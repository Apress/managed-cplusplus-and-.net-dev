#pragma once


namespace MonthCalendar1
{
    using namespace System;
    using namespace System::ComponentModel;
    using namespace System::Collections;
    using namespace System::Windows::Forms;
    using namespace System::Data;
    using namespace System::Drawing;

    public __gc class Form1 : public System::Windows::Forms::Form
    {   
    public:
        Form1(void)
        {
            InitializeComponent();
        }
  
    protected:
        void Dispose(Boolean disposing)
        {
            if (disposing && components)
            {
                components->Dispose();
            }
            __super::Dispose(disposing);
        }
    private: System::Windows::Forms::MonthCalendar *  monthCal;
    private: System::Windows::Forms::Label *  Start;
    private: System::Windows::Forms::Label *  End;
    private: System::ComponentModel::Container * components;

        void InitializeComponent(void)
        {
            this->monthCal = new System::Windows::Forms::MonthCalendar();
            this->Start = new System::Windows::Forms::Label();
            this->End = new System::Windows::Forms::Label();
            this->SuspendLayout();
            // 
            // monthCalendar1
            // 
            System::DateTime __mcTemp__1[] = new System::DateTime[1];
            __mcTemp__1[0] = System::DateTime(2002, 10, 31, 0, 0, 0, 0);
            this->monthCal->AnnuallyBoldedDates = __mcTemp__1;
            this->monthCal->CalendarDimensions = System::Drawing::Size(2, 2);
            this->monthCal->Location = System::Drawing::Point(8, 8);
            this->monthCal->MaxSelectionCount = 365;
            System::DateTime __mcTemp__2[] = new System::DateTime[2];
            __mcTemp__2[0] = System::DateTime(2002, 10, 1, 0, 0, 0, 0);
            __mcTemp__2[1] = System::DateTime(2002, 10, 15, 0, 0, 0, 0);
            this->monthCal->MonthlyBoldedDates = __mcTemp__2;
            this->monthCal->Name = S"monthCal";
            this->monthCal->ShowWeekNumbers = true;
            this->monthCal->TabIndex = 0;
            this->monthCal->DateChanged += new System::Windows::Forms::DateRangeEventHandler(this, monthCal_DateChanged);
            // 
            // Start
            // 
            this->Start->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
            this->Start->Location = System::Drawing::Point(150, 375);
            this->Start->Name = S"Start";
            this->Start->TabIndex = 1;
            // 
            // End
            // 
            this->End->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
            this->End->Location = System::Drawing::Point(290, 375);
            this->End->Name = S"End";
            this->End->TabIndex = 2;
            // 
            // Form1
            // 
            this->AutoScaleBaseSize = System::Drawing::Size(6, 15);
            this->ClientSize = System::Drawing::Size(540, 410);
            this->Controls->Add(this->End);
            this->Controls->Add(this->Start);
            this->Controls->Add(this->monthCal);
            this->Name = S"Form1";
            this->Text = S"Month Calendar";
            this->ResumeLayout(false);
        }   
    private: 
        System::Void monthCal_DateChanged(System::Object *  sender, System::Windows::Forms::DateRangeEventArgs *  e)
        {
            // Update start and end range labels when date changes
            Start->Text = e->Start.Date.ToShortDateString(); 
            End->Text   = e->End.Date.ToShortDateString(); 
        }
    };
}


