#pragma once


namespace TreeView1
{
    using namespace System;
    using namespace System::ComponentModel;
    using namespace System::Collections;
    using namespace System::Windows::Forms;
    using namespace System::Data;
    using namespace System::Drawing;

    public __gc class Form1 : public System::Windows::Forms::Form
    {   
    public:
        Form1(void)
        {
            InitializeComponent();
        }
  
    protected:
        void Dispose(Boolean disposing)
        {
            if (disposing && components)
            {
                components->Dispose();
            }
            __super::Dispose(disposing);
        }
    private: System::Windows::Forms::TreeView *  tView;
    private: System::ComponentModel::Container * components;


        void InitializeComponent(void)
        {
            this->tView = new System::Windows::Forms::TreeView();
            this->SuspendLayout();
            // 
            // tView
            // 
            this->tView->Dock = System::Windows::Forms::DockStyle::Fill;
            this->tView->LabelEdit = true;
            this->tView->Location = System::Drawing::Point(0, 0);
            this->tView->Name = S"tView";
            System::Windows::Forms::TreeNode* __mcTemp__1[] = new System::Windows::Forms::TreeNode*[2];
            System::Windows::Forms::TreeNode* __mcTemp__2[] = new System::Windows::Forms::TreeNode*[1];
            __mcTemp__2[0] = new System::Windows::Forms::TreeNode(S"<Holder>");
            __mcTemp__1[0] = new System::Windows::Forms::TreeNode(S"Root Node A", __mcTemp__2);
            System::Windows::Forms::TreeNode* __mcTemp__3[] = new System::Windows::Forms::TreeNode*[1];
            __mcTemp__3[0] = new System::Windows::Forms::TreeNode(S"<Holder>");
            __mcTemp__1[1] = new System::Windows::Forms::TreeNode(S"Root Node B", __mcTemp__3);
            this->tView->Nodes->AddRange(__mcTemp__1);
            this->tView->Size = System::Drawing::Size(200, 450);
            this->tView->BeforeExpand += new System::Windows::Forms::TreeViewCancelEventHandler(this, tView_BeforeExpand);
            // 
            // Form1
            // 
            this->AutoScaleBaseSize = System::Drawing::Size(6, 15);
            this->ClientSize = System::Drawing::Size(200, 450);
            this->Controls->Add(this->tView);
            this->Name = S"Form1";
            this->Text = S"The Tree View";
            this->ResumeLayout(false);

        }   
    private: 
        System::Void tView_BeforeExpand(System::Object *  sender, System::Windows::Forms::TreeViewCancelEventArgs *  e)
        {
            // Already expanded before?
            if (e->Node->Nodes->Count > 1)
                return;  // Already expanded
            else if (e->Node->Nodes->Count == 1)
            {
                if (e->Node->Nodes->Item[0]->Text->Equals(S"<Holder>"))
                    e->Node->Nodes->RemoveAt(0); // Holder node ready for expanding
                else
                    return; // Already expanded but only one sub node
            }
            // Randomly expand the Node
            Random *rand = new Random();
            Int32 rnd = rand->Next(1,5);
            for (Int32 i = 0; i < rnd; i++) // Randon number of sub nodes 
            {
                TreeNode *stn = 
                    new TreeNode(String::Format(S"Sub Node {0}", __box(i+1)));
                e->Node->Nodes->Add(stn);

                if (rand->Next(2) == 1)  // Has sub sub-nodes
                    stn->Nodes->Add(new TreeNode(S"<Holder>"));
            }
        }
    };
}


