#pragma once


namespace Splitter1
{
    using namespace System;
    using namespace System::ComponentModel;
    using namespace System::Collections;
    using namespace System::Windows::Forms;
    using namespace System::Data;
    using namespace System::Drawing;

    public __gc class Form1 : public System::Windows::Forms::Form
    {   
    public:
        Form1(void)
        {
            InitializeComponent();
        }
  
    protected:
        void Dispose(Boolean disposing)
        {
            if (disposing && components)
            {
                components->Dispose();
            }
            __super::Dispose(disposing);
        }
    private: System::Windows::Forms::TextBox *  textBox1;
    private: System::Windows::Forms::Splitter *  splitter1;
    private: System::Windows::Forms::TextBox *  textBox2;
    private: System::Windows::Forms::Splitter *  splitter2;
    private: System::Windows::Forms::TextBox *  textBox3;
    private: System::ComponentModel::Container * components;

        void InitializeComponent(void)
        {
            this->textBox1 = new System::Windows::Forms::TextBox();
            this->splitter1 = new System::Windows::Forms::Splitter();
            this->textBox2 = new System::Windows::Forms::TextBox();
            this->splitter2 = new System::Windows::Forms::Splitter();
            this->textBox3 = new System::Windows::Forms::TextBox();
            this->SuspendLayout();
            // 
            // textBox1
            // 
            this->textBox1->Dock = System::Windows::Forms::DockStyle::Left;
            this->textBox1->Location = System::Drawing::Point(0, 0);
            this->textBox1->Multiline = true;
            this->textBox1->Name = S"textBox1";
            this->textBox1->Size = System::Drawing::Size(120, 300);
            this->textBox1->TabIndex = 0;
            this->textBox1->Text = S"textBox1";
            // 
            // splitter1
            // 
            this->splitter1->Location = System::Drawing::Point(120, 0);
            this->splitter1->Name = S"splitter1";
            this->splitter1->Size = System::Drawing::Size(3, 300);
            this->splitter1->TabIndex = 1;
            this->splitter1->TabStop = false;
            // 
            // textBox2
            // 
            this->textBox2->Dock = System::Windows::Forms::DockStyle::Top;
            this->textBox2->Location = System::Drawing::Point(123, 0);
            this->textBox2->Multiline = true;
            this->textBox2->Name = S"textBox2";
            this->textBox2->Size = System::Drawing::Size(177, 144);
            this->textBox2->TabIndex = 2;
            this->textBox2->Text = S"textBox2";
            // 
            // splitter2
            // 
            this->splitter2->Dock = System::Windows::Forms::DockStyle::Top;
            this->splitter2->Location = System::Drawing::Point(123, 144);
            this->splitter2->Name = S"splitter2";
            this->splitter2->Size = System::Drawing::Size(177, 3);
            this->splitter2->TabIndex = 3;
            this->splitter2->TabStop = false;
            // 
            // textBox3
            // 
            this->textBox3->Dock = System::Windows::Forms::DockStyle::Fill;
            this->textBox3->Location = System::Drawing::Point(123, 147);
            this->textBox3->Multiline = true;
            this->textBox3->Name = S"textBox3";
            this->textBox3->Size = System::Drawing::Size(177, 153);
            this->textBox3->TabIndex = 4;
            this->textBox3->Text = S"textBox3";
            // 
            // Form1
            // 
            this->AutoScaleBaseSize = System::Drawing::Size(6, 15);
            this->ClientSize = System::Drawing::Size(300, 300);
            this->Controls->Add(this->textBox3);
            this->Controls->Add(this->splitter2);
            this->Controls->Add(this->textBox2);
            this->Controls->Add(this->splitter1);
            this->Controls->Add(this->textBox1);
            this->Name = S"Form1";
            this->Text = S"Splitters";
            this->ResumeLayout(false);
        }   
    };
}


