#pragma once


namespace NotifyIconEx
{
    using namespace System;
    using namespace System::ComponentModel;
    using namespace System::Collections;
    using namespace System::Windows::Forms;
    using namespace System::Data;
    using namespace System::Drawing;

    public __gc class Form1 : public System::Windows::Forms::Form
    {   
    public:
        Form1(void)
        {
            InitializeComponent();
        }
  
    protected:
        void Dispose(Boolean disposing)
        {
            if (disposing && components)
            {
                components->Dispose();
            }
            __super::Dispose(disposing);
        }
    private: System::Windows::Forms::NotifyIcon *  notifyIcon;
    private: System::Windows::Forms::Button *  bnNotify;
    private: System::Windows::Forms::Button *  bnTaskbar;


    private: System::ComponentModel::IContainer *  components;

        void InitializeComponent(void)
        {
            this->components = new System::ComponentModel::Container();
            System::Resources::ResourceManager *  resources = new System::Resources::ResourceManager(__typeof(NotifyIconEx::Form1));
            this->notifyIcon = new System::Windows::Forms::NotifyIcon(this->components);
            this->bnNotify = new System::Windows::Forms::Button();
            this->bnTaskbar = new System::Windows::Forms::Button();
            this->SuspendLayout();
            // 
            // notifyIcon
            // 
            this->notifyIcon->Icon = (dynamic_cast<System::Drawing::Icon *  >(resources->GetObject(S"notifyIcon.Icon")));
            this->notifyIcon->Text = S"Notify Icon Example";
            this->notifyIcon->Visible = true;
            // 
            // bnNotify
            // 
            this->bnNotify->Location = System::Drawing::Point(48, 32);
            this->bnNotify->Name = S"bnNotify";
            this->bnNotify->Size = System::Drawing::Size(144, 23);
            this->bnNotify->TabIndex = 0;
            this->bnNotify->Text = S"Toggle Notify Icon";
            this->bnNotify->Click += new System::EventHandler(this, bnNotify_Click);
            // 
            // bnTaskbar
            // 
            this->bnTaskbar->Location = System::Drawing::Point(48, 72);
            this->bnTaskbar->Name = S"bnTaskbar";
            this->bnTaskbar->Size = System::Drawing::Size(144, 24);
            this->bnTaskbar->TabIndex = 1;
            this->bnTaskbar->Text = S"Toggle TaskBar Icon";
            this->bnTaskbar->Click += new System::EventHandler(this, bnTaskbar_Click);
            // 
            // Form1
            // 
            this->AutoScaleBaseSize = System::Drawing::Size(6, 15);
            this->ClientSize = System::Drawing::Size(240, 154);
            this->Controls->Add(this->bnTaskbar);
            this->Controls->Add(this->bnNotify);
            this->Icon = (dynamic_cast<System::Drawing::Icon *  >(resources->GetObject(S"$this.Icon")));
            this->Name = S"Form1";
            this->Text = S"Notify Icon";
            this->ResumeLayout(false);

        }   
    private: 
        System::Void bnNotify_Click(System::Object *  sender, System::EventArgs *  e)
        {
            notifyIcon->Visible = !notifyIcon->Visible;
        }

    private: 
        System::Void bnTaskbar_Click(System::Object *  sender, System::EventArgs *  e)
        {
            this->ShowInTaskbar = ! this->ShowInTaskbar;
        }

    };
}


