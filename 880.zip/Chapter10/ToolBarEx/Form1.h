#pragma once


namespace ToolBarEx
{
    using namespace System;
    using namespace System::ComponentModel;
    using namespace System::Collections;
    using namespace System::Windows::Forms;
    using namespace System::Data;
    using namespace System::Drawing;

    public __gc class Form1 : public System::Windows::Forms::Form
    {   
    public:
        Form1(void)
        {
            InitializeComponent();
        }
  
    protected:
        void Dispose(Boolean disposing)
        {
            if (disposing && components)
            {
                components->Dispose();
            }
            __super::Dispose(disposing);
        }
    private: System::Windows::Forms::ToolBar *  toolBar;
    private: System::Windows::Forms::ToolBarButton *  ttbHappy;
    private: System::Windows::Forms::ToolBarButton *  ttbSad;
    private: System::Windows::Forms::Label *  label;
    private: System::Windows::Forms::ImageList *  imageList;
    private: System::ComponentModel::IContainer *  components;

        void InitializeComponent(void)
        {
            this->components = new System::ComponentModel::Container();
            System::Resources::ResourceManager *  resources = new System::Resources::ResourceManager(__typeof(ToolBarEx::Form1));
            this->toolBar = new System::Windows::Forms::ToolBar();
            this->ttbHappy = new System::Windows::Forms::ToolBarButton();
            this->ttbSad = new System::Windows::Forms::ToolBarButton();
            this->imageList = new System::Windows::Forms::ImageList(this->components);
            this->label = new System::Windows::Forms::Label();
            this->SuspendLayout();
            // 
            // toolBar
            // 
            System::Windows::Forms::ToolBarButton* __mcTemp__1[] = new System::Windows::Forms::ToolBarButton*[2];
            __mcTemp__1[0] = this->ttbHappy;
            __mcTemp__1[1] = this->ttbSad;
            this->toolBar->Buttons->AddRange(__mcTemp__1);
            this->toolBar->DropDownArrows = true;
            this->toolBar->ImageList = this->imageList;
            this->toolBar->Location = System::Drawing::Point(0, 0);
            this->toolBar->Name = S"toolBar";
            this->toolBar->ShowToolTips = true;
            this->toolBar->Size = System::Drawing::Size(292, 44);
            this->toolBar->TabIndex = 0;
            this->toolBar->TextAlign = System::Windows::Forms::ToolBarTextAlign::Right;
            this->toolBar->ButtonClick += new System::Windows::Forms::ToolBarButtonClickEventHandler(this, toolBar_ButtonClick);
            // 
            // ttbHappy
            // 
            this->ttbHappy->ImageIndex = 0;
            this->ttbHappy->Text = S"Happy";
            this->ttbHappy->ToolTipText = S"Happy Face";
            // 
            // ttbSad
            // 
            this->ttbSad->ImageIndex = 1;
            this->ttbSad->Text = S"Sad";
            this->ttbSad->ToolTipText = S"Sad Face";
            // 
            // imageList
            // 
            this->imageList->ImageSize = System::Drawing::Size(32, 32);
            this->imageList->ImageStream = (dynamic_cast<System::Windows::Forms::ImageListStreamer *  >(resources->GetObject(S"imageList.ImageStream")));
            this->imageList->TransparentColor = System::Drawing::Color::Transparent;
            // 
            // label
            // 
            this->label->Location = System::Drawing::Point(88, 120);
            this->label->Name = S"label";
            this->label->TabIndex = 1;
            // 
            // Form1
            // 
            this->AutoScaleBaseSize = System::Drawing::Size(6, 15);
            this->ClientSize = System::Drawing::Size(292, 270);
            this->Controls->Add(this->label);
            this->Controls->Add(this->toolBar);
            this->Name = S"Form1";
            this->Text = S"An Emotional ToolBar";
            this->ResumeLayout(false);

        }   
    private: 
        System::Void toolBar_ButtonClick(System::Object *  sender, System::Windows::Forms::ToolBarButtonClickEventArgs *  e)
        {
            label->Text = e->Button->ToolTipText;
        }
    };
}


