#pragma once


namespace ElaborateMenu
{
    using namespace System;
    using namespace System::ComponentModel;
    using namespace System::Collections;
    using namespace System::Windows::Forms;
    using namespace System::Data;
    using namespace System::Drawing;

    /// <summary> 
    /// Summary for Form1
    ///
    /// WARNING: If you change the name of this class, you will need to change the 
    ///          'Resource File Name' property for the managed resource compiler tool 
    ///          associated with all .resx files this class depends on.  Otherwise,
    ///          the designers will not be able to interact properly with localized
    ///          resources associated with this form.
    /// </summary>
    public __gc class Form1 : public System::Windows::Forms::Form
    {   
    public:
        Form1(void)
        {
            InitializeComponent();

            // Create "This" MenuItem
            file_do_this_Item         = new MenuItem(); 
            file_do_this_Item->Text   = S"Thi&s"; 
            file_do_this_Item->Click += new EventHandler(this, menuItem_Click); 

            // Create "That" MenuItem
            file_do_that_Item         = new MenuItem(); 
            file_do_that_Item->Text   = S"Tha&t"; 
            file_do_that_Item->Click += new EventHandler(this, menuItem_Click); 

            // Create "Other Thing" MenuItem
            file_do_other_Item         = new MenuItem(); 
            file_do_other_Item->Text   = S"Othe&r Thing"; 
            file_do_other_Item->Click += new EventHandler(this, menuItem_Click); 

            // Create "DO" MenuItem
            file_do_Item         = new MenuItem(); 
            file_do_Item->Text   = S"&Do"; 

            // Add sub MenuItems
            file_do_Item->MenuItems->Add(file_do_this_Item);
            file_do_Item->MenuItems->Add(file_do_that_Item);
            file_do_Item->MenuItems->Add(file_do_other_Item);

            // Create "Exit" MenuItem
            file_exit_Item         = new MenuItem(); 
            file_exit_Item->Text   = S"E&xit"; 
            file_exit_Item->Click += new EventHandler(this, menuItem_Click); 

            // Create "File" MenuItem
            file_Menu        = new MenuItem(); 
            file_Menu->Text  = S"&File";

            // Add Sub MenuItems 
            file_Menu->MenuItems->Add(file_do_Item);
            file_Menu->MenuItems->Add(new MenuItem(S"-"));  // <-- Separator
            file_Menu->MenuItems->Add(file_exit_Item);

            // Create "About" MenuItem
            help_about_Item         = new MenuItem(); 
            help_about_Item->Text   = S"&About"; 
            help_about_Item->Click += new EventHandler(this, menuItem_Click); 

            // Create "Help" MenuItem
            help_Menu        = new MenuItem(); 
            help_Menu->Text  = S"&Help"; 

            // Add Sub MenuItems 
            help_Menu->MenuItems->Add(help_about_Item);

            // Create MainMenu
            main_Menu = new MainMenu(); 

            // Add Sub MenuItems 
            main_Menu->MenuItems->Add(file_Menu);
            main_Menu->MenuItems->Add(help_Menu);

            // Add MainMenu to Form
            Menu = this->main_Menu; 
       }
    protected:
        void Dispose(Boolean disposing)
        {
            if (disposing && components)
            {
                components->Dispose();
            }
            __super::Dispose(disposing);
        }

    private: MainMenu *main_Menu; 
    private: MenuItem *file_Menu; 
    private: MenuItem *file_do_Item; 
    private: MenuItem *file_do_this_Item; 
    private: MenuItem *file_do_that_Item; 
    private: MenuItem *file_do_other_Item; 
    private: MenuItem *file_exit_Item; 
    private: MenuItem *help_Menu; 
    private: MenuItem *help_about_Item; 
    private: System::ComponentModel::Container * components;

        void InitializeComponent(void)
        {
            this->components = new System::ComponentModel::Container();
            this->Size = System::Drawing::Size(300,300);
            this->Text = S"A Less Simple Menu";
        }   
    private:
        void menuItem_Click(Object *sender, EventArgs *e) 
        {
            if (sender == file_exit_Item)
            {
                Application::Exit();
            }
            else if (sender == help_about_Item)
            {
                MessageBox::Show(S"Main Menu v.1.0.0.0");
            }
            else 
            {
                MessageBox::Show(S"Another MenuItem");
            }
        }
    };
}


