#pragma once


namespace ErrProvider
{
	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary> 
	/// Summary for Form1
	///
	/// WARNING: If you change the name of this class, you will need to change the 
	///          'Resource File Name' property for the managed resource compiler tool 
	///          associated with all .resx files this class depends on.  Otherwise,
	///          the designers will not be able to interact properly with localized
	///          resources associated with this form.
	/// </summary>
	public __gc class Form1 : public System::Windows::Forms::Form
	{	
	public:
		Form1(void)
		{
			InitializeComponent();
		}
  
	protected:
		void Dispose(Boolean disposing)
		{
			if (disposing && components)
			{
				components->Dispose();
			}
			__super::Dispose(disposing);
		}

    private: System::Windows::Forms::ErrorProvider *  eProvider;
    private: System::Windows::Forms::TextBox *  tbName;
    private: System::Windows::Forms::TextBox *  tbPword;
    private: System::Windows::Forms::Button *  bnLogin;
    private: System::Windows::Forms::Label *  lbName;
    private: System::Windows::Forms::Label *  lbPword;



	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container * components;

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
            this->eProvider = new System::Windows::Forms::ErrorProvider();
            this->tbName = new System::Windows::Forms::TextBox();
            this->tbPword = new System::Windows::Forms::TextBox();
            this->bnLogin = new System::Windows::Forms::Button();
            this->lbName = new System::Windows::Forms::Label();
            this->lbPword = new System::Windows::Forms::Label();
            this->SuspendLayout();
            // 
            // errorProvider1
            // 
            this->eProvider->ContainerControl = this;
            // 
            // tbName
            // 
            this->tbName->Location = System::Drawing::Point(112, 32);
            this->tbName->Name = S"tbName";
            this->tbName->TabIndex = 0;
            this->tbName->Text = S"";
            this->tbName->Validating += new System::ComponentModel::CancelEventHandler(this, textBox_Validating);
            // 
            // tbPword
            // 
            this->tbPword->Location = System::Drawing::Point(112, 80);
            this->tbPword->Name = S"tbPword";
            this->tbPword->PasswordChar = '*';
            this->tbPword->TabIndex = 1;
            this->tbPword->Text = S"";
            this->tbPword->Validating += new System::ComponentModel::CancelEventHandler(this, textBox_Validating);
            // 
            // button1
            // 
            this->bnLogin->Location = System::Drawing::Point(80, 128);
            this->bnLogin->Name = S"bnLogin";
            this->bnLogin->TabIndex = 2;
            this->bnLogin->Text = S"&Login";
            this->bnLogin->Click += new System::EventHandler(this, bnLogin_Click);
            // 
            // lbName
            // 
            this->lbName->Location = System::Drawing::Point(32, 40);
            this->lbName->Name = S"lbName";
            this->lbName->Size = System::Drawing::Size(64, 16);
            this->lbName->TabIndex = 0;
            this->lbName->Text = S"&Name";
            // 
            // lbPword
            // 
            this->lbPword->Location = System::Drawing::Point(32, 88);
            this->lbPword->Name = S"lbPword";
            this->lbPword->Size = System::Drawing::Size(64, 16);
            this->lbPword->TabIndex = 1;
            this->lbPword->Text = S"&Password";
            // 
            // Form1
            // 
            this->AutoScaleBaseSize = System::Drawing::Size(6, 15);
            this->ClientSize = System::Drawing::Size(256, 178);
            this->Controls->Add(this->lbPword);
            this->Controls->Add(this->lbName);
            this->Controls->Add(this->bnLogin);
            this->Controls->Add(this->tbPword);
            this->Controls->Add(this->tbName);
            this->Name = S"Form1";
            this->Text = S"System Login";
            this->ResumeLayout(false);

        }	
    private: 
        System::Void textBox_Validating(System::Object *  sender, System::ComponentModel::CancelEventArgs *  e)
        {
            try
            {
                TextBox *tb = dynamic_cast<TextBox*>(sender);

                if (tb->Text->Equals(""))
                    eProvider->SetError(tb, "**Error** Missing Entry!");
                else
                    eProvider->SetError(tb, "");
            }
            catch (...)
            {
                // Not TextBox
            }
        }
 
    private: 
        System::Void bnLogin_Click(System::Object *  sender, System::EventArgs *  e)
        {
            if (tbName->Text->Equals(""))
                eProvider->SetError(tbName, "**Error** Missing Entry!");
            else
                eProvider->SetError(tbName, "");

            if (tbPword->Text->Equals(""))
            {
                // Place the icon left side of control
                eProvider->SetIconAlignment(tbPword, ErrorIconAlignment::MiddleLeft);
                eProvider->SetError(tbPword, "**Error** Missing Entry!");
            }
            else
                eProvider->SetError(tbPword, "");
         }

};
}


