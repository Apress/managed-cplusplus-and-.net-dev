#pragma once


namespace SimpleMenu
{
    using namespace System;
    using namespace System::ComponentModel;
    using namespace System::Collections;
    using namespace System::Windows::Forms;
    using namespace System::Data;
    using namespace System::Drawing;

    public __gc class Form1 : public System::Windows::Forms::Form
    {   
    public:
        Form1(void)
        {
            InitializeComponent();

            // Create MenuItem
            exitItem = new MenuItem(); 
            exitItem->Text   = S"E&xit"; 
            exitItem->Click += new EventHandler(this, menuItem_Click); 

            // Create Root MenuItem and sub menu items
            fileMenu = new MenuItem(); 
            fileMenu->Text  = S"&File"; 
            fileMenu->MenuItems->Add(exitItem);

            // Create MainMenu and add root menuitem
            mainMenu = new MainMenu(); 
            mainMenu->MenuItems->Add(fileMenu);

            // Add MainMenu to Form
            Menu = this->mainMenu; 
        }
  
    protected:
        void Dispose(Boolean disposing)
        {
            if (disposing && components)
            {
                components->Dispose();
            }
            __super::Dispose(disposing);
        }

    private: MainMenu *mainMenu; 
    private: MenuItem *fileMenu; 
    private: MenuItem *exitItem; 
    private: System::ComponentModel::Container * components;

        void InitializeComponent(void)
        {
            this->components = new System::ComponentModel::Container();
            this->Size = System::Drawing::Size(300,300);
            this->Text = S"A simple Menu";
        }   
    private:
        void menuItem_Click(Object *sender, EventArgs *e) 
        {
            if (sender == exitItem)
            {
                Application::Exit();
            }
        }
    };
}


