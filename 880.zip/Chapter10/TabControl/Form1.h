#pragma once


namespace TabControl1
{
    using namespace System;
    using namespace System::ComponentModel;
    using namespace System::Collections;
    using namespace System::Windows::Forms;
    using namespace System::Data;
    using namespace System::Drawing;

    public __gc class Form1 : public System::Windows::Forms::Form
    {   
    public:
        Form1(void)
        {
            InitializeComponent();
        }
  
    protected:
        void Dispose(Boolean disposing)
        {
            if (disposing && components)
            {
                components->Dispose();
            }
            __super::Dispose(disposing);
        }
    private: System::Windows::Forms::TabControl *  tabControl1;
    private: System::Windows::Forms::TabPage *  tabPage1;
    private: System::Windows::Forms::TabPage *  tabPage2;
    private: System::Windows::Forms::Label *  label1;
    private: System::Windows::Forms::Label *  label2;
    private: System::ComponentModel::Container * components;

        void InitializeComponent(void)
        {
            this->tabControl1 = new System::Windows::Forms::TabControl();
            this->tabPage1 = new System::Windows::Forms::TabPage();
            this->label1 = new System::Windows::Forms::Label();
            this->tabPage2 = new System::Windows::Forms::TabPage();
            this->label2 = new System::Windows::Forms::Label();
            this->tabControl1->SuspendLayout();
            this->tabPage1->SuspendLayout();
            this->tabPage2->SuspendLayout();
            this->SuspendLayout();
            // 
            // tabControl1
            // 
            this->tabControl1->Alignment = System::Windows::Forms::TabAlignment::Left;
            this->tabControl1->Controls->Add(this->tabPage1);
            this->tabControl1->Controls->Add(this->tabPage2);
            this->tabControl1->Dock = System::Windows::Forms::DockStyle::Fill;
            this->tabControl1->HotTrack = true;
            this->tabControl1->Location = System::Drawing::Point(0, 0);
            this->tabControl1->Multiline = true;
            this->tabControl1->Name = S"tabControl1";
            this->tabControl1->SelectedIndex = 0;
            this->tabControl1->ShowToolTips = true;
            this->tabControl1->Size = System::Drawing::Size(250, 150);
            this->tabControl1->TabIndex = 0;
            // 
            // tabPage1
            // 
            this->tabPage1->Controls->Add(this->label1);
            this->tabPage1->Location = System::Drawing::Point(25, 4);
            this->tabPage1->Name = S"tabPage1";
            this->tabPage1->Size = System::Drawing::Size(221, 142);
            this->tabPage1->TabIndex = 0;
            this->tabPage1->Text = S"Tab One";
            this->tabPage1->ToolTipText = S"This is tab one";
            // 
            // label1
            // 
            this->label1->Location = System::Drawing::Point(60, 60);
            this->label1->Name = S"label1";
            this->label1->TabIndex = 0;
            this->label1->Text = S"This is tab one";
            // 
            // tabPage2
            // 
            this->tabPage2->Controls->Add(this->label2);
            this->tabPage2->Location = System::Drawing::Point(25, 4);
            this->tabPage2->Name = S"tabPage2";
            this->tabPage2->Size = System::Drawing::Size(221, 142);
            this->tabPage2->TabIndex = 1;
            this->tabPage2->Text = S"Tab Two";
            this->tabPage2->ToolTipText = S"This is tab two";
            // 
            // label2
            // 
            this->label2->Location = System::Drawing::Point(60, 60);
            this->label2->Name = S"label2";
            this->label2->TabIndex = 0;
            this->label2->Text = S"This is tab two";
            // 
            // Form1
            // 
            this->AutoScaleBaseSize = System::Drawing::Size(6, 15);
            this->ClientSize = System::Drawing::Size(250, 150);
            this->Controls->Add(this->tabControl1);
            this->Name = S"Form1";
            this->Text = S"Simple Tab Control";
            this->tabControl1->ResumeLayout(false);
            this->tabPage1->ResumeLayout(false);
            this->tabPage2->ResumeLayout(false);
            this->ResumeLayout(false);
        }   
    };
}


