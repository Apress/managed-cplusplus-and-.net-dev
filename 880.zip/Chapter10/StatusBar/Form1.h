#pragma once


namespace StatusBar1
{
    using namespace System;
    using namespace System::ComponentModel;
    using namespace System::Collections;
    using namespace System::Windows::Forms;
    using namespace System::Data;
    using namespace System::Drawing;

    public __gc class Form1 : public System::Windows::Forms::Form
    {   
    public:
        Form1(void)
        {
            InitializeComponent();
        }
  
    protected:
        void Dispose(Boolean disposing)
        {
            if (disposing && components)
            {
                components->Dispose();
            }
            __super::Dispose(disposing);
        }
    private: System::Windows::Forms::StatusBar *  statusBar;
    private: System::Windows::Forms::StatusBarPanel *  statusButtons;
    private: System::Windows::Forms::StatusBarPanel *  statusXCoord;
    private: System::Windows::Forms::StatusBarPanel *  statusYCoord;
    private: System::ComponentModel::Container * components;

        void InitializeComponent(void)
        {
            this->statusBar = new System::Windows::Forms::StatusBar();
            this->statusButtons = new System::Windows::Forms::StatusBarPanel();
            this->statusXCoord = new System::Windows::Forms::StatusBarPanel();
            this->statusYCoord = new System::Windows::Forms::StatusBarPanel();
            (dynamic_cast<System::ComponentModel::ISupportInitialize *  >(this->statusButtons))->BeginInit();
            (dynamic_cast<System::ComponentModel::ISupportInitialize *  >(this->statusXCoord))->BeginInit();
            (dynamic_cast<System::ComponentModel::ISupportInitialize *  >(this->statusYCoord))->BeginInit();
            this->SuspendLayout();
            // 
            // statusBar
            // 
            this->statusBar->Name = S"statusBar";
            System::Windows::Forms::StatusBarPanel* __mcTemp__1[] = new System::Windows::Forms::StatusBarPanel*[3];
            __mcTemp__1[0] = this->statusButtons;
            __mcTemp__1[1] = this->statusXCoord;
            __mcTemp__1[2] = this->statusYCoord;
            this->statusBar->Panels->AddRange(__mcTemp__1);
            this->statusBar->ShowPanels = true;
            // 
            // statusButtons
            // 
            this->statusButtons->AutoSize = System::Windows::Forms::StatusBarPanelAutoSize::Spring;
            // 
            // statusXCoord
            // 
            this->statusXCoord->Width = 50;
            // 
            // statusYCoord
            // 
            this->statusYCoord->Width = 50;
            // 
            // Form1
            // 
            this->AutoScaleBaseSize = System::Drawing::Size(6, 15);
            this->ClientSize = System::Drawing::Size(300, 322);
            this->Controls->Add(this->statusBar);
            this->Name = S"Form1";
            this->Text = S"Status Bar Mouse Tracking";
            this->MouseDown += new System::Windows::Forms::MouseEventHandler(this, Form1_MouseDown);
            this->MouseMove += new System::Windows::Forms::MouseEventHandler(this, Form1_MouseMove);
            (dynamic_cast<System::ComponentModel::ISupportInitialize *  >(this->statusButtons))->EndInit();
            (dynamic_cast<System::ComponentModel::ISupportInitialize *  >(this->statusXCoord))->EndInit();
            (dynamic_cast<System::ComponentModel::ISupportInitialize *  >(this->statusYCoord))->EndInit();
            this->ResumeLayout(false);
        }   
    private: 
        System::Void Form1_MouseMove(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
        {
            // x,y coords in second and third status bar panels
            statusXCoord->Text = String::Format("X={0}", __box(e->X)); 
            statusYCoord->Text = String::Format("Y={0}", __box(e->Y)); 
        }
    private: 
        System::Void Form1_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
        {
            // clicked mouse button in first status bar panel
            if (e->Button == MouseButtons::Right) 
                statusButtons->Text = S"Right"; 
            else if (e->Button == MouseButtons::Left) 
                statusButtons->Text = S"Left"; 
            else 
                statusButtons->Text = S"Middle"; 
        }
    };
}


