#pragma once


namespace PictureBoxEx
{
    using namespace System;
    using namespace System::ComponentModel;
    using namespace System::Collections;
    using namespace System::Windows::Forms;
    using namespace System::Data;
    using namespace System::Drawing;

    public __gc class Form1 : public System::Windows::Forms::Form
    {   
    public:
        Form1(void)
        {
            InitializeComponent();
        }
  
    protected:
        void Dispose(Boolean disposing)
        {
            if (disposing && components)
            {
                components->Dispose();
            }
            __super::Dispose(disposing);
        }
    private: System::Windows::Forms::PictureBox *  pictureBox;
    private: System::ComponentModel::Container * components;

        void InitializeComponent(void)
        {
            System::Resources::ResourceManager *  resources = new System::Resources::ResourceManager(__typeof(PictureBoxEx::Form1));
            this->pictureBox = new System::Windows::Forms::PictureBox();
            this->SuspendLayout();
            // 
            // pictureBox
            // 
            this->pictureBox->Anchor = (System::Windows::Forms::AnchorStyles)(((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Bottom) 
                | System::Windows::Forms::AnchorStyles::Left) 
                | System::Windows::Forms::AnchorStyles::Right);
            this->pictureBox->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
            this->pictureBox->Image = (dynamic_cast<System::Drawing::Image *  >(resources->GetObject(S"pictureBox.Image")));
            this->pictureBox->Location = System::Drawing::Point(16, 16);
            this->pictureBox->Name = S"pictureBox";
            this->pictureBox->Size = System::Drawing::Size(272, 274);
            this->pictureBox->SizeMode = System::Windows::Forms::PictureBoxSizeMode::StretchImage;
            this->pictureBox->TabIndex = 0;
            this->pictureBox->TabStop = false;
            // 
            // Form1
            // 
            this->AutoScaleBaseSize = System::Drawing::Size(6, 15);
            this->ClientSize = System::Drawing::Size(304, 314);
            this->Controls->Add(this->pictureBox);
            this->Name = S"Form1";
            this->Text = S"Shaina Shoshana";
            this->ResumeLayout(false);

        }   
    };
}


