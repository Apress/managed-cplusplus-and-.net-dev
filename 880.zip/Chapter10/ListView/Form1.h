#pragma once


namespace ListView1
{
    using namespace System;
    using namespace System::ComponentModel;
    using namespace System::Collections;
    using namespace System::Windows::Forms;
    using namespace System::Data;
    using namespace System::Drawing;

    public __gc class Form1 : public System::Windows::Forms::Form
    {   
    public:
        Form1(void)
        {
            InitializeComponent();
            FillListView();
        }
  
    protected:
        void Dispose(Boolean disposing)
        {
            if (disposing && components)
            {
                components->Dispose();
            }
            __super::Dispose(disposing);
        }

    private: System::Windows::Forms::ColumnHeader *  Fruit;
    private: System::Windows::Forms::ColumnHeader *  Price;
    private: System::Windows::Forms::ColumnHeader *  Available;
    private: System::Windows::Forms::ListView *  lView;
    private: System::Windows::Forms::Label *  label;
    private: System::ComponentModel::Container * components;

        void InitializeComponent(void)
        {
            this->lView = new System::Windows::Forms::ListView();
            this->Fruit = new System::Windows::Forms::ColumnHeader();
            this->Price = new System::Windows::Forms::ColumnHeader();
            this->Available = new System::Windows::Forms::ColumnHeader();
            this->label = new System::Windows::Forms::Label();
            this->SuspendLayout();
            // 
            // lView
            // 
            this->lView->Anchor = (System::Windows::Forms::AnchorStyles)((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Left) 
                | System::Windows::Forms::AnchorStyles::Right);
            System::Windows::Forms::ColumnHeader* __mcTemp__1[] = new System::Windows::Forms::ColumnHeader*[3];
            __mcTemp__1[0] = this->Fruit;
            __mcTemp__1[1] = this->Price;
            __mcTemp__1[2] = this->Available;
            this->lView->Columns->AddRange(__mcTemp__1);
            this->lView->FullRowSelect = true;
            this->lView->GridLines = true;
            this->lView->Location = System::Drawing::Point(0, 0);
            this->lView->MultiSelect = false;
            this->lView->Name = S"lView";
            this->lView->Size = System::Drawing::Size(424, 248);
            this->lView->TabIndex = 0;
            this->lView->View = System::Windows::Forms::View::Details;
            this->lView->SelectedIndexChanged += new System::EventHandler(this, lView_SelectedIndexChanged);
            // 
            // Fruit
            // 
            this->Fruit->Text = S"Fruit";
            // 
            // Price
            // 
            this->Price->Text = S"Price";
            // 
            // Available
            // 
            this->Available->Text = S"Available";
            this->Available->Width = 100;
            // 
            // label
            // 
            this->label->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
            this->label->Location = System::Drawing::Point(170, 260);
            this->label->Name = S"label";
            this->label->Size = System::Drawing::Size(60, 24);
            this->label->TabIndex = 1;
            this->label->TextAlign = System::Drawing::ContentAlignment::MiddleCenter;
            // 
            // Form1
            // 
            this->AutoScaleBaseSize = System::Drawing::Size(6, 15);
            this->ClientSize = System::Drawing::Size(400, 300);
            this->Controls->Add(this->label);
            this->Controls->Add(this->lView);
            this->Name = S"Form1";
            this->Text = S"The List View Control";
            this->ResumeLayout(false);

        }   
    private: 
        void FillListView()
        {
            String *itemRec1[]  = { S"Apple",  S"1.50", S"September" };
            lView->Items->Add(new ListViewItem(itemRec1));

            String *itemRec2[]  = { S"Orange", S"2.50", S"March" };
            lView->Items->Add(new ListViewItem(itemRec2));

            String *itemRec3[]  = { S"Grape",  S"1.95", S"November" };
            lView->Items->Add(new ListViewItem(itemRec3));
        }
    private: 
        System::Void lView_SelectedIndexChanged(System::Object *  sender, System::EventArgs *  e)
        {
            if (lView->FocusedItem != 0)
                label->Text = lView->FocusedItem->SubItems->Item[1]->Text; 
        }
    };
}


