#pragma once


namespace ColorDlg
{
    using namespace System;
    using namespace System::ComponentModel;
    using namespace System::Collections;
    using namespace System::Windows::Forms;
    using namespace System::Data;
    using namespace System::Drawing;

    public __gc class Form1 : public System::Windows::Forms::Form
    {   
    public:
        Form1(void)
        {
            InitializeComponent();
        }
  
    protected:
        void Dispose(Boolean disposing)
        {
            if (disposing && components)
            {
                components->Dispose();
            }
            __super::Dispose(disposing);
        }

    private: System::ComponentModel::Container * components;

        void InitializeComponent(void)
        {
            this->AutoScaleBaseSize = System::Drawing::Size(6, 15);
            this->ClientSize = System::Drawing::Size(292, 270);
            this->Name = S"Form1";
            this->Text = S"Common Color Dialog - Click Form";
            this->Click += new System::EventHandler(this, Form1_Click);

        }   
    private: 
        System::Void Form1_Click(System::Object *  sender, System::EventArgs *  e)
        {
            ColorDialog *colordialog = new ColorDialog();
        
            if (colordialog->ShowDialog() == DialogResult::OK)
            {
                BackColor = colordialog->Color;
            }
        }
    };
}


