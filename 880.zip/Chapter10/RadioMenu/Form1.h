#pragma once


namespace RadioMenu
{
    using namespace System;
    using namespace System::ComponentModel;
    using namespace System::Collections;
    using namespace System::Windows::Forms;
    using namespace System::Data;
    using namespace System::Drawing;

    public __gc class Form1 : public System::Windows::Forms::Form
    {   
    public:
        Form1(void)
        {
            InitializeComponent();

            // Default first menu item as checked
            checkMenuItem = menuItem1;
            checkMenuItem->Checked = true;

        }
  
    protected:
        void Dispose(Boolean disposing)
        {
            if (disposing && components)
            {
                components->Dispose();
            }
            __super::Dispose(disposing);
        }

    private: System::Windows::Forms::MenuItem *  menuItem1;
    private: System::Windows::Forms::MenuItem *  menuItem2;
    private: System::Windows::Forms::MenuItem *  menuItem3;
    private: System::Windows::Forms::ContextMenu *  contextMenu;

    private: MenuItem *checkMenuItem;  // The holder of the check mark  private:
        
    private: System::ComponentModel::Container * components;

        void InitializeComponent(void)
        {
            this->contextMenu = new System::Windows::Forms::ContextMenu();
            this->menuItem1 = new System::Windows::Forms::MenuItem();
            this->menuItem2 = new System::Windows::Forms::MenuItem();
            this->menuItem3 = new System::Windows::Forms::MenuItem();
            // 
            // contextMenu
            // 
            System::Windows::Forms::MenuItem* __mcTemp__1[] = new System::Windows::Forms::MenuItem*[3];
            __mcTemp__1[0] = this->menuItem1;
            __mcTemp__1[1] = this->menuItem2;
            __mcTemp__1[2] = this->menuItem3;
            this->contextMenu->MenuItems->AddRange(__mcTemp__1);
            // 
            // menuItem1
            // 
            this->menuItem1->Index = 0;
            this->menuItem1->RadioCheck = true;
            this->menuItem1->Text = S"Item one";
            this->menuItem1->Click += new System::EventHandler(this, menuItem_Click);
            // 
            // menuItem2
            // 
            this->menuItem2->Index = 1;
            this->menuItem2->RadioCheck = true;
            this->menuItem2->Text = S"Item Two";
            this->menuItem2->Click += new System::EventHandler(this, menuItem_Click);
            // 
            // menuItem3
            // 
            this->menuItem3->Index = 2;
            this->menuItem3->RadioCheck = true;
            this->menuItem3->Text = S"Item Three";
            this->menuItem3->Click += new System::EventHandler(this, menuItem_Click);
            // 
            // Form1
            // 
            this->AutoScaleBaseSize = System::Drawing::Size(6, 15);
            this->ClientSize = System::Drawing::Size(292, 270);
            this->ContextMenu = this->contextMenu;
            this->Name = S"Form1";
            this->Text = S"ContextMenu - Right Click Form";

        }   
    private:
        void menuItem_Click(Object *sender, System::EventArgs *e) 
        {
            // Uncheck Original checked MenuItem
            checkMenuItem->Checked = false; 
            // Set the check menu to the selected MenuItem
            checkMenuItem = dynamic_cast<MenuItem*>(sender);
            // Check the new MenuItem 
            checkMenuItem->Checked = true; 
        }
    };
}


