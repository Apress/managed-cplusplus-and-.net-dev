#pragma once

using namespace System;
using namespace System::ComponentModel;
using namespace System::Collections;
using namespace System::Windows::Forms;
using namespace System::Data;
using namespace System::Drawing;


namespace CustomDialog
{
    public __gc class MyDialog : public System::Windows::Forms::Form
    {
    public: 
        MyDialog(void)
        {
            InitializeComponent();
        }
        
    public:
        __property void set_PassedValue(String *value)  // PassedValue property
        {
            tbPassedValue->Text = value;
        }
        __property String *get_PassedValue()
        {
            return tbPassedValue->Text;
        }

protected: 
        void Dispose(Boolean disposing)
        {
            if (disposing && components)
            {
                components->Dispose();
            }
            __super::Dispose(disposing);
        }

    private: System::Windows::Forms::Button *  bnOK;
    private: System::Windows::Forms::Button *  bnAbort;
    private: System::Windows::Forms::Button *  bnCancel;
    private: System::Windows::Forms::TextBox *  tbPassedValue;
    private: System::ComponentModel::Container* components;

        void InitializeComponent(void)
        {
            this->tbPassedValue = new System::Windows::Forms::TextBox();
            this->bnOK = new System::Windows::Forms::Button();
            this->bnAbort = new System::Windows::Forms::Button();
            this->bnCancel = new System::Windows::Forms::Button();
            this->SuspendLayout();
            // 
            // tbPassedValue
            // 
            this->tbPassedValue->Location = System::Drawing::Point(15, 25);
            this->tbPassedValue->Name = S"tbPassedValue";
            this->tbPassedValue->Size = System::Drawing::Size(250, 22);
            this->tbPassedValue->TabIndex = 0;
            this->tbPassedValue->Text = S"";
            // 
            // bnOK
            // 
            this->bnOK->DialogResult = System::Windows::Forms::DialogResult::OK;
            this->bnOK->Location = System::Drawing::Point(15, 72);
            this->bnOK->Name = S"bnOK";
            this->bnOK->TabIndex = 1;
            this->bnOK->Text = S"OK";
            // 
            // bnAbort
            // 
            this->bnAbort->DialogResult = System::Windows::Forms::DialogResult::Abort;
            this->bnAbort->Location = System::Drawing::Point(104, 72);
            this->bnAbort->Name = S"bnAbort";
            this->bnAbort->TabIndex = 2;
            this->bnAbort->Text = S"Abort";
            // 
            // bnCancel
            // 
            this->bnCancel->DialogResult = System::Windows::Forms::DialogResult::Cancel;
            this->bnCancel->Location = System::Drawing::Point(192, 72);
            this->bnCancel->Name = S"bnCancel";
            this->bnCancel->TabIndex = 3;
            this->bnCancel->Text = S"Cancel";
            // 
            // MyDialog
            // 
            this->AcceptButton = this->bnOK;
            this->AutoScaleBaseSize = System::Drawing::Size(6, 15);
            this->CancelButton = this->bnCancel;
            this->ClientSize = System::Drawing::Size(300, 120);
            this->Controls->Add(this->bnCancel);
            this->Controls->Add(this->bnAbort);
            this->Controls->Add(this->bnOK);
            this->Controls->Add(this->tbPassedValue);
            this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedToolWindow;
            this->Name = S"MyDialog";
            this->Text = S"My Custom Dialog";
            this->ResumeLayout(false);
        }       
    };
}