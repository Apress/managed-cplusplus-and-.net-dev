#pragma once

#include "MyDialog.h"

namespace CustomDialog
{
    using namespace System;
    using namespace System::ComponentModel;
    using namespace System::Collections;
    using namespace System::Windows::Forms;
    using namespace System::Data;
    using namespace System::Drawing;

    public __gc class Form1 : public System::Windows::Forms::Form
    {   
    public:
        Form1(void)
        {
            InitializeComponent();
        }
  
    protected:
        void Dispose(Boolean disposing)
        {
            if (disposing && components)
            {
                components->Dispose();
            }
            __super::Dispose(disposing);
        }
    private: System::Windows::Forms::Label *  lbRetVal;
    private: System::Windows::Forms::Label *  lbRetString;
    private: System::ComponentModel::Container * components;

        void InitializeComponent(void)
        {
            this->lbRetVal = new System::Windows::Forms::Label();
            this->lbRetString = new System::Windows::Forms::Label();
            this->SuspendLayout();
            // 
            // lbRetVal
            // 
            this->lbRetVal->Location = System::Drawing::Point(32, 40);
            this->lbRetVal->Name = S"lbRetVal";
            this->lbRetVal->Size = System::Drawing::Size(224, 23);
            // 
            // lbRetString
            // 
            this->lbRetString->Location = System::Drawing::Point(32, 88);
            this->lbRetString->Name = S"lbRetString";
            this->lbRetString->Size = System::Drawing::Size(224, 23);
            // 
            // Form1
            // 
            this->AutoScaleBaseSize = System::Drawing::Size(6, 15);
            this->ClientSize = System::Drawing::Size(292, 270);
            this->Controls->Add(this->lbRetString);
            this->Controls->Add(this->lbRetVal);
            this->Name = S"Form1";
            this->Text = S"Click Form to get dialog";
            this->Click += new System::EventHandler(this, Form1_Click);
            this->ResumeLayout(false);

        }   
    private: 
        System::Void Form1_Click(System::Object *  sender, System::EventArgs *  e)
        {
            MyDialog *mydialog = new MyDialog(); 
            mydialog->PassedValue = S"This has been passed from Form1"; 

            if (mydialog->ShowDialog() == DialogResult::OK) 
                lbRetVal->Text = S"OK"; 
            else if (mydialog->DialogResult == DialogResult::Abort) 
                lbRetVal->Text = S"Abort"; 
            else  
                lbRetVal->Text = S"Cancel"; 

            lbRetString->Text = mydialog->PassedValue; 
        }

    };
}


