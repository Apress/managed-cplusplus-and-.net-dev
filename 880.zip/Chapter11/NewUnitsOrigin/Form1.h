#pragma once


namespace NewUnitsOrigin
{
    using namespace System;
    using namespace System::ComponentModel;
    using namespace System::Collections;
    using namespace System::Windows::Forms;
    using namespace System::Data;
    using namespace System::Drawing;

    public __gc class Form1 : public System::Windows::Forms::Form
    {   
    public:
        Form1(void)
        {
            InitializeComponent();
        }
  
    protected:
        void Dispose(Boolean disposing)
        {
            if (disposing && components)
            {
                components->Dispose();
            }
            __super::Dispose(disposing);
        }

    private: System::ComponentModel::Container * components;

        void InitializeComponent(void)
        {
            this->AutoScaleBaseSize = System::Drawing::Size(6, 15);
            this->ClientSize = System::Drawing::Size(442, 265);
            this->Name = S"Form1";
            this->Text = S"Millimeter Unit of measure Origin (20,20)";
            this->Paint += 
               new System::Windows::Forms::PaintEventHandler(this, Form1_Paint);

        }   
    private: 
        System::Void Form1_Paint(System::Object * sender, 
                                 System::Windows::Forms::PaintEventArgs * e)
        {
            Graphics *g = e->Graphics;

            // Draw a rectangle before unit of measure and origin change
            g->DrawRectangle(Pens::Black, 5, 5, 50, 20);

            // Draw same rectangle after change
            g->PageUnit = GraphicsUnit::Millimeter;
            g->TranslateTransform(20,20);
            g->DrawRectangle(Pens::Black, 5, 5, 50, 20);
        }

    };
}


