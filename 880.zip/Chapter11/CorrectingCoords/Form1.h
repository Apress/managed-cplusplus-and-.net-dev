#pragma once


namespace CorrectingCoords
{
    using namespace System;
    using namespace System::ComponentModel;
    using namespace System::Collections;
    using namespace System::Windows::Forms;
    using namespace System::Data;
    using namespace System::Drawing;

    public __gc class Form1 : public System::Windows::Forms::Form
    {   
    public:
        Form1(void)
        {
            coords = new ArrayList();  // Instantiate coords array

            InitializeComponent();
        }
  
    protected:
        void Dispose(Boolean disposing)
        {
            if (disposing && components)
            {
                components->Dispose();
            }
            __super::Dispose(disposing);
        }

    private: System::ComponentModel::Container * components;
    private: ArrayList *coords;

        void InitializeComponent(void)
        {
            this->AutoScaleBaseSize = System::Drawing::Size(6, 15);
            this->ClientSize = System::Drawing::Size(292, 265);
            this->Name = S"Form1";
            this->Text = S"Click and see coords";
            this->MouseDown += 
            new System::Windows::Forms::MouseEventHandler(this,Form1_MouseDown);
            this->Paint += 
            new System::Windows::Forms::PaintEventHandler(this, Form1_Paint);
        }   
    private: 
        System::Void Form1_MouseDown(System::Object * sender, 
                                     System::Windows::Forms::MouseEventArgs * e)
        {
            coords->Add(__box(Point(e->X, e->Y)));
            Invalidate();
        }
    private: 
        System::Void Form1_Paint(System::Object * sender, 
                                 System::Windows::Forms::PaintEventArgs * e)
        {
            Graphics *g = e->Graphics;
            for (Int32 i = 0; i < coords->Count; i++)
            {
                Point *p = dynamic_cast<Point*>(coords->Item[i]);
                g->DrawString(String::Format(S"({0},{1})",__box(p->X),
                                                          __box(p->Y)), 
                   new Drawing::Font(new FontFamily(S"Courier New"), 8),
                   Brushes::Black, (Single)p->X, (Single)p->Y);
            }
        }
    };
}


