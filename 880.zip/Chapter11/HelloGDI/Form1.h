#pragma once


namespace HelloGDI
{
    using namespace System;
    using namespace System::ComponentModel;
    using namespace System::Collections;
    using namespace System::Windows::Forms;
    using namespace System::Data;
    using namespace System::Drawing;

    public __gc class Form1 : public System::Windows::Forms::Form
    {   
    public:
        Form1(void)
        {
            InitializeComponent();
        }
  
    protected:
        void Dispose(Boolean disposing)
        {
            if (disposing && components)
            {
                components->Dispose();
            }
            __super::Dispose(disposing);
        }

    private: System::ComponentModel::Container * components;

        void InitializeComponent(void)
        {
            this->ClientSize = System::Drawing::Size(300, 300);
            this->Name = S"Form1";
            this->Text = S"Hello GDI+";
            this->Paint += new System::Windows::Forms::PaintEventHandler(this, Form1_Paint);
        }   

	protected: 
        System::Void Form1_Paint(System::Object *  sender, System::Windows::Forms::PaintEventArgs *  e)
        {
            Graphics *g = e->Graphics;
            g->DrawString(S"Hello World!", 
            new Drawing::Font(S"Arial", 16), Brushes::Black, 75.0, 110.0);
        }
    };
}


