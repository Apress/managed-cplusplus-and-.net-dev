#pragma once


namespace DisappearingCoords
{
    using namespace System;
    using namespace System::ComponentModel;
    using namespace System::Collections;
    using namespace System::Windows::Forms;
    using namespace System::Data;
    using namespace System::Drawing;

    public __gc class Form1 : public System::Windows::Forms::Form
    {   
    public:
        Form1(void)
        {
            InitializeComponent();
        }
  
    protected:
        void Dispose(Boolean disposing)
        {
            if (disposing && components)
            {
                components->Dispose();
            }
            __super::Dispose(disposing);
        }

    private: System::ComponentModel::Container * components;

        void InitializeComponent(void)
        {
            this->AutoScaleBaseSize = System::Drawing::Size(6, 15);
            this->ClientSize = System::Drawing::Size(292, 265);
            this->Name = S"Form1";
            this->Text = S"Click and see coords";
            this->MouseDown += new System::Windows::Forms::MouseEventHandler(this, Form1_MouseDown);
        }   
    private: 
        System::Void Form1_MouseDown(System::Object * sender, System::Windows::Forms::MouseEventArgs *  e)
        {
            Graphics *g = this->CreateGraphics();
            g->DrawString(String::Format(S"({0},{1})",__box(e->X),__box(e->Y)), 
                new Drawing::Font(new FontFamily(S"Courier New"), 8),
                Brushes::Black, (Single)e->X, (Single)e->Y);

            g->Dispose();  // we dispose of the Graphics object because we 
                           // created it with the CreateGraphics() method.
        }
    };
}


