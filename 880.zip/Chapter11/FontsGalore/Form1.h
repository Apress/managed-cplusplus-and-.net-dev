#pragma once


namespace FontsGalore
{
    using namespace System;
    using namespace System::ComponentModel;
    using namespace System::Collections;
    using namespace System::Windows::Forms;
    using namespace System::Data;
    using namespace System::Drawing::Text;
    using namespace System::Drawing;

    public __gc class Form1 : public System::Windows::Forms::Form
    {   
    public:
        Form1(void)
        {
            fonts = new Drawing::Font*[10];
            fontstr = new String*[10];

            // Used to generate random fonts
            Single sizes[] = { 10.0, 12.5, 16.0 };
            FontStyle fontstyles[] = { 
                FontStyle::Regular, FontStyle::Bold, 
                FontStyle::Italic,
            (FontStyle)(FontStyle::Underline|FontStyle::Bold|FontStyle::Italic)
            };
            GraphicsUnit units[] = { GraphicsUnit::Point, GraphicsUnit::Pixel }; 

            // Get all fonts on computer
            InstalledFontCollection *availFonts = new InstalledFontCollection();
            FontFamily *fontfamilies[] = availFonts->Families;

            Random *rand = new Random();
            Int32 ff, s, fs, u;
            for (Int32 i = 0; i < fonts->Count; i++)
            {
                s  = rand->Next(0,3);
                fs = rand->Next(0,3);
                u  = rand->Next(0,2);

                // Not all fonts support every style
                do {
                    ff = rand->Next(0,fontfamilies->Count);
                }
                while (!fontfamilies[ff]->IsStyleAvailable(
                    (FontStyle)fontstyles[fs]));
                
                // Display string of font
                fontstr[i] = String::Format(S"{0} {1} {2}", 
                    fontfamilies[ff]->Name,
                    __box(sizes[s])->ToString(),
                    String::Concat(__box(fontstyles[fs])->ToString(), S" ", 
                                __box(units[u])->ToString()));

                // Create the font
                fonts[i] = new Drawing::Font(fontfamilies[ff], sizes[s], 
                                            (FontStyle)fontstyles[fs],
                                            (GraphicsUnit)units[u]);
            }
            InitializeComponent();
        }
  
    protected:
        void Dispose(Boolean disposing)
        {
            if (disposing && components)
            {
                components->Dispose();
            }
            __super::Dispose(disposing);
        }

    private: System::ComponentModel::Container * components;

    private: Drawing::Font *fonts[];
    private: String *fontstr[];

        void InitializeComponent(void)
        {
            this->AutoScaleBaseSize = System::Drawing::Size(6, 15);
            this->ClientSize = System::Drawing::Size(292, 265);
            this->Name = S"Form1";
            this->Text = S"Many Fonts";
            this->Paint += new System::Windows::Forms::PaintEventHandler(this, Form1_Paint);

        }   
    private: 
        System::Void Form1_Paint(System::Object *  sender, 
                                 System::Windows::Forms::PaintEventArgs *  e)
        {
            Graphics *g = e->Graphics;

            Single lineloc = 0;
            for (Int32 i = 0; i < fonts->Count; i++)
            {
                // Display font
                g->DrawString(fontstr[i], fonts[i], Brushes::Black, 10, lineloc);

                // Calculate the top of the next line
                lineloc += fonts[i]->Height;
            }
        }
    };
}


