#pragma once


namespace InterOrUnion
{
    using namespace System;
    using namespace System::ComponentModel;
    using namespace System::Collections;
    using namespace System::Windows::Forms;
    using namespace System::Data;
    using namespace System::Drawing;

    public __gc class Form1 : public System::Windows::Forms::Form
    {   
    public:
        Form1(void)
        {
            // Build the rectangles from points and size
            Drawing::Point point1 = Drawing::Point(25,25);
            Drawing::Point point2 = Drawing::Point(100,100);
            Drawing::Size size    = Drawing::Size(200, 150);
            rect1  = Drawing::Rectangle(point1, size); 
            rect2  = Drawing::Rectangle(point2, size);

            InitializeComponent();
        }
  
    protected:
        void Dispose(Boolean disposing)
        {
            if (disposing && components)
            {
                components->Dispose();
            }
            __super::Dispose(disposing);
        }

    private: System::ComponentModel::Container * components;

    // intersecting and unions rectangles
    private: Drawing::Rectangle rect1;
    private: Drawing::Rectangle rect2;

        void InitializeComponent(void)
        {
            this->ClientSize = System::Drawing::Size(325, 275);
            this->Name = S"Form1";
            this->Text = S"Click in Window";
            this->MouseDown += 
            new System::Windows::Forms::MouseEventHandler(this,Form1_MouseDown);
            this->Paint += 
            new System::Windows::Forms::PaintEventHandler(this, Form1_Paint);
        }   
    private: 
        System::Void Form1_Paint(System::Object *  sender, 
                                 System::Windows::Forms::PaintEventArgs * e)
        {
            // Grab Graphics from e
            Graphics *g = e->Graphics;
            // Draw a couple of rectangles
            g->DrawRectangle(Pens::Black, rect1);
            g->DrawRectangle(Pens::Black, rect2);
        }
    private: 
        System::Void Form1_MouseDown(System::Object *  sender, 
                                     System::Windows::Forms::MouseEventArgs * e)
        {
            // build a point from x,y coords of mouse click
            Point p = Point(e->X, e->Y);

            // did we click in the intersection?
            if (Rectangle::Intersect(rect1, rect2).Contains(p))
                Text = S"Intersection and Union";
            // did we click in the union?
            else if (Rectangle::Union(rect1, rect2).Contains(p))
                Text = S"Union";
            // did we miss altogether
            else
                Text = S"Outside of Both";
        }
    };
}


