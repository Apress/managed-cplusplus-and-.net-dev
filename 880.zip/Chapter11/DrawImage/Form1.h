#pragma once


namespace DrawImage
{
    using namespace System;
    using namespace System::ComponentModel;
    using namespace System::Collections;
    using namespace System::Windows::Forms;
    using namespace System::Data;
    using namespace System::Drawing;

    public __gc class Form1 : public System::Windows::Forms::Form
    {   
    public:
        Form1(void)
        {
            InitializeComponent();
        }
  
    protected:
        void Dispose(Boolean disposing)
        {
            if (disposing && components)
            {
                components->Dispose();
            }
            __super::Dispose(disposing);
        }

    private: System::ComponentModel::Container * components;

        void InitializeComponent(void)
        {
            this->AutoScaleBaseSize = System::Drawing::Size(6, 15);
            this->ClientSize = System::Drawing::Size(292, 265);
            this->Name = S"Form1";
            this->Text = S"Draw Image";
            this->Paint += new System::Windows::Forms::PaintEventHandler(this, Form1_Paint);
        }   
    private: 
        System::Void Form1_Paint(System::Object *  sender, System::Windows::Forms::PaintEventArgs *  e)
        {
            Graphics *g = e->Graphics;
            Image *img = Image::FromFile(S"MCppCover.jpg");
            g->DrawImage(img, 0, 0, img->Width*2, img->Height*2);
        }
    };
}


