#pragma once


namespace DrawingLines
{
    using namespace System;
    using namespace System::ComponentModel;
    using namespace System::Collections;
    using namespace System::Windows::Forms;
    using namespace System::Data;
    using namespace System::Drawing;
    using namespace System::Drawing::Drawing2D;

    public __gc class Form1 : public System::Windows::Forms::Form
    {   
    public:
        Form1(void)
        {
            pen = new Pen*[5];

            // a one unit width black pen
            pen[0] = Pens::Black;

            // a one unit with purple pen broken with dashes
            pen[1] = new Pen(Color::Purple);
            pen[1]->DashStyle = DashStyle::Dash;

            // a 4 unit width chocolate pen
            pen[2] = new Pen(Color::Chocolate, 4);
            
            // A 8 width royalblue pen made up of three lines narrow wide narrow
            pen[3] = new Pen(Color::RoyalBlue, 10);
            Single cArray[] = { 0.0f, 0.1f, 0.3f, 0.7f, 0.9f, 1.0f }; 
            pen[3]->CompoundArray = cArray;

            // a 5 width tomato pen with dimond start and round end anchors
            pen[4] = new Pen(Color::Tomato, 5);
            pen[4]->StartCap = LineCap::DiamondAnchor;
            pen[4]->EndCap = LineCap::RoundAnchor;

            InitializeComponent();
        }
  
    protected:
        void Dispose(Boolean disposing)
        {
            if (disposing && components)
            {
                components->Dispose();
            }
            __super::Dispose(disposing);
        }

    private: System::ComponentModel::Container * components;
    private: Pen *pen[];

        void InitializeComponent(void)
        {
            this->BackColor = System::Drawing::Color::White;
            this->ClientSize = System::Drawing::Size(300, 300);
            this->Name = S"Form1";
            this->Text = S"Drawing Some lines";
            this->Paint += new System::Windows::Forms::PaintEventHandler(this, Form1_Paint);

        }   
    private: 
        System::Void Form1_Paint(System::Object *  sender, System::Windows::Forms::PaintEventArgs *  e)
        {
            Random *rand = new Random();
            Graphics *g = e->Graphics;
            for (Int32 i = 0; i < 10; i++)
            {
                g->DrawLine(pen[i%5], rand->Next(0,299), 
                    rand->Next(0,299), rand->Next(0,299), rand->Next(0,299));
            }
        }

    };
}


