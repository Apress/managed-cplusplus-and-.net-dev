#using <mscorlib.dll>
using namespace System;

__gc class MyDerivedException : public ApplicationException
{
public:
    MyDerivedException( String *err ) : ApplicationException(err) {}
};

__gc class MyException  // Not derived from Exception class
{
};


Int32 main(void)
{
    for (Int32 i = 0; i < 4; i++)
    {
        Console::WriteLine(S"Start Loop");
        try
        {
            if (i == 1)
                throw new ApplicationException(S"\tBase Exception");
            else if (i == 2)
                throw new MyDerivedException(S"\tMy Derived Exception");
            else if (i == 3)
                throw new MyException();

            Console::WriteLine(S"\tNo Exception");
        }
        catch (ApplicationException *e)
        {
            Console::WriteLine(e->Message);
        }
        catch (...)
        {
            Console::WriteLine(S"\tMy Exception");
        }
        Console::WriteLine(S"End Loop");
    }
    return 0;
}