#using <mscorlib.dll>
using namespace System;

__gc class X {};
__gc class Y {};

Int32 main(void)
{
    X *x = new X;

    try
    {
         Y *y = __try_cast<Y*>(x);   
         Console::WriteLine(S"No Exception");  // Should not execute
    }
    catch (InvalidCastException *e)
    {
        Console::WriteLine(S"Invalid Cast Exception");
        Console::WriteLine(e->StackTrace);
    }

    return 0;
}