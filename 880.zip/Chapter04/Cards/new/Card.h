namespace Cards
{
    public __value enum Suits { Heart, Diamond, Spade, Club };

    public __gc class Card
    {
        Int32 _type;
        Suits _suit;

    public:
        Card(Int32 type, Suits suit)
        {
            _type = type;
            _suit = suit;
        }

        __property Int32 get_Type()
        { 
            return _type; 
        }

        __property Suits get_Suit()
        { 
            return _suit; 
        }

        virtual String *ToString()
        {
            String *t;

            if (_type > 1 && _type < 11)
                t = _type.ToString();
            else if (_type == 1)
                t = S"A";
            else if (_type == 11)
                t = S"J";
            else if (_type == 12)
                t = S"Q";
            else
                t = S"K";

            switch (_suit)
            {
                case Heart:
                    return String::Concat(t, S"H");
                case Diamond:
                    return String::Concat(t, S"D");
                case Spade:
                    return String::Concat(t, S"S");
                    break;
                default:
                    return String::Concat(t, S"C");
            }
        }
    };
}