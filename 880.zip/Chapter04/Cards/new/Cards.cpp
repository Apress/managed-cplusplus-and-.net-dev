#using <mscorlib.dll>
using namespace System;

#include "card.h"
#include "deck.h"