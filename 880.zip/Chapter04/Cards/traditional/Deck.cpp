#using <mscorlib.dll>
using namespace System;

#include "card.h"
#include "deck.h"

Cards::Deck::Deck(void)
{
    deck = new Card*[52];

    for (Int32 i = 0; i < 13; i++)
    {
        deck[i]    = new Card(i+1, Suits::Heart);
        deck[i+13] = new Card(i+1, Suits::Club);
        deck[i+26] = new Card(i+1, Suits::Diamond);
        deck[i+39] = new Card(i+1, Suits::Spade);
    }
    curCard = 0;
}

Cards::Card *Cards::Deck::Deal()
{
    if (curCard < deck->Count)
        return deck[curCard++];
    else
        return 0;
}

void Cards::Deck::Shuffle()
{
    Random *r = new Random();
    Card *tmp;
    Int32 j;

    for( int i = 0; i < deck->Count; i++ )
    {
        j        = r->Next(deck->Count);
        tmp      = deck[j];
        deck[j] = deck[i];
        deck[i] = tmp;
    }

    curCard = 0;
}
