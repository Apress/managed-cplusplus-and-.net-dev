#using <mscorlib.dll>
using namespace System;

#include "card.h"

Cards::Card::Card(Int32 type, Suits suit)
{
    _type = type;
    _suit = suit;
}

Int32 Cards::Card::get_Type()      
{ 
    return _type; 
}

Cards::Suits Cards::Card::get_Suit() 
{ 
    return _suit; 
}

String *Cards::Card::ToString()
{
    String *t;

    if (_type > 1 && _type < 11)
        t = _type.ToString();
    else if (_type == 1)
        t = S"A";
    else if (_type == 11)
        t = S"J";
    else if (_type == 12)
        t = S"Q";
    else
        t = S"K";

    switch (_suit)
    {
        case Heart:
            return String::Concat(t, S"H");
        case Diamond:
            return String::Concat(t, S"D");
        case Spade:
            return String::Concat(t, S"S");
        default:
            return String::Concat(t, S"C");
    }
}
