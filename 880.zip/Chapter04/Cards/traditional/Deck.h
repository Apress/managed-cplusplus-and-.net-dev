namespace Cards
{
    public __gc class Deck
    {
        Card  *deck[];
        Int32 curCard;

    public:
        Deck(void);

        Card *Deal();
        void Shuffle();
    };
}
