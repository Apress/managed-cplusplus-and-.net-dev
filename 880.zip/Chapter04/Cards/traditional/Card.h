namespace Cards
{
    public __value enum Suits { Heart, Diamond, Spade, Club };

    public __gc class Card
    {
        Int32 _type;
        Suits _suit;

    public:
        Card(Int32 type, Suits suit);

        __property Int32 get_Type(); 
        __property Suits get_Suit();

        virtual String *ToString();
    };
}
