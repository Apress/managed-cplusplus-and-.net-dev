#using <mscorlib.dll>
#using <cards.dll>

using namespace System;
using namespace Cards;

Int32 main(void)
{
    Deck &deck = *new Deck;

    deck.Shuffle();

    Card *card;
    Int32 cnt = 0;
    while ((card = deck.Deal()) != 0)
    {
        Console::Write(card->ToString());
        Console::Write("\t");
        cnt++;

        if (cnt > 4)
        {
            Console::WriteLine("");
            cnt = 0;
        }
    }
    Console::WriteLine("");

    return 0;
}