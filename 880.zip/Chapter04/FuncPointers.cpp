#using <mscorlib.dll>
using namespace System;

void SayHello(String *name)
{
    Console::Write(S"Hello there ");
    Console::WriteLine(name);
}

void SayStuff(String *name)
{
    Console::Write(S"Nice weather we are having. Right, ");
    Console::Write(name);
    Console::WriteLine(S"?");
}

void SayBye(String *name)
{
    Console::Write(S"Good-bye ");
    Console::WriteLine(name);
}

Int32 main(void)
{
    void (*say)(String*) = SayHello;
    say(S"Mr. Fraser");

    say = SayStuff;
    say(S"Stephen");

    say = SayBye;
    say(S"Friend");

    return 0;
}