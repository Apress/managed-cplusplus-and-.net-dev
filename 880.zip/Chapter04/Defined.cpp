#using <mscorlib.dll>
using namespace System;

#define DISAPPEARS
#define ONE 1
#define TWO 2
#define POW2(x) (x)*(x)

Int32 main(void)
{
    Console::Write(S"The follow symbol disappears->" DISAPPEARS);
    Console::WriteLine(S"<-");

    Int32 x = TWO;
    Int32 y = POW2(x + ONE);

    Console::WriteLine(y.ToString());

    return 0;
}