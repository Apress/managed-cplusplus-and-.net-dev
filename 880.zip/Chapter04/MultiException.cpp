#using <mscorlib.dll>
using namespace System;

__gc class LevelOneException : public ApplicationException
{
public:
    LevelOneException( String *err ) : ApplicationException(err) {}
};

__gc class LevelTwoException : public LevelOneException
{
public:
    LevelTwoException( String *err ) : LevelOneException(err) {}
};


Int32 main(void)
{
    for (Int32 i = 0; i < 4; i++)
    {
        Console::WriteLine(S"Start Loop");
        try
        {
            if (i == 1)
                throw new ApplicationException(S"\tBase Exception Thrown");
            else if (i == 2)
                throw new LevelOneException(S"\tLevel 1 Exception Thrown");
            else if (i == 3)
                throw new LevelTwoException(S"\tLevel 2 Exception Thrown");

            Console::WriteLine(S"\tNo Exception");
        }
        catch (LevelTwoException *e2)
        {
            Console::WriteLine(e2->Message);
            Console::WriteLine(S"\tLevel 2 Exception Caught");
        }
        catch (LevelOneException *e1)
        {
            Console::WriteLine(e1->Message);
            Console::WriteLine(S"\tLevel 1 Exception Caught");
        }
        catch (ApplicationException *e)
        {
            Console::WriteLine(e->Message);
            Console::WriteLine(S"\tBase Exception Caught");
        }
        Console::WriteLine(S"End Loop");
    }
    return 0;
}