#using <mscorlib.dll>
using namespace System;

__gc class MyException : public ApplicationException
{
public:
    MyException( String *err ) : ApplicationException(err) {}
};

Int32 main(void)
{
    for (Int32 i = 0; i < 3; i++)
    {
        Console::WriteLine(S"Start Loop");
        try
        {
            if (i == 0)
            {
                Console::WriteLine(S"\tCounter equal to 0");
            }
            else if (i == 1)
            {
                throw new MyException(S"\t**Exception** Counter equal to 1");
            }
            else
            {
                Console::WriteLine(S"\tCounter greater than 1");
            }
        }
        catch (MyException *e)
        {
            Console::WriteLine(e->Message);
        }
        Console::WriteLine(S"End Loop");
    }
    return 0;
}