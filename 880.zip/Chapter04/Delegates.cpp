#using <mscorlib.dll>
using namespace System;

__delegate void SayDelegate(String *name);

__gc class Talkative
{
public:
    static void SayHello(String *name)
    {
        Console::Write(S"Hello there ");
        Console::WriteLine(name);
    }

    void SayStuff(String *name)
    {
        Console::Write(S"Nice weather we are having. Right, ");
        Console::Write(name);
        Console::WriteLine(S"?");
    }

    void SayBye(String *name)
    {
        Console::Write(S"Good-bye ");
        Console::WriteLine(name);
    }
};

Int32 main(void)
{
    SayDelegate *hello, *stuff, *bye;

    // Static member functions
    hello = new SayDelegate(0, &Talkative::SayHello);

    Talkative *computer = new Talkative();

    // Non-static member functions
    stuff = new SayDelegate(computer, &Talkative::SayStuff);
    bye   = new SayDelegate(computer, &Talkative::SayBye);

    // Multicast delegate combine
    SayDelegate *winded = dynamic_cast<SayDelegate*>(Delegate::Combine(hello, stuff));

    winded->Invoke(S"Mr Fraser");
    bye->Invoke(S"Stephen");

    Console::WriteLine(S"-------------------------------");

    // Multicast delegate remove
    SayDelegate *gruff = dynamic_cast<SayDelegate*>(Delegate::Remove(winded, stuff));

    gruff->Invoke(S"Mr Fraser");
    bye->Invoke(S"Stephen");

    return 0;
}