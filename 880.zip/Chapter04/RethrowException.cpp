#using <mscorlib.dll>
using namespace System;

Int32 main(void)
{
    try
    {
        try
        {
            throw new ApplicationException(S"\t***Boom***");
            Console::WriteLine(S"Imbedded Try End");
        }
        catch (ApplicationException *ie)
        {
            Console::WriteLine(S"Caught Exception ");
            Console::WriteLine(ie->Message);
            throw;
        }
        Console::WriteLine(S"Outer Try End");
    }
    catch (ApplicationException *oe)
    {
        Console::WriteLine(S"Recaught Exception ");
        Console::WriteLine(oe->Message);
    }

    return 0;
}