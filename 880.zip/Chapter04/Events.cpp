#using <mscorlib.dll>
using namespace System;

__delegate void SayHandler(String *name);

__gc class EventSource
{
public:
    __event SayHandler* OnSay;

    void Say(String *name)
    {
        OnSay(name);
    }
};

__gc class EventReceiver1
{
    EventSource *source;
public:

    EventReceiver1(EventSource *src)
    {
        if (src == 0)
            throw new ArgumentNullException(S"Must pass an Event Source");

        source = src;

        source->OnSay += new SayHandler(this, &EventReceiver1::SayHello);
        source->OnSay += new SayHandler(this, &EventReceiver1::SayStuff);
    }

    void RemoveStuff()
    {
        source->OnSay -= new SayHandler(this, &EventReceiver1::SayStuff);
    }

    void SayHello(String *name)
    {
        Console::Write(S"Hello there ");
        Console::WriteLine(name);
    }

    void SayStuff(String *name)
    {
        Console::Write(S"Nice weather we are having. Right, ");
        Console::Write(name);
        Console::WriteLine(S"?");
    }
};

__gc class EventReceiver2
{
    EventSource *source;
public:

    EventReceiver2(EventSource *src)
    {
        if (src == 0)
            throw new ArgumentNullException(S"Must pass an Event Source");

        source = src;

        source->OnSay += new SayHandler(this, &EventReceiver2::SayBye);
    }

    void SayBye(String *name)
    {
        Console::Write(S"Good-bye ");
        Console::WriteLine(name);
    }
};

Int32 main(void)
{
    EventSource *source = new EventSource();

    EventReceiver1 *receiver1 = new EventReceiver1(source);
    EventReceiver2 *receiver2 = new EventReceiver2(source);

    source->Say(S"Mr Fraser");

    Console::WriteLine(S"-------------------------------");

    receiver1->RemoveStuff();

    source->Say(S"Stephen");

    return 0;
}