#using <mscorlib.dll>

using namespace System;
using namespace System::Collections;

Int32 main(void)
{
    Queue *que = new Queue();
    Stack *stk = new Stack();

    String *entry[] = { S"First", S"Second", S"Third", S"Fourth" };

    Console::WriteLine(S"Queue\t\tStack");

    Console::WriteLine(S"** ON **");
    for (Int32 i = 0; i < entry->Count; i++)
    {
        que->Enqueue(entry[i]);
        stk->Push(entry[i]);  

        Console::WriteLine(S"{0}\t\t{1}", entry[i], entry[i]);
    }

    Console::WriteLine(S"\n** OFF **");
    while ((que->Count > 0) && (stk->Count > 0))
    {
        Console::WriteLine(S"{0}\t\t{1}", que->Dequeue(), stk->Pop());
    }

    que->Clear();
    stk->Clear();

    Console::WriteLine(S"\n");
    return 0;
}