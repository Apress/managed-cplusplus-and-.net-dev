#using <mscorlib.dll>
#using <system.dll>

using namespace System;
using namespace System::Collections;
using namespace System::Collections::Specialized;

Int32 main(void)
{
    StringCollection &strcol = *new StringCollection();

    strcol.Add(S"The first String");

    String *tmpstr[] = {S"Third", S"Fourth" };
    strcol.AddRange(tmpstr);

    strcol.Insert(1, S"Second");

    strcol.Item[0] = S"First";

    StringEnumerator *strenum = strcol.GetEnumerator();
    while ( strenum->MoveNext())
    {
        Console::WriteLine(strenum->Current);
    }

    Console::WriteLine(S"");
    return 0;
}