#using <mscorlib.dll>
#using <system.dll>

using namespace System;
using namespace System::Collections;
using namespace System::Collections::Specialized;

Int32 main(void)
{
    ListDictionary *ldict = new ListDictionary();

    ldict->Add(S"A", S"First");
    ldict->Add(S"B", S"Second");
    ldict->Add(S"C", S"Third");
    ldict->Item[S"D"] = S"Fourth";

    try {
        ldict->Add(S"C", S"Third Replaced");
    }
    catch (ArgumentException *e)
    {
        Console::WriteLine(S"ldict->Add(S\"C\", S\"Third Replaced\");");
        Console::WriteLine(S"Throws exception: {0}", e->Message);
    }
    ldict->Item[S"B"] = S"Second Replaced";

    Console::WriteLine(S"\nEnumerate");
    IEnumerator *keys = ldict->Keys->GetEnumerator();
    IEnumerator *vals = ldict->Values->GetEnumerator();
    while ( keys->MoveNext() && vals->MoveNext())
    {
        Console::WriteLine(S"{0}\t\t{1}", keys->Current, vals->Current);
    }

    Console::WriteLine(S"\n");
    return 0;
}