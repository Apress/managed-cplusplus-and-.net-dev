#using <mscorlib.dll>

using namespace System;
using namespace System::Collections;

Int32 main(void)
{
    ArrayList *alist = new ArrayList();
    alist->Add(S"One");
    alist->Add(S"-");
    alist->Item[1] = S"Three";

    alist->Insert(1, S"Two");

    String* morenums[] = {S"Four", S"Five"};

    alist->AddRange(dynamic_cast<Array*>(morenums));

    alist->Reverse();

    Console::WriteLine(S"*** The ArrayList ***");
    for (Int32 i = 0; i < alist->Count; i++)
    {
        Console::Write(S"{0} ", alist->Item[i]);
    }

    Console::WriteLine(S"\n\nCapacity is: {0}", alist->Capacity.ToString());

    alist->Capacity = 10;
    Console::WriteLine(S"New capacity is: {0}", alist->Capacity.ToString());

    Console::WriteLine(S"Count is: {0}", alist->Count.ToString());

    alist->Sort();
    
    Int32 indx = alist->BinarySearch(S"Four");
    Console::WriteLine(S"Four found at index: {0}", indx.ToString());

    Boolean fnd = alist->Contains(S"One");
    Console::WriteLine(S"ArrayList contains a 'One': {0}", fnd.ToString());

    Console::WriteLine();
    return 0;
}