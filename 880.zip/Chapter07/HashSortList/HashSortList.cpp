 #using <mscorlib.dll>

using namespace System;
using namespace System::Collections;

Int32 main(void)
{
    Hashtable *hash  = new Hashtable();
    SortedList *sort = new SortedList();

    String *keys[]  = { S"B", S"A", S"C", S"D" };
    String *skeys[] = { S"A", S"B", S"C", S"D" };
    String *values[] = { S"moose", S"zebra", S"frog", S"horse" };

    for (Int32 i = 0; i < keys->Count; i++)
    {
        hash->Add(keys[i], values[i]);
        sort->Add(keys[i], values[i]);
    }

    Console::WriteLine(S"Hashtable\tSortedList");

    Console::WriteLine(S"By indexed property");
    for (Int32 i = 0; i < hash->Count; i++)
    {
        Console::WriteLine(S"{0} {1}\t\t{2} {3}", skeys[i], 
            hash->Item[skeys[i]], skeys[i], sort->Item[skeys[i]]);
    }

    Console::WriteLine(S"\nBy index");
    for (Int32 i = 0; i < sort->Count; i++)
    {
        Console::WriteLine(S"N/A\t\t{0} {1}", __box(i), sort->GetByIndex(i));
    }

    Console::WriteLine(S"\nBy enumerator");
    IDictionaryEnumerator *enum1 = hash->GetEnumerator();
    IDictionaryEnumerator *enum2 = sort->GetEnumerator();
    while ( enum1->MoveNext() && enum2->MoveNext())
    {
        Console::Write(S"{0} {1}\t\t", enum1->Key, enum1->Value);
        Console::WriteLine(S"{0} {1}", enum2->Key, enum2->Value);
    }

    Console::WriteLine(S"\nEnumerate Keys");
    IEnumerator *keys1 = hash->Keys->GetEnumerator();
    IEnumerator *keys2 = sort->Keys->GetEnumerator();
    while ( keys1->MoveNext() && keys2->MoveNext())
    {
        Console::Write(S"{0}\t\t", keys1->Current);
        Console::WriteLine(S"{0}", keys2->Current);
    }

    Console::WriteLine(S"\nEnumerate Values");
    IEnumerator *vals1 = hash->Values->GetEnumerator();
    IEnumerator *vals2 = sort->Values->GetEnumerator();
    while ( vals1->MoveNext() && vals2->MoveNext())
    {
        Console::Write(S"{0}\t\t", vals1->Current);
        Console::WriteLine(S"{0}", vals2->Current);
    }

    Console::WriteLine(S"\nContains a Key 'A' and 'Z'");
    Console::WriteLine(S"{0}\t\t{1}", __box(hash->Contains(S"A")), 
                                      __box(sort->Contains(S"A"))); 
    Console::WriteLine(S"{0}\t\t{1}", __box(hash->ContainsKey(S"Z")), 
                                      __box(sort->ContainsKey(S"Z"))); 

    Console::WriteLine(S"\nContains a Value 'frog' and 'cow'");
    Console::WriteLine(S"{0}\t\t{1}", __box(hash->ContainsValue(S"frog")), 
                                      __box(sort->ContainsValue(S"frog"))); 
    Console::WriteLine(S"{0}\t\t{1}", __box(hash->ContainsValue(S"cow")), 
                                      __box(sort->ContainsValue(S"cow"))); 

    Console::WriteLine(S"\n\t\t'B' key index: {0}", 
        __box(sort->IndexOfKey(S"B")));

    Console::WriteLine(S"\t\t'frog' value index: {0}", 
        __box(sort->IndexOfValue(S"frog")));

    return 0;
}
