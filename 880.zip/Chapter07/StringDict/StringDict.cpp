#using <mscorlib.dll>
#using <system.dll>

using namespace System;
using namespace System::Collections;
using namespace System::Collections::Specialized;

Int32 main(void)
{
    StringDictionary &strdict = *new StringDictionary();

    strdict.Add(S"Dog", S"Four leg, hydrant loving, barking, mammal");
    strdict.Add(S"Frog", S"Green, jumping, croaking, amphibian");

    strdict.Item[S"Crocodile"] = S"Ugly, boot origin, snapping, reptile";

    ArrayList *alist = new ArrayList();
    alist->AddRange(strdict.Keys);
    alist->Sort();

    for (Int32 i = 0; i < alist->Count; i++)
    {
        Console::WriteLine(S"{0,10}:\t{1}", alist->Item[i], 
            strdict.Item[dynamic_cast<String*>(alist->Item[i])]);
    }

    Console::WriteLine(S"");
    return 0;
}