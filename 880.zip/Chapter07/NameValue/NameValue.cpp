#using <mscorlib.dll>
#using <system.dll>

using namespace System;
using namespace System::Collections::Specialized;

Int32 main(void)
{
    NameValueCollection &nvCol = *new NameValueCollection();

    nvCol.Add(0, S"void");

    nvCol.Set(S"Flower", S"Rose");

    nvCol.Add(S"Animal", S"Dog");
    nvCol.Add(S"Animal", S"Cat");
    nvCol.Add(S"Animal", S"Cow");

    nvCol.Add(S"Fruit", S"Apple");
    nvCol.Add(S"Fruit", S"Pear");
    nvCol.Add(S"Fruit", S"Peach");


    String *keys[] = nvCol.AllKeys;

    Console::WriteLine(S"Key\t\tValues");
    for (Int32 i = 0; i < keys->Count; i++)
    {
        String *vals[] = nvCol.GetValues(keys[i]);

        Console::WriteLine(S"{0}:\t\t{1}", keys[i], vals[0]);
        for (Int32 j = 1; j < vals->Count; j++)
        {
            Console::WriteLine(S"\t\t{0}", vals[j]);
        }
    }

    Console::WriteLine(S"------ Index Lookups ------");
    Console::WriteLine(S"Key @[1]:\t{0}", nvCol.GetKey(1));
    Console::WriteLine(S"Values @[3]:\t{0}", nvCol.Item[3]);


    nvCol.Remove(0);

    nvCol.Item[S"Fruit"] = S"Plum";

    nvCol.Set(S"Animal", S"Deer");
    nvCol.Add(S"Animal", S"Ape");

    keys = nvCol.AllKeys;

    Console::WriteLine(S"--------- Updated ---------");
    for (Int32 i = 0; i < keys->Count; i++)
    {
        Console::WriteLine(S"{0}:\t\t{1}", keys[i], nvCol.Get(keys[i]));
    }
    return 0;
}