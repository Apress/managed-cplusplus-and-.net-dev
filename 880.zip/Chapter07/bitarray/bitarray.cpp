#using <mscorlib.dll>

using namespace System;
using namespace System::Collections;

__gc class ForEach
{
    IEnumerator *enumerator;
    IEnumerable *collection;

public:
    Boolean foreach (Object **out, IEnumerable *collection)
    {
        if (this->collection != collection)
        {
            this->collection = collection;
            this->enumerator = collection->GetEnumerator();
        }

        Boolean end = this->enumerator->MoveNext();

        if (end)
            *out = this->enumerator->Current;
        else
            this->enumerator->Reset();

        return end;
    }
};

void Print( BitArray *barray, String *desc)
{
    ForEach &loop = *new ForEach();
    Object *val;

    Console::WriteLine(desc);

    Int32 i = 0;
    while ( loop.foreach( &val, /*in*/ barray ))
    {
        Console::Write(S"{0} ", val);
        i++;
        if (i > 7)
        {
            Console::WriteLine(S"");
            i = 0;
        }
    }
    Console::WriteLine(S"");
}

Int32 main(void)
{
    BitArray *barray1 = new BitArray( 8, true );
    Print(barray1, S"BitArray( 8, true );");

    barray1->Item[1] = false;
    barray1->Item[4] = false;
    barray1->Not();
    Print(barray1, S"Modified bit 1&4 then Not");

    BitArray *barray2 = new BitArray( 8, true );
    barray2->And(barray1);
    Print(barray2, S"And with BitArray( 8, true )");

    barray2->SetAll(true);
    barray2->Or(barray1);
    Print(barray2, S"Or with BitArray( 8, true )");

    barray2->SetAll(true);
    barray2->Xor(barray1);
    Print(barray2, S"Xor with BitArray( 8, true )");

    Console::WriteLine(S"");

    Byte bytes[] = { 0x55, 0xAA };
    BitArray *barray3 = new BitArray( bytes );
    Print(barray3, S"BitArray(0x55, 0xAA);");

    Console::WriteLine(S"Item[0]={0}", __box(barray3->Item[0]));
    Console::WriteLine(S"Item[8]={0}", __box(barray3->Item[8]));

    Console::WriteLine(S"");
    return 0;
}