#using <mscorlib.dll>

using namespace System;
using namespace System::Collections;

public __gc class ForEach
{
    IEnumerator *enumerator;
    IEnumerable *collection;

public:
    ForEach()
    {
        enumerator = 0;
        collection = 0;
    }

    Boolean foreach (Object **out, IEnumerable *collection)
    {
        if (this->collection != collection)
        {
            this->collection = collection;
            enumerator = collection->GetEnumerator();
        }

        Boolean end = enumerator->MoveNext();

        if (end)
            *out = enumerator->Current;
        else
            enumerator->Reset();

        return end;
    }
};

void SimpleForEach()
{
    Int32 ints[] = { 1, 2, 3, 5, 7, 11 };
    ForEach &loop = *new ForEach(); 
    Object *val;

    Console::WriteLine(S"Simple foreach");
    while ( loop.foreach( &val, /*in*/ dynamic_cast<Array*>(ints)) )
    {
        Console::Write(S"{0} ", val);
    }

    Console::WriteLine(S"\n");
}

void ImbeddedForEach()
{
    Int32 ints[] = { 1, 2, 3, 4, 5};
    ArrayList *nums = new ArrayList(5);
    for (Int32 i = 0; i < 5; i++)
    {
        nums->Add(__box((Char)(i+65)));
    }

    ForEach &loopOuter = *new ForEach(); 
    ForEach &loopInner = *new ForEach(); 
    Object *val1, *val2;

    Console::WriteLine(S"Imbedded foreach");

    Console::WriteLine(S"Outer foreach");
    while ( loopOuter.foreach( &val1, /*in*/ nums) )
    {
        Console::WriteLine(val1);
        Console::Write(S"\tInner foreach\n\t");
        while ( loopInner.foreach( &val2, /*in*/ (Array*)ints ))
        {
            Console::Write(S"{0} ", val2);
        }
        Console::WriteLine();
    }
}

Int32 main(void)
{
    SimpleForEach();
    ImbeddedForEach();

    return 0;
}
