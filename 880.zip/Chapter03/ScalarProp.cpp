#using <mscorlib.dll>
using namespace System;

__value struct ScalarProp
{
    // Write only property
    __property void set_Name(String *name)
    {
        _name = name;
    }

    // Ready only property
    __property String *get_Description()
    {
        return String::Concat(_name, S" ", _desc);
    }

    // Read/write validated parameter
    __property void set_Number(Int32 num)
    {
        if (num < 1)
            num = 1;
        else if (num > 10)
            num = 10;
            
        _num = num;
    }
    __property Int32 get_Number()
    {
        return _num;
    }

    ScalarProp()
    {
        _name = S"Blank Name";
        _desc = S"Scalar Property";
    }
private:
    String *_name;
    String *_desc;
    Int32   _num;
};

Int32 main(void)
{
    ScalarProp sp;

    sp.Name = S"The Struct";

    Console::WriteLine(sp.Description);

    sp.Number = 20;    // Will be changed to 10
    Console::WriteLine(sp.Number);

    sp.Number = -5;    // Will be changed to 1
    Console::WriteLine(sp.Number);

    sp.Number = 6;    // Will not change
    Console::WriteLine(sp.Number);

    return 0;
}
