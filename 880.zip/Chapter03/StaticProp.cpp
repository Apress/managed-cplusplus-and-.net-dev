#using <mscorlib.dll>
using namespace System;

__gc class StaticProp
{
    static String* _name;

public:
    __property static void set_Name (String* name)
    {
        _name = name;
    }
    __property static String* get_Name ()
    {
        return _name;
    }
};

Int32 main(void)
{
    StaticProp::Name = S"Static Property";

    Console::WriteLine(StaticProp::Name);
    return 0;
}