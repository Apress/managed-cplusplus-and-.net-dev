#using <mscorlib.dll>
using namespace System;

__gc class Square
{
public:
    Int32 Area()
    {
        return Dims * Dims;
    }

    Int32 Dims;
};

__gc class Cube : public Square
{
public:
    Int32 Volume()
    {
        return Area() * Dims;
    }
};

int main(void)
{
    Cube *cube = new Cube(); 
    cube->Dims = 3;

    Console::WriteLine(cube->Dims); 
    Console::WriteLine(cube->Area());
    Console::WriteLine(cube->Volume());

    return 0;
}
