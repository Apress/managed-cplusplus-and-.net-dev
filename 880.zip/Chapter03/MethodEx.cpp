#using <mscorlib.dll>
using namespace System;

__gc class MethodEx
{
public:
    void printPublic(Int32 num)
    {
        for (Int32 i = 0; i < num; i++)
        {
            Console::WriteLine( S"Public" );
        }
        printProtected(num/2);
    }
protected:
    void printProtected(Int32 num)
    {
        for (Int32 i = 0; i < num; i++)
        {
            Console::WriteLine( S"Protected" );
        }
        printPrivate(num/2);
    }
private:
    void printPrivate(Int32 num)
    {
        for (Int32 i = 0; i < num; i++)
        {
            Console::WriteLine( S"Private" );
        }
    }
};

Int32 main()
{
    MethodEx &ex = *new MethodEx();

    ex.printPublic(4);
    // ex.printProtected(4);  // Error can not access
    // ex.printPrivate(4);    // Error can not access
}
