#using <mscorlib.dll>
using namespace System;

__abstract __gc class AbstractExClass
{
protected:
    Int32 AbstractVar;
    AbstractExClass(Int32 val): AbstractVar(val) {}
public:
    virtual void Method1() = 0;  // unimplemented method
    virtual void Method2() = 0;  // unimplemented method
    void Method3()
    {
        Console::WriteLine(AbstractVar.ToString());
    }
};

__abstract __gc class MidAbstractExClass : public AbstractExClass
{
public:
    __sealed void Method1()
    {
        Console::WriteLine((AbstractVar * 3).ToString());
    }
protected:
    MidAbstractExClass(Int32 val) : AbstractExClass(val) {}
};

__gc class DerivedExClass : public MidAbstractExClass
{
public:
    DerivedExClass(Int32 val) : MidAbstractExClass(val) {}
    void Method2()
    {
        Console::WriteLine((AbstractVar * 2).ToString());
    }
};

void testMethod(AbstractExClass &aec)
{
    aec.Method1();
    aec.Method2();
    aec.Method3();
}

Int32 main(void)
{
    AbstractExClass &Ab1 = *new DerivedExClass(5);
    Ab1.Method1();
    Ab1.Method2();
    Ab1.Method3();

    AbstractExClass &Ab2 = *new DerivedExClass(6);
    testMethod(Ab2);

    DerivedExClass *dc = new DerivedExClass(7);
    testMethod(*dc);

    return 0;
}