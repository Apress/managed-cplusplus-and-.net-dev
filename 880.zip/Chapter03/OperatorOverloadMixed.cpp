#using <mscorlib.dll>
using namespace System;

__value struct N 
{
   Int32 i;
public:
    N(Int32 x) { i = x; }
    static bool op_GreaterThan(N n, Int32 v)  // maps to operator >
    {
        return n.i > v;
    }
    static bool op_GreaterThan(Int32 v, N n)  // maps to operator >
    {
        return v > n.i;
    }
};
 
Int32 main(void)
{
   N n(5);

   if ( n > 6 )
       Console::WriteLine(S"Greater than");
   else
       Console::WriteLine(S"Less than or Equal");

   if ( 6 > n )
       Console::WriteLine(S"Greater than");
   else
       Console::WriteLine(S"Less than or Equal");

    return 0;

}
