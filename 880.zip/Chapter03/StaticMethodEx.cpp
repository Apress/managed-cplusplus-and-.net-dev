#using <mscorlib.dll>
using namespace System;

__gc class StaticTest
{
private:
    static Int32 x = 42;
public:
   static Int32 get_x()
   {
      return x;
   }
};

Int32 main()
{
    Console::WriteLine ( StaticTest::get_x() );

    return 0;
}
