#using <mscorlib.dll>
using namespace System;


__gc class M 
{
   Int32 i;
public:
    M(Int32 x) { i = x; }
    static bool op_Inequality(M &m1, M &m2)  // maps to operator!=
    {
        Console::WriteLine(S"In op_Inequality");
        return m1.i != m2.i;
    }

    static bool op_Equality(M &m1, M &m2)  // maps to operator==
    {
        Console::WriteLine(S"In op_Equality");
        return m1.i == m2.i;
    }
};

Int32 main(void)
{
    M *m1 = new M(5);
    M *m2 = new M(5);
    M *m3 = new M(10);

   if ( M::op_Inequality(*m2, *m3) )
       Console::WriteLine(S"Don't Equal");
   else
       Console::WriteLine(S"Equal");

   if ( *m1 != *m2 )
       Console::WriteLine(S"Don't Equal");
   else
       Console::WriteLine(S"Equal");

   if ( M::op_Equality(*m2, *m3) )
       Console::WriteLine(S"Equal");
   else
       Console::WriteLine(S"Don't Equal");

   if ( *m1 == *m2 )
       Console::WriteLine(S"Equal");
   else
       Console::WriteLine(S"Don't Equal");

    return 0;
}
