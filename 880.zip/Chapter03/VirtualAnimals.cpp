#using <mscorlib.dll>
using namespace System;

__gc class Animal
{
public:
    virtual void Speak ()
    {
        Console::WriteLine(S"Mysterious Silence");
    }
};

__gc class Dog : public Animal
{
public:
    virtual void Speak ()
    {
        Console::WriteLine(S"Woof");
    }
};

__gc class Puppy : public Dog
{
public:
    virtual void Speak ()
    {
        Console::WriteLine(S"Yip Yip");
    }
};

__gc class Cat : public Animal
{
public:
    virtual void Speak ()
    {
        Console::WriteLine(S"Meow");
    }
};

Int32 main(void)
{
    Animal *a[] = new Animal*[4]; // Array of class pointers
    a[0] = new Cat(); 
    a[1] = new Dog(); 
    a[2] = new Puppy(); 
    a[3] = new Animal(); 

    for (Int32 i = 0; i < a->Count; i++)
    {
        a[i]->Speak();
    }

    return 0;
}