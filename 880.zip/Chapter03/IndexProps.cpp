#using <mscorlib.dll>
using namespace System;

__gc class Student 
{
   String *_name;
   Int32   _grade;

public:
   Student(String * s, Int32 g) 
   {
      _name = s; 
      _grade = g;
   }
   __property String *get_Name() 
   {
      return _name;
   }
   __property Int32 get_Grade() 
   {
      return _grade;
   }
};

__gc class Course 
{
   __gc struct StuList 
   {
      Student *stu;
      StuList *next;
   };
   StuList *pStu;
   static StuList *ReportCards = 0;

public:
   __property Student &get_ReportCard(String * n) 
   { 
      for(pStu = ReportCards; pStu && (pStu->stu->Name != n); pStu = pStu->next)
         ;
      if (pStu != 0) 
         return *pStu->stu; 
      else 
         return *new Student(0,0);  // empty student
   }

   __property void set_ReportCard(String* n, Student& s) 
   { 
      for(pStu = ReportCards; pStu && (pStu->stu->Name != n); pStu = pStu->next)
         ;
      if (pStu == 0) 
      {
         StuList *stuList = new StuList; 
         stuList->stu = &s; 
         stuList->next = ReportCards; 
         ReportCards = stuList;
      }
   }
};

Int32 main() 
{
   Course  &EnglishLit = *new Course;
   Student &Stephen    = *new Student(S"Stephen", 95);
   Student &Sarah      = *new Student(S"Sarah", 98);

   EnglishLit.ReportCard[ S"Stephen" ] = Stephen;  // index String lit
   EnglishLit.ReportCard[ Sarah.Name ] = Sarah;    // index String*

   Console::WriteLine(EnglishLit.ReportCard[ Stephen.Name ].Grade);
   Console::WriteLine(EnglishLit.ReportCard[ S"Sarah" ].Grade);

   return 0;
}
