#using <mscorlib.dll>
using namespace System;

__gc class Test 
{
public:
    Int32 i; 
    Test() 
    { 
        i = 0; 
    }
};

void incr (int *i)   // unmanaged function
{
    (*i)++;
}

Int32 main () 
{
    Test __pin *ptrTest = new Test; // ptrTest is a pinned pointer

    incr( &ptrTest->i);             // pointer to managed data passed as actual
                                    // parameter of unmanaged function call
    
    Console::WriteLine ( ptrTest->i );
}
