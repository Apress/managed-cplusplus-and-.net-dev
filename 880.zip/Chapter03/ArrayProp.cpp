#using <mscorlib.dll>
using namespace System;


__gc class ArrayProp
{
    Int32 _numArray[];
public:
    __property Int32 get_NumArray() []
    {
        return _numArray;
    }

    __property void set_NumArray ( Int32 NumArray[] )
    {
        _numArray = NumArray;
    }
    
};

Int32 main() 
{
   ArrayProp &array = *new ArrayProp;

   array.NumArray = new Int32[5];

   for ( int i = 0 ; i < array.NumArray->Count ; ++i )
      array.NumArray[i] = i;

   for ( int i = 0 ; i < array.NumArray->Count ; ++i )
       Console::WriteLine(array.NumArray[i].ToString());
}

