#using <mscorlib.dll>
using namespace System;

__gc class Square
{
public:
    Square(Int32 v)
    {
        Dims = v;
    }

    Int32 Area()
    {
        return Dims * Dims;
    }

    Int32 Dims;
};

int main(void)
{
    Square *sqr1 = new Square( 2 );           // Pointer
    Square &sqr2 = *new Square( 3 );          // Reference

    Console::WriteLine( sqr1->Dims );         // Pointer
    Console::WriteLine( sqr1->Area() );

    Console::WriteLine( sqr2.Dims );          // Reference
    Console::WriteLine( sqr2.Area() );

    return 0;
}
