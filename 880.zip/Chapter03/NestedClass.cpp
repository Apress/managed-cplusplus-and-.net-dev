#using <mscorlib.dll>
using namespace System;

__gc class SurroundClass
{
protected:
    __gc class NestedClass      // Declaration of the nested class
    {
    public:
        Int32 publicMember;
    protected:
        Int32 protectedMember;
    private:
        Int32 privateMember;
    };

    NestedClass &protectedNC;   // protected variable reference to NestedClass

private:
    NestedClass &privateNC;     // private variable reference to NestedClass

public:
    NestedClass &publicNC;      // public variable reference to NestedClass

    // Constructor for SurroundClass
    // Notice the initializer list declaration of the reference member variable
    SurroundClass() : publicNC(*new NestedClass),
                      protectedNC(*new NestedClass),
                      privateNC(*new NestedClass)
    {}

    // A member showing how to access NestedClass within SurroundClass
    // Notice only public member varibles of the nested class are accessed
    // The private an protected are hidden
    void method()  
    {
        Int32 x;

        NestedClass &nc1 = *new NestedClass();  // Declared another reference 
                                                // NestedClass
        x = nc1.publicMember;        // Accessing new NestedClass variable

        x = publicNC.publicMember;   // Accessing public NestedClass variable
        x = protectedNC.publicMember;// Accessing protected NestedClass variable
        x = privateNC.publicMember;  // Accessing private NestedClass variable
    }
};

// A inhertied class showing how to access NestedClass within a member method
// Notice only public and protected NestedClass are accessed
// The private is hidden
__gc class inheritSurroundClass : public SurroundClass
{
public:
    void method()
    {
        Int32 x;

        NestedClass &nc1 = *new NestedClass(); // can access because NestedClass 
                                               // declaration protected
        x = nc1.publicMember;

        x = publicNC.publicMember;
        x = protectedNC.publicMember;
    }
};

// The main function shows how to access NestedClass from outside SurroundClass
// inhertance tree
// Notice only the public NestedClass reference is accessible
Int32 main()
{
    SurroundClass &sc = *new SurroundClass();
    Int32 x = sc.publicNC.publicMember;
    return 0;
}
