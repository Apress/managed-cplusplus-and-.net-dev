#using <mscorlib.dll>
using namespace System;

__gc __interface Interface1
{
    virtual void Method1() = 0;
    virtual void Method2() = 0;
};

__gc __interface Interface2
{
    virtual void Method3() = 0;
    __property String* get_X();
    __property void  set_X(String*);
};

__gc class Base
{
public:
    void MethodBase()
    {
        Console::WriteLine(S"MethodBase()");
    }
};

__gc class DerivedClass : public Base, public Interface1, public Interface2
{
    String* _x;
public:
    
    __property String* get_X()
    {
        return _x;
    }
    __property void  set_X(String* x)
    {
        _x = x;
    }

    void Method1()
    {
        Console::WriteLine(S"Method1()");
    }
    void Method2()
    {
        Console::WriteLine(S"Method2()");
    }
    void Method3()
    {
        Console::WriteLine(S"Method3()");
    }
    void Print()
    {
        MethodBase();
        Method1();
        Method2();
        Method3();
    }
};

Int32 main(void)
{
    DerivedClass &dc = *new DerivedClass;

    dc.X = S"Start'n Up";
    Console::WriteLine(dc.X);

    dc.Print();

    return 0;
}