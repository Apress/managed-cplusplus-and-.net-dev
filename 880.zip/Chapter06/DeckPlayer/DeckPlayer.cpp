#include "stdafx.h"

using namespace System;
using namespace Cards;

Int32 main(void)
{
    Deck &deck = *new Deck;

    deck.Shuffle();

    Card *card;
    Int32 i = 0;
    while ((card = deck.Deal()) != 0)
    {
        if (i < 6)
        {
            Console::Write(S"{0}\t", card->ToString());
            i++;
        }
        else
        {
            Console::WriteLine(S"{0}\n", card->ToString());
            i = 0;
        }
    }
    Console::WriteLine(S"\n");

    return 0;
}
