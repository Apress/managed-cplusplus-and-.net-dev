#using <mscorlib.dll>

using namespace System;
using namespace System::IO;

Int32 main(void)
{
    Byte data[] = { 'T', 'h', 'i', 's', ' ', 'i', 's', ' ', 'a', 
                    ' ', 't', 'e', 's', 't', '!', '\r', '\n', 'T', 
                    'h', 'i', 's', ' ', 'i', 's', ' ', 'o', 'n',
                    'l', 'y', ' ', 'a', ' ', 't', 'e', 's', 't', '.','\r', '\n' };
    
    MemoryStream *ms = new MemoryStream();
    ms->Capacity = 40;

    for (Int32 i = 0; i < data.Count-5; i += 5)
    {
        ms->Write(data, i, 5);
    }

    for (Int32 i = data.Count-4; i < data.Count; i++)
    {
        ms->WriteByte(data[i]);
    }

    Byte ba[] = ms->GetBuffer();
    for (Int32 i = 0; i < ba.Count; i++)
    {
        Console::Write((Char)ba[i]);
    }
    Console::WriteLine(S"");

    FileStream *fs = File::OpenWrite(S"file.dat");
    
    ms->WriteTo(fs);

    fs->Close();
    ms->Close();

    return 0;
}