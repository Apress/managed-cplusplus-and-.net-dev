#using <mscorlib.dll>

using namespace System;
using namespace System::IO;
using namespace System::Text;


Int32 main( Int32 argc, SByte __nogc *argv[] )
{
    if (argc <= 1)
    {
        Console::WriteLine(S"Usage: DirInfo <Directory>");
        return -1;
    }

    StringBuilder *tmppath = new StringBuilder();

    for (Int32 i = 1; i < argc; i++)
    {
        tmppath->Append(argv[i]);
        tmppath->Append(S" ");
    }

    String *path = tmppath->ToString()->Trim();

    DirectoryInfo *dir = new DirectoryInfo(path);

    if (!dir->Exists)
    {
        Console::WriteLine(S"Directory Not Found");
        return -1;
    }

    Console::WriteLine(S"Name:       {0}", dir->FullName);

    Console::WriteLine(S"Created:    {0} {1}", 
        dir->CreationTime.ToShortDateString(),
        dir->CreationTime.ToLongTimeString());

    Console::WriteLine(S"Accessed:   {0} {1}", 
        dir->LastAccessTime.ToShortDateString(),
        dir->LastAccessTime.ToLongTimeString());

    Console::WriteLine(S"Updated:    {0} {1}", 
        dir->LastWriteTime.ToShortDateString(),
        dir->LastWriteTime.ToLongTimeString());

    Console::WriteLine(S"Attributes: {0}", 
        __box(dir->Attributes)->ToString());

    Console::WriteLine(S"Sub-Directories:"); 

    DirectoryInfo *subDirs[] = dir->GetDirectories();
    if (subDirs->Count == 0)
        Console::WriteLine(S"\tNone."); 
    else
    {
        for (Int32 i = 0; i < subDirs->Count; i++)
        {
            Console::WriteLine(S"\t{0}", subDirs[i]->Name); 
        }
    }

    Console::WriteLine(S"Files:"); 

    FileInfo *files[] = dir->GetFiles();
    if (files->Count == 0)
        Console::WriteLine(S"\tNone."); 
    else
    {
        for (Int32 i = 0; i < files->Count; i++)
        {
            Console::WriteLine(S"\t{0}", files[i]->Name); 
        }
    }

    return 0;
}