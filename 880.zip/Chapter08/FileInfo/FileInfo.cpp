#using <mscorlib.dll>

using namespace System;
using namespace System::IO;
using namespace System::Text;

Int32 main( Int32 argc, SByte __nogc *argv[] )
{
    if (argc <= 1)
    {
        Console::WriteLine(S"Usage: FileInfo <File>");
        return -1;
    }

    StringBuilder *tmpfile = new StringBuilder();

    for (Int32 i = 1; i < argc; i++)
    {
        tmpfile->Append(argv[i]);
        tmpfile->Append(S" ");
    }

    String *strfile = tmpfile->ToString()->Trim();

    FileInfo *fileinfo = new FileInfo(strfile);

    if (!fileinfo->Exists)
    {
        Console::WriteLine(S"File Not Found");
        return -1;
    }

    Console::WriteLine(S"Name:       {0}", fileinfo->FullName);

    Console::WriteLine(S"Created:    {0} {1}", 
        fileinfo->CreationTime.ToShortDateString(),
        fileinfo->CreationTime.ToLongTimeString());

    Console::WriteLine(S"Accessed:   {0} {1}", 
        fileinfo->LastAccessTime.ToShortDateString(),
        fileinfo->LastAccessTime.ToLongTimeString());

    Console::WriteLine(S"Updated:    {0} {1}", 
        fileinfo->LastWriteTime.ToShortDateString(),
        fileinfo->LastWriteTime.ToLongTimeString());

    Console::WriteLine(S"Length:     {0}", 
        __box(fileinfo->Length)->ToString());

    Console::WriteLine(S"Attributes: {0}", 
        __box(fileinfo->Attributes)->ToString());

    return 0;
}