#using <mscorlib.dll>

using namespace System;
using namespace System::IO;
using namespace System::Runtime::Serialization::Formatters::Binary;

__gc class Player
{
    String *Name;
    Int32   Strength;
    Boolean IsMale;
    DateTime CreateDate;

public:
    Player()
    {
    }

    Player (String *Name, Int32 Str, Boolean IsMale)
    {
        this->Name     = Name;
        this->Strength = Str;
        this->IsMale   = IsMale;
        this->CreateDate = DateTime::Now;
    }

    void Print()
    {
        Console::WriteLine(S"Name: {0} ({1})", Name, (IsMale ? S"M" : S"F"));
        Console::WriteLine(S"Str:  {0}", __box(Strength));
        Console::WriteLine(S"Date: {0}", CreateDate.ToString());
    }

    void Save(String *fname)
    {
        FileStream *fs = File::OpenWrite(fname);
        BinaryWriter *bw = new BinaryWriter(fs);

        bw->Write(Name);
        bw->Write(Strength);
        bw->Write(IsMale);

        // Due to multicultures this is a safe way of storing DateTimes
        bw->Write(CreateDate.Ticks);  

        bw->Close();
        fs->Close();
    }

    void Load(String *fname)
    {
        FileStream *fs = File::OpenRead(fname);
        BinaryReader *br = new BinaryReader(fs);

        Name     = br->ReadString();
        Strength = br->ReadInt32();
        IsMale   = br->ReadBoolean();

        // Due to multicultures this is a safe way of retrieving DateTimes
        CreateDate = DateTime( br->ReadInt64() );

        br->Close();
        fs->Close();
    }
};

Int32 main(void)
{
    Player *Joe = new Player(S"Joe", 10, true);
    Joe->Save(S"Player.dat");

    Console::WriteLine(S"Original Joe");
    Joe->Print();

    Player *JoeClone = new Player();
    JoeClone->Load(S"Player.dat");

    Console::WriteLine(S"\nCloned Joe");
    JoeClone->Print();

    return 0;
}