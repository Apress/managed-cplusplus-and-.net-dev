#using <mscorlib.dll>

using namespace System;
using namespace System::IO;

Int32 main(void)
{
    String *data[] = { S"This is ", S"a test!", S"This is only a test." };
    
    StreamWriter *sw = new StreamWriter(new FileStream(S"file.dat", 
                       FileMode::Create, FileAccess::Write, FileShare::None));

    for (Int32 i = 0; i < data.Count-1; i++)
    {
        sw->Write(data[i]);
    }
    sw->WriteLine(S"");

    sw->WriteLine(data[2]);

    sw->Close();

    StreamReader *sr = File::OpenText(S"file.dat");

    String *in = sr->ReadLine();
    Console::WriteLine(in);

    Console::WriteLine(sr->ReadToEnd());
    
    sw->Close();

    return 0;
}