#using <mscorlib.dll>
#using <system.runtime.serialization.formatters.soap.dll>

using namespace System;
using namespace System::IO;
using namespace System::Runtime::Serialization::Formatters::Soap;

[Serializable]
__gc class PlayerAttr
{
    Int32   Strength;
    Int32   Dexterity;
    Int32   Constitution;
    Int32   Intelligence;
    Int32   Wisdom;
    Int32   Charisma;

public:
    PlayerAttr(Int32 Str, Int32 Dex, Int32 Con, Int32 Int, Int32 Wis, Int32 Cha)
    {
        this->Strength     = Str;
        this->Dexterity    = Dex;
        this->Constitution = Con;
        this->Intelligence = Int;
        this->Wisdom       = Wis;
        this->Charisma     = Cha;
    }

    void Print()
    {
        Console::WriteLine(S"Str: {0}, Dex: {1}, Con {2}", 
            __box(Strength), __box(Dexterity), __box(Constitution));
        Console::WriteLine(S"Int: {0}, Wis: {1}, Cha {2}", 
            __box(Intelligence), __box(Wisdom), __box(Charisma));
    }
};

[Serializable]
__gc class Player
{
    String *Name;
    String *Race;
    String *Class;
    PlayerAttr *pattr;

public:
    Player (String *Name, String *Race, String *Class,
        Int32 Str, Int32 Dex, Int32 Con, Int32 Int, Int32 Wis, Int32 Cha)
    {
        this->Name  = Name;
        this->Race  = Race;
        this->Class = Class;
        this->pattr = new PlayerAttr(Str, Dex, Con, Int, Wis, Cha);
    }

    void Print()
    {
        Console::WriteLine(S"Name:  {0}", Name);
        Console::WriteLine(S"Race:  {0}", Race);
        Console::WriteLine(S"Class: {0}", Class);
        pattr->Print();
    }
};

Int32 main(void)
{
    Player *Joe = new Player(S"Joe", S"Human", S"Thief", 10, 18, 9, 13,10, 11);

    Console::WriteLine(S"Original Joe");
    Joe->Print();

    FileStream *plStream = File::Create(S"Player.xml");

    SoapFormatter *sf = new SoapFormatter();
    sf->Serialize(plStream, Joe);
    plStream->Close();

    plStream = File::OpenRead(S"Player.xml");

    Player *JoeClone = dynamic_cast<Player*>(sf->Deserialize(plStream));
    plStream->Close();

    Console::WriteLine(S"\nCloned Joe");
    JoeClone->Print();

    return 0;
}