#using <mscorlib.dll>
using namespace System;

Int32 main(void)
{
    // This is kind of neat. Boolean literals are objects too!
    Console::WriteLine ( true.ToString () );
    Console::WriteLine ( false.ToString () );
    return 0;
}
