#using <mscorlib.dll>
using namespace System;


__value struct Coord3D
{
    Double x;
    Double y;
    Double z;

    Coord3D (Double x, Double y, Double z)
    {
        this->x = x;
        this->y = y;
        this->z = z;
    }

    String *ToString()
    {
        return String::Format(S"{0},{1},{2}", x.ToString(), y.ToString(), z.ToString());
    }
};

int main(void)
{
    Coord3D coordA;
    Coord3D coordB(1,2,3);

    coordA = coordB;  // Assign is simply an =

    coordA.x += 5.5;  // Operations work just like usual
    coordA.y *= 2.7;
    coordA.z /= 1.3;

    Console::WriteLine(coordB.ToString());
    Console::WriteLine(coordA.x);
    Console::WriteLine(coordA.y);
    Console::WriteLine(coordA.z);

    return 0;
}