#using <mscorlib.dll>
using namespace System;

Int32 main(void)
{
    Single w = 123.456f;   // standard decimal notation
    Single x = 7890e3f;    // exponent notation
    Double y = 34525425432525764765.76476476547654; // too big will truncate
    Double z = 123456789012345e-300; // exponent will be reset

    Console::WriteLine( w ); // Write out Single
    Console::WriteLine( x ); // Write out Single with more zeros
    Console::WriteLine( y ); // Write out Double truncated
    Console::WriteLine( z ); // Write out Double shift back decimal

    return 0;
}
