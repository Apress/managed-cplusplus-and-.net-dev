#using <mscorlib.dll>
using namespace System;

Int32 main(void)
{
    Char a = L'A';        // character literal 'A'
    Char b = L'\x0041';   // Unicode notation also an 'A'

    Console::WriteLine ( a );
    Console::WriteLine ( b );

    return 0;
}