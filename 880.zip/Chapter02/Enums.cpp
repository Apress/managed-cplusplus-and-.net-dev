#using <mscorlib.dll>
using namespace System;

__value enum PrimeColors { Red, Blue, Yellow };

int main(void)
{
    PrimeColors color;

    color = PrimeColors::Blue;

    switch (color)
    {
        case PrimeColors::Red :
            Console::WriteLine(S"Red");
            break;
        case PrimeColors::Blue :
            Console::WriteLine(S"Blue");
            break;
        case PrimeColors::Yellow :
            Console::WriteLine(S"Yellow");
            break;
    }

    Console::WriteLine(__box(color)->ToString());

    return 0;
}