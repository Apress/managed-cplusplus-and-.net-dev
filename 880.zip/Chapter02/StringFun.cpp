#using <mscorlib.dll>
using namespace System;

Int32 main(void)
{
	// Create some strings
    String *s1 = S"This will ";
    String *s2 = S"be a ";
    String *s3 = S"String";
    Console::WriteLine(String::Concat(s1, s2, s3));

	// Create a copy, then concatenate new text
    String *s4 = s2;  
    s4 = String::Concat(s4, S"new ");
    Console::WriteLine(String::Concat(s1, s4, s3));

    // Replace stuff in a concatenated string
	String *s5 = String::Concat(s1, s2, s3)->Replace(S"i", S"*");
	Console::WriteLine(s5); 

	// Insert into a string
    String *s6 = s3->Insert(3, S"ange Str");
    Console::WriteLine(String::Concat(s1, s2, s6));

	// Remove text from strings
    s1 = s1->Remove(4, 5);  // remove ' will' from middle
    s2 = s2->Remove(0, 3);  // remove 'be ' from start
    Console::WriteLine(String::Concat(s1, S"is ", s2, s3));

    return 0;
}
