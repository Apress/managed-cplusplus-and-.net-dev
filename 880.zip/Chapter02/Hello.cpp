#using <mscorlib.dll>
using namespace System;

Int32 main(void)
{
    Console::WriteLine(S"Hello Managed World");

    return 0;
}