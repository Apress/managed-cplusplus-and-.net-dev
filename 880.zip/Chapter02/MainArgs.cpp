#using <mscorlib.dll>
using namespace System;

Int32 main(Int32 argc, SByte __nogc *argv[])
{
    Console::WriteLine(argc.ToString());
    for (int i = 0; i < argc; i++)
    {
        Console::WriteLine(new String(argv[i]));
    }
    return 0;
}