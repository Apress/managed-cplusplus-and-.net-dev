#using <mscorlib.dll>
using namespace System;

Int32 main(void)
{
    Int32 x;   // create a variable 
    Int32 *y;  // create a pointer to an Int32
    
    y = &x;	   // place the address of x in the pointer y
    *y = 50;   // place 50 at the address y points to
    Console::WriteLine(x);  // print out x. This should contain 50.

    return 0;
}