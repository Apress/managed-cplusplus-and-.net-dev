#using <mscorlib.dll>
using namespace System;

Int32 main(void)
{
    Boolean a = 18757;   // will give a warning but set to true
    Boolean b = 0;       // false
    Boolean c = true;    // obviously true
    Boolean d = false;   // obviously false

    Console::WriteLine( a );
    Console::WriteLine( b );
    Console::WriteLine( c );
    Console::WriteLine( d );
    return 0;
}