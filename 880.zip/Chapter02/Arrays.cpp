#using <mscorlib.dll>
using namespace System;

Int32 main(void)
{
    // Single dimension
    Int32 a[] = new Int32[4];
    String *b[] = new String*[4];

    for (Int32 i = 0; i < a->Count; i++)
    {
        a[i] = i;
    }

    for (Int32 i = 0; i < b->Count; i++)
    {
        b[i] = a[i].ToString();
    }

    for (Int32 i = 0; i < b->Count; i++)
    {
        Console::WriteLine(b[i]);
    }


    Console::WriteLine(S"");
    Array::Reverse(b);
    for (Int32 i = 0; i < b->Count; i++)
    {
        Console::WriteLine(b[i]);
    }

    // Multi dimension
    Int32 c[,] = new Int32[4,3];
    String *d[,] = new String*[4,3];

    for (Int32 x = 0; x < c->GetLength(0); x++)
    {
        for (Int32 y = 0; y < c->GetLength(1); y++)
        {
            c[x,y] = (x*10)+y;
        }
    }

    Console::WriteLine(S"");
    for (Int32 x = 0; x < d->GetLength(0); x++)
    {
        for (Int32 y = 0; y < d->GetLength(1); y++)
        {
            Console::Write(c[x,y]);
            Console::Write(S"\t");
        }
        Console::WriteLine();
    }

    return 0;
}