#using <mscorlib.dll>
using namespace System;

Int32 main(void)
{
    String *a = S"Managed String";
    String *b = L"Unicode String";
    String *c =  "Unmanaged String";

    Console::WriteLine(a);
    Console::WriteLine(b);
    Console::WriteLine(c);

    return 0;
}