#using <mscorlib.dll>
using namespace System;

Int32 main(void)
{
    Byte  w = 'F';             // Intialize using charater literal
    Int16 x(123);              // Intializing using Functional Notation
    Int32 y = 456789l;         // Decimal literal assigned
    Int64 z = 0x9876543210;    // Hex literal assigned

    Console::WriteLine( w );    // Write out a Byte
    Console::WriteLine( x );    // Write out a Int16
    Console::WriteLine( y );    // Write out a Int32
    Console::WriteLine( z );    // Write out a Int64
    Console::WriteLine( z.ToString("X") ); // Write out a Int64 in Hex

    return 0;
}
