#pragma once


namespace Invoking
{
    using namespace System;
    using namespace System::ComponentModel;
    using namespace System::Collections;
    using namespace System::Windows::Forms;
    using namespace System::Data;
    using namespace System::Drawing;
    using namespace System::Reflection;

    public __gc class Form1 : public System::Windows::Forms::Form
    {   
    public:
        Form1(void)
        {
            InitializeComponent();
        }
  
    protected:
        void Dispose(Boolean disposing)
        {
            if (disposing && components)
            {
                components->Dispose();
            }
            __super::Dispose(disposing);
        }
    private: System::Windows::Forms::ComboBox *  cbColor;
    private: System::Windows::Forms::Label *  lbColor;
    private: System::ComponentModel::Container * components;

    private: PropertyInfo *colors[];

        void InitializeComponent(void)
        {
            this->cbColor = new System::Windows::Forms::ComboBox();
            this->lbColor = new System::Windows::Forms::Label();
            this->SuspendLayout();
            // 
            // cbColor
            // 
            this->cbColor->Location = System::Drawing::Point(8, 16);
            this->cbColor->Name = S"cbColor";
            this->cbColor->Size = System::Drawing::Size(320, 24);
            this->cbColor->TabIndex = 0;
            this->cbColor->SelectedIndexChanged += new System::EventHandler(this, cbColor_SelectedIndexChanged);
            // 
            // lbColor
            // 
            this->lbColor->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
            this->lbColor->Location = System::Drawing::Point(8, 56);
            this->lbColor->Name = S"lbColor";
            this->lbColor->Size = System::Drawing::Size(320, 48);
            this->lbColor->TabIndex = 1;
            this->lbColor->Text = S"None";
            this->lbColor->TextAlign = System::Drawing::ContentAlignment::MiddleCenter;
            // 
            // Form1
            // 
            this->AutoScaleBaseSize = System::Drawing::Size(6, 15);
            this->ClientSize = System::Drawing::Size(336, 117);
            this->Controls->Add(this->lbColor);
            this->Controls->Add(this->cbColor);
            this->Name = S"Form1";
            this->Text = S"System Drawing Colors";
            this->Load += new System::EventHandler(this, Form1_Load);
            this->ResumeLayout(false);

        }   
    private: 
        System::Void Form1_Load(System::Object *  sender, System::EventArgs *  e)
        {
            Type* colorType = __typeof(Color);
            colors = colorType->GetProperties();

            for (Int32 i = 0; i < colors->Length; i++)
            {
                if (colors[i]->ToString()->IndexOf(S"System.Drawing.Color") >= 0)
                    cbColor->Items->Add(colors[i]->ToString());
            }
            cbColor->SelectedIndex = 0;
        }
    private: 
        System::Void cbColor_SelectedIndexChanged(System::Object *  sender, System::EventArgs *  e)
        {
            static Boolean alternateWrite = true;
            PropertyInfo *property = colors[cbColor->SelectedIndex];

            MethodInfo *PropMethod = property->GetGetMethod();

            lbColor->BackColor = *dynamic_cast<Color*>(PropMethod->Invoke(0,0));

            Assembly *assembly = Assembly::Load("Invoking");

            Type *type;
            if (alternateWrite)
                type = assembly->GetType("Invoking.Writer1");
            else
                type = assembly->GetType("Invoking.Writer2");

            alternateWrite = !alternateWrite;

            MethodInfo *ColorMethod = type->GetMethod("aColor");

            Object *writerInst = Activator::CreateInstance(type);

            Object *args[] = new Object*[1];
            args[0] = PropMethod->Invoke(0,0);

            lbColor->Text = dynamic_cast<String*>(ColorMethod->Invoke(writerInst, args));
        }
    };

    __gc class Writer1
    {
    public:
        String *aColor(Color *col)
        {
            return String::Format("[Writer 1] {0}", col->ToString());
        }
    };

    __gc class Writer2
    {
    public:
        String *aColor(Color *col)
        {
            return String::Format("[Writer 2] {0}", col->ToString());
        }
    };
}


