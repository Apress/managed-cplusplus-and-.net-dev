using namespace System;
using namespace System::Reflection;
using namespace System::Resources;
using namespace System::Threading;
using namespace System::Globalization;

Int32 main()
{
    Assembly *assembly = Assembly::GetExecutingAssembly();
    ResourceManager *rmgr = 
        new ResourceManager(S"MulticulturalConsole.Colors", assembly);

    Console::WriteLine(rmgr->GetObject(S"Color1"));
    Console::WriteLine(rmgr->GetObject(S"Color2"));
    Console::WriteLine(rmgr->GetObject(S"Color3"));
    Console::WriteLine(rmgr->GetObject(S"Color4"));

    Thread::CurrentThread->CurrentUICulture = new CultureInfo(S"fr-fr");

    Console::WriteLine(rmgr->GetObject(S"Color1"));
    Console::WriteLine(rmgr->GetObject(S"Color2"));
    Console::WriteLine(rmgr->GetObject(S"Color3"));
    Console::WriteLine(rmgr->GetObject(S"Color4"));

    return 0;
}