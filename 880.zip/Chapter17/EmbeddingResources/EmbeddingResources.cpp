using namespace System;
using namespace System::Collections;
using namespace System::Reflection;
using namespace System::Resources;

Int32 main()
{
    Console::WriteLine(S"*** ResourceReader ***");
    ResourceReader *rreader = new ResourceReader(S"Fruit.resources");
    IDictionaryEnumerator *denum = rreader->GetEnumerator();
    while (denum->MoveNext())
    {
        Console::WriteLine(S"{0} = {1}", denum->Key, denum->Value);
    }
    rreader->Close();

    ResourceManager *rmgr;
    
    Console::WriteLine(S"\n*** ResourceManager From File ***");
    rmgr = ResourceManager::CreateFileBasedResourceManager(S"Fruit", "", 0);
    Console::WriteLine(rmgr->GetString(S"Fruit1"));
    Console::WriteLine(rmgr->GetString(S"Fruit2"));
    Console::WriteLine(rmgr->GetString(S"Fruit3"));
    Console::WriteLine(rmgr->GetString(S"Fruit4"));

    Console::WriteLine(S"\n*** ResourceManager From Assembly ***");
    Assembly *assembly = Assembly::GetExecutingAssembly();
    rmgr = new ResourceManager(S"Fruit", assembly);
    Console::WriteLine(rmgr->GetObject(S"Fruit1"));
    Console::WriteLine(rmgr->GetObject(S"Fruit2"));
    Console::WriteLine(rmgr->GetObject(S"Fruit3"));
    Console::WriteLine(rmgr->GetObject(S"Fruit4"));

    return 0;
}