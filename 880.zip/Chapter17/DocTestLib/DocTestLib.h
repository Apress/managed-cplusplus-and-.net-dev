// DocTestLib.h

#pragma once

using namespace System;
using namespace Documentation;

namespace DocTestLib
{
    [Description(S"Stephen Fraser", 
        S"This is TestClass1 to test the documentation Attribute.")]
    [History(S"Stephen Fraser",
        S"Original Version.", ModifyDate=S"11/27/02")]
    [History(S"Stephen Fraser",
        S"Added DoesNothing Method to do nothing.")]
    public __gc class TestClass1
    {
        String *mVariable;
    public:
        [Description(S"Stephen Fraser", 
            S"This is default constructor for TextClass1.")]
        TestClass1()
        {
        }

        [Description(S"Stephen Fraser", 
            S"This is method does nothing for TestClass1.")]
        void DoesNothing()
        {
        }

        [Description(S"Stephen Fraser", 
            S"Added Variable property.")]
        [History(S"Stephen Fraser",
            S"Removed extra CodeDoc Attribute")]
        __property String *get_Variable()
        {
            return mVariable;
        }
       __property void set_Variable(String *value)
        {
            mVariable = value;
        }
    };

    [Description(S"Stephen Fraser", 
        S"This is TestClass2 to test the documentation Attribute.")]
    public __gc class TestClass2
    {
    };
}
