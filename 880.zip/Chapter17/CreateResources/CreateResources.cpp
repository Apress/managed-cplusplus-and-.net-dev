// This is the main project file for VC++ application project 
// generated using an Application Wizard.

#include "stdafx.h"
#include "WinForm.h"

#using <mscorlib.dll>

using namespace System;
using namespace System::Reflection;
using namespace System::Resources;


int _tmain()
{
    Assembly *assembly = Assembly::GetExecutingAssembly();
    ResourceManager *rm1 = new ResourceManager(S"CreateResources.Color", assembly);
    ResourceManager *rm2 = new ResourceManager(S"CreateResources.Animal", assembly);
    ResourceManager *rm3 = new ResourceManager(S"Fruit", assembly);

    // TODO: Please replace the sample code below with your own.
    Console::WriteLine(rm1->GetObject(S"Color1"));
    Console::WriteLine(rm1->GetObject(S"Color2"));
    Console::WriteLine(rm1->GetObject(S"Color3"));
    Console::WriteLine(rm1->GetObject(S"Color4"));

    Console::WriteLine(rm2->GetObject(S"Animal1"));
    Console::WriteLine(rm2->GetObject(S"Animal2"));
    Console::WriteLine(rm2->GetObject(S"Animal3"));
    Console::WriteLine(rm2->GetObject(S"Animal4"));

    Console::WriteLine(rm3->GetObject(S"Fruit1"));
    Console::WriteLine(rm3->GetObject(S"Fruit2"));
    Console::WriteLine(rm3->GetObject(S"Fruit3"));
    Console::WriteLine(rm3->GetObject(S"Fruit4"));

    (new CreateResources::WinForm())->ShowDialog();

    return 0;
}