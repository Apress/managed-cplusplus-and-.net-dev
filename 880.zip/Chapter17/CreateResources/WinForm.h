#pragma once

using namespace System;
using namespace System::ComponentModel;
using namespace System::Collections;
using namespace System::Windows::Forms;
using namespace System::Data;
using namespace System::Drawing;
using namespace System::Reflection;
using namespace System::Resources;


namespace CreateResources
{
	/// <summary> 
	/// Summary for WinForm
	///
	/// WARNING: If you change the name of this class, you will need to change the 
	///          'Resource File Name' property for the managed resource compiler tool 
	///          associated with all .resx files this class depends on.  Otherwise,
	///          the designers will not be able to interact properly with localized
	///          resources associated with this form.
	/// </summary>
	public __gc class WinForm : public System::Windows::Forms::Form
	{
	public: 
		WinForm(void)
		{
			InitializeComponent();
		}
        
	protected: 
		void Dispose(Boolean disposing)
		{
			if (disposing && components)
			{
				components->Dispose();
			}
			__super::Dispose(disposing);
		}
    private: System::Windows::Forms::PictureBox *  pictureBox1;
    private: System::Windows::Forms::PictureBox *  pictureBox2;
    private: System::Windows::Forms::Label *  label1;
    private: System::Windows::Forms::Label *  label2;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container* components;

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
            this->pictureBox1 = new System::Windows::Forms::PictureBox();
            this->pictureBox2 = new System::Windows::Forms::PictureBox();
            this->label1 = new System::Windows::Forms::Label();
            this->label2 = new System::Windows::Forms::Label();
            this->SuspendLayout();
            // 
            // pictureBox1
            // 
            this->pictureBox1->Location = System::Drawing::Point(32, 64);
            this->pictureBox1->Name = S"pictureBox1";
            this->pictureBox1->Size = System::Drawing::Size(160, 240);
            this->pictureBox1->TabIndex = 0;
            this->pictureBox1->TabStop = false;
            // 
            // pictureBox2
            // 
            this->pictureBox2->Location = System::Drawing::Point(264, 64);
            this->pictureBox2->Name = S"pictureBox2";
            this->pictureBox2->Size = System::Drawing::Size(288, 296);
            this->pictureBox2->TabIndex = 1;
            this->pictureBox2->TabStop = false;
            // 
            // label1
            // 
            this->label1->Location = System::Drawing::Point(56, 24);
            this->label1->Name = S"label1";
            this->label1->TabIndex = 2;
            this->label1->Text = S"label1";
            // 
            // label2
            // 
            this->label2->Location = System::Drawing::Point(272, 24);
            this->label2->Name = S"label2";
            this->label2->TabIndex = 3;
            this->label2->Text = S"label2";
            // 
            // WinForm
            // 
            this->AutoScaleBaseSize = System::Drawing::Size(6, 15);
            this->ClientSize = System::Drawing::Size(624, 389);
            this->Controls->Add(this->label2);
            this->Controls->Add(this->label1);
            this->Controls->Add(this->pictureBox2);
            this->Controls->Add(this->pictureBox1);
            this->Name = S"WinForm";
            this->Text = S"WinForm";
            this->Load += new System::EventHandler(this, WinForm_Load);
            this->ResumeLayout(false);

        }		
    private: 
        System::Void WinForm_Load(System::Object *  sender, System::EventArgs *  e)
        {
            Assembly *assembly = Assembly::GetExecutingAssembly();
            ResourceManager *rm = new ResourceManager(S"images", assembly);

            label1->Text = rm->GetObject(S"Name1")->ToString();
            pictureBox1->Image = dynamic_cast<Image*>(rm->GetObject(S"Image1"));
            label2->Text = rm->GetObject(S"Name2")->ToString();
            pictureBox2->Image = dynamic_cast<Image*>(rm->GetObject(S"Image2"));
        }

    };
}