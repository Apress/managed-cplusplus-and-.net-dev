#pragma once

using namespace System;
using namespace System::Text;
using namespace System::Reflection;

namespace Documentation
{
    [AttributeUsage(AttributeTargets::All, Inherited=true, AllowMultiple=false)]
    public __gc class DescriptionAttribute : public Attribute
    {
        String  *mAuthor;
        DateTime mCompileDate;
        String  *mDescription;

    public:
        DescriptionAttribute(String *Author, String *Description)
        {
            mAuthor = Author;
            mDescription = Description;
            mCompileDate = DateTime::Now;
        }

        __property String *get_Author()
        {
            return mAuthor;
        }

        __property String *get_CompileDate()
        {
            return mCompileDate.ToShortDateString();
        }

         __property String *get_Description()
        {
            return mDescription;
        }
    };

    [AttributeUsage(AttributeTargets::All, Inherited=true, AllowMultiple=true)]
    public __gc class HistoryAttribute : public Attribute
    {
        String  *mAuthor;
        DateTime mModifyDate;
        String  *mDescription;

    public:
        HistoryAttribute(String *Author, String *Description)
        {
            mAuthor = Author;
            mDescription = Description;
            mModifyDate = DateTime::Now;
        }

        __property String *get_Author()
        {
            return mAuthor;
        }

        __property String *get_ModifyDate()
        {
            return mModifyDate.ToShortDateString();
        }
        __property void set_ModifyDate(String *value)
        {
            mModifyDate = Convert::ToDateTime(value);
        }

        __property String *get_Description()
        {
            return mDescription;
        }
    };
}
