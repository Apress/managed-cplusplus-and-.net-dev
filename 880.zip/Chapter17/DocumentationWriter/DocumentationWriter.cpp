using namespace System;
using namespace Reflection;
using namespace Documentation;

void DisplayDescription(Attribute *attr)
{
    if (attr !=  0)
    {
        DescriptionAttribute *cd = dynamic_cast<DescriptionAttribute*>(attr);
        Console::WriteLine(S"  Author: {0}  --  Compiled: {1}", 
            cd->Author, cd->CompileDate);
        Console::WriteLine(S"  Description: {0}", cd->Description);
        Console::WriteLine(S"    ---- Change History ----");
    }
    else
        Console::WriteLine(S"    No Documentation");
}

void DisplayHistory(Object *attr[])
{
    if (attr->Length > 0)
    {
        for (Int32 i = 0; i < attr->Length; i++)
        {
            HistoryAttribute *cd = dynamic_cast<HistoryAttribute*>(attr[i]);
            Console::WriteLine(S"    Author: {0}  --  Modified: {1}", 
                cd->Author, cd->ModifyDate);
            Console::WriteLine(S"    Description: {0}", cd->Description);
        }
    }
    else
        Console::WriteLine(S"    No changes");
}

void DisplayAttributes(MemberInfo *info)
{
    DisplayDescription(Attribute::GetCustomAttribute(info, __typeof(DescriptionAttribute)));
    DisplayHistory(info->GetCustomAttributes(__typeof(HistoryAttribute), true));
}

void PrintClassInfo(Type *type)
{
    Console::WriteLine(S"Class: {0}", type->ToString());
    DisplayAttributes(type);
 
    ConstructorInfo *constructors[] = type->GetConstructors();
    for (Int32 i = 0; i < constructors->Length; i++)
    {
        Console::WriteLine(S"Constructor: {0}", constructors[i]->ToString());
        DisplayAttributes(constructors[i]);
    }

    MethodInfo *methods[] = type->GetMethods(static_cast<BindingFlags>
      (BindingFlags::Public|BindingFlags::Instance|BindingFlags::DeclaredOnly));
    for (Int32 i = 0; i < methods->Length; i++)
    {
        Console::WriteLine(S"Method: {0}", methods[i]->ToString());
        DisplayAttributes(methods[i]);
    }

    PropertyInfo *properties[] = type->GetProperties(static_cast<BindingFlags>
      (BindingFlags::Public|BindingFlags::Instance|BindingFlags::DeclaredOnly));
    for (Int32 i = 0; i < properties->Length; i++)
    {
        Console::WriteLine(S"Property: {0}", properties[i]->ToString());
        DisplayAttributes(properties[i]);
    }
}

Int32 main(Int32 argc, SByte __nogc *argv[])
{
    try
    {
        Assembly *assembly = Assembly::LoadFrom(new String(argv[1]));

        Type *types[] = assembly->GetTypes();

        for (Int32 i = 0; i < types->Length; i++)
        {
            PrintClassInfo(types[i]);
            Console::WriteLine();
        }
    }
    catch(System::IO::FileNotFoundException*)
    {
        Console::WriteLine(S"Can't find assembly: {0}\n", new String(argv[1]));
    }
    return 0;
}