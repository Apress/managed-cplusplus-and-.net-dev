using namespace System;
using namespace System::Globalization;

Int32 main()
{
    DateTime dt = DateTime::Now;

    Console::WriteLine(S"en-us {0}",dt.ToString("D",new CultureInfo(S"en-us")));
    Console::WriteLine(S"en-gb {0}",dt.ToString("D",new CultureInfo(S"en-gb")));
    Console::WriteLine(S"fr-fr {0}",dt.ToString("D",new CultureInfo(S"fr-fr")));
    Console::WriteLine(S"de-de {0}",dt.ToString("D",new CultureInfo(S"de-de")));

	return 0;
}