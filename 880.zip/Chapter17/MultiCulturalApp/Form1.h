#pragma once

#include "SelectLang.h"

namespace MultiCulturalApp
{
    using namespace System;
    using namespace System::ComponentModel;
    using namespace System::Collections;
    using namespace System::Windows::Forms;
    using namespace System::Data;
    using namespace System::Drawing;

    using namespace System::Globalization;
    using namespace System::Threading;

    public __gc class Form1 : public System::Windows::Forms::Form
    {   
    public:
        Form1(void)
        {
            (new SelectLang())->ShowDialog();
            InitializeComponent();
        }
  
    protected:
        void Dispose(Boolean disposing)
        {
            if (disposing && components)
            {
                components->Dispose();
            }
            __super::Dispose(disposing);
        }
    private: System::Windows::Forms::Label *  lbHello;


    private: System::ComponentModel::Container * components;

        void InitializeComponent(void)
        {
            System::Resources::ResourceManager *  resources = new System::Resources::ResourceManager(__typeof(MultiCulturalApp::Form1));
            this->lbHello = new System::Windows::Forms::Label();
            this->SuspendLayout();
            // 
            // lbHello
            // 
            this->lbHello->AccessibleDescription = resources->GetString(S"lbHello.AccessibleDescription");
            this->lbHello->AccessibleName = resources->GetString(S"lbHello.AccessibleName");
            this->lbHello->Anchor = (*__try_cast<__box System::Windows::Forms::AnchorStyles *  >(resources->GetObject(S"lbHello.Anchor")));
            this->lbHello->AutoSize = (*__try_cast<__box System::Boolean *  >(resources->GetObject(S"lbHello.AutoSize")));
            this->lbHello->BackColor = System::Drawing::SystemColors::ControlLight;
            this->lbHello->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
            this->lbHello->Dock = (*__try_cast<__box System::Windows::Forms::DockStyle *  >(resources->GetObject(S"lbHello.Dock")));
            this->lbHello->Enabled = (*__try_cast<__box System::Boolean *  >(resources->GetObject(S"lbHello.Enabled")));
            this->lbHello->Font = (__try_cast<System::Drawing::Font *  >(resources->GetObject(S"lbHello.Font")));
            this->lbHello->Image = (__try_cast<System::Drawing::Image *  >(resources->GetObject(S"lbHello.Image")));
            this->lbHello->ImageAlign = (*__try_cast<__box System::Drawing::ContentAlignment *  >(resources->GetObject(S"lbHello.ImageAlign")));
            this->lbHello->ImageIndex = (*__try_cast<__box System::Int32 *  >(resources->GetObject(S"lbHello.ImageIndex")));
            this->lbHello->ImeMode = (*__try_cast<__box System::Windows::Forms::ImeMode *  >(resources->GetObject(S"lbHello.ImeMode")));
            this->lbHello->Location = (*__try_cast<__box System::Drawing::Point *  >(resources->GetObject(S"lbHello.Location")));
            this->lbHello->Name = S"lbHello";
            this->lbHello->RightToLeft = (*__try_cast<__box System::Windows::Forms::RightToLeft *  >(resources->GetObject(S"lbHello.RightToLeft")));
            this->lbHello->Size = (*__try_cast<__box System::Drawing::Size *  >(resources->GetObject(S"lbHello.Size")));
            this->lbHello->TabIndex = (*__try_cast<__box System::Int32 *  >(resources->GetObject(S"lbHello.TabIndex")));
            this->lbHello->Text = resources->GetString(S"lbHello.Text");
            this->lbHello->TextAlign = (*__try_cast<__box System::Drawing::ContentAlignment *  >(resources->GetObject(S"lbHello.TextAlign")));
            this->lbHello->Visible = (*__try_cast<__box System::Boolean *  >(resources->GetObject(S"lbHello.Visible")));
            // 
            // Form1
            // 
            this->AccessibleDescription = resources->GetString(S"$this.AccessibleDescription");
            this->AccessibleName = resources->GetString(S"$this.AccessibleName");
            this->AutoScaleBaseSize = (*__try_cast<__box System::Drawing::Size *  >(resources->GetObject(S"$this.AutoScaleBaseSize")));
            this->AutoScroll = (*__try_cast<__box System::Boolean *  >(resources->GetObject(S"$this.AutoScroll")));
            this->AutoScrollMargin = (*__try_cast<__box System::Drawing::Size *  >(resources->GetObject(S"$this.AutoScrollMargin")));
            this->AutoScrollMinSize = (*__try_cast<__box System::Drawing::Size *  >(resources->GetObject(S"$this.AutoScrollMinSize")));
            this->BackgroundImage = (__try_cast<System::Drawing::Image *  >(resources->GetObject(S"$this.BackgroundImage")));
            this->ClientSize = (*__try_cast<__box System::Drawing::Size *  >(resources->GetObject(S"$this.ClientSize")));
            this->Controls->Add(this->lbHello);
            this->Enabled = (*__try_cast<__box System::Boolean *  >(resources->GetObject(S"$this.Enabled")));
            this->Font = (__try_cast<System::Drawing::Font *  >(resources->GetObject(S"$this.Font")));
            this->Icon = (__try_cast<System::Drawing::Icon *  >(resources->GetObject(S"$this.Icon")));
            this->ImeMode = (*__try_cast<__box System::Windows::Forms::ImeMode *  >(resources->GetObject(S"$this.ImeMode")));
            this->Location = (*__try_cast<__box System::Drawing::Point *  >(resources->GetObject(S"$this.Location")));
            this->MaximumSize = (*__try_cast<__box System::Drawing::Size *  >(resources->GetObject(S"$this.MaximumSize")));
            this->MinimumSize = (*__try_cast<__box System::Drawing::Size *  >(resources->GetObject(S"$this.MinimumSize")));
            this->Name = S"Form1";
            this->RightToLeft = (*__try_cast<__box System::Windows::Forms::RightToLeft *  >(resources->GetObject(S"$this.RightToLeft")));
            this->StartPosition = (*__try_cast<__box System::Windows::Forms::FormStartPosition *  >(resources->GetObject(S"$this.StartPosition")));
            this->Text = resources->GetString(S"$this.Text");
            this->ResumeLayout(false);

        }   
    };
}


