#pragma once

using namespace System;
using namespace System::ComponentModel;
using namespace System::Collections;
using namespace System::Windows::Forms;
using namespace System::Data;
using namespace System::Drawing;

using namespace System::Globalization;
using namespace System::Threading;

namespace MultiCulturalApp
{
	/// <summary> 
	/// Summary for SelectLang
	///
	/// WARNING: If you change the name of this class, you will need to change the 
	///          'Resource File Name' property for the managed resource compiler tool 
	///          associated with all .resx files this class depends on.  Otherwise,
	///          the designers will not be able to interact properly with localized
	///          resources associated with this form.
	/// </summary>
	public __gc class SelectLang : public System::Windows::Forms::Form
	{
	public: 
		SelectLang(void)
		{
			InitializeComponent();
		}
        
	protected: 
		void Dispose(Boolean disposing)
		{
			if (disposing && components)
			{
				components->Dispose();
			}
			__super::Dispose(disposing);
		}
    private: System::Windows::Forms::Label *  label1;
    private: System::Windows::Forms::ComboBox *  comboBox1;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container* components;

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
            System::Resources::ResourceManager *  resources = new System::Resources::ResourceManager(__typeof(MultiCulturalApp::SelectLang));
            this->label1 = new System::Windows::Forms::Label();
            this->comboBox1 = new System::Windows::Forms::ComboBox();
            this->SuspendLayout();
            // 
            // label1
            // 
            this->label1->AccessibleDescription = resources->GetString(S"label1.AccessibleDescription");
            this->label1->AccessibleName = resources->GetString(S"label1.AccessibleName");
            this->label1->Anchor = (*__try_cast<__box System::Windows::Forms::AnchorStyles *  >(resources->GetObject(S"label1.Anchor")));
            this->label1->AutoSize = (*__try_cast<__box System::Boolean *  >(resources->GetObject(S"label1.AutoSize")));
            this->label1->Dock = (*__try_cast<__box System::Windows::Forms::DockStyle *  >(resources->GetObject(S"label1.Dock")));
            this->label1->Enabled = (*__try_cast<__box System::Boolean *  >(resources->GetObject(S"label1.Enabled")));
            this->label1->Font = (__try_cast<System::Drawing::Font *  >(resources->GetObject(S"label1.Font")));
            this->label1->Image = (__try_cast<System::Drawing::Image *  >(resources->GetObject(S"label1.Image")));
            this->label1->ImageAlign = (*__try_cast<__box System::Drawing::ContentAlignment *  >(resources->GetObject(S"label1.ImageAlign")));
            this->label1->ImageIndex = (*__try_cast<__box System::Int32 *  >(resources->GetObject(S"label1.ImageIndex")));
            this->label1->ImeMode = (*__try_cast<__box System::Windows::Forms::ImeMode *  >(resources->GetObject(S"label1.ImeMode")));
            this->label1->Location = (*__try_cast<__box System::Drawing::Point *  >(resources->GetObject(S"label1.Location")));
            this->label1->Name = S"label1";
            this->label1->RightToLeft = (*__try_cast<__box System::Windows::Forms::RightToLeft *  >(resources->GetObject(S"label1.RightToLeft")));
            this->label1->Size = (*__try_cast<__box System::Drawing::Size *  >(resources->GetObject(S"label1.Size")));
            this->label1->TabIndex = (*__try_cast<__box System::Int32 *  >(resources->GetObject(S"label1.TabIndex")));
            this->label1->Text = resources->GetString(S"label1.Text");
            this->label1->TextAlign = (*__try_cast<__box System::Drawing::ContentAlignment *  >(resources->GetObject(S"label1.TextAlign")));
            this->label1->Visible = (*__try_cast<__box System::Boolean *  >(resources->GetObject(S"label1.Visible")));
            // 
            // comboBox1
            // 
            this->comboBox1->AccessibleDescription = resources->GetString(S"comboBox1.AccessibleDescription");
            this->comboBox1->AccessibleName = resources->GetString(S"comboBox1.AccessibleName");
            this->comboBox1->Anchor = (*__try_cast<__box System::Windows::Forms::AnchorStyles *  >(resources->GetObject(S"comboBox1.Anchor")));
            this->comboBox1->BackgroundImage = (__try_cast<System::Drawing::Image *  >(resources->GetObject(S"comboBox1.BackgroundImage")));
            this->comboBox1->Dock = (*__try_cast<__box System::Windows::Forms::DockStyle *  >(resources->GetObject(S"comboBox1.Dock")));
            this->comboBox1->Enabled = (*__try_cast<__box System::Boolean *  >(resources->GetObject(S"comboBox1.Enabled")));
            this->comboBox1->Font = (__try_cast<System::Drawing::Font *  >(resources->GetObject(S"comboBox1.Font")));
            this->comboBox1->ImeMode = (*__try_cast<__box System::Windows::Forms::ImeMode *  >(resources->GetObject(S"comboBox1.ImeMode")));
            this->comboBox1->IntegralHeight = (*__try_cast<__box System::Boolean *  >(resources->GetObject(S"comboBox1.IntegralHeight")));
            this->comboBox1->ItemHeight = (*__try_cast<__box System::Int32 *  >(resources->GetObject(S"comboBox1.ItemHeight")));
            System::Object* __mcTemp__1[] = new System::Object*[3];
            __mcTemp__1[0] = resources->GetString(S"comboBox1.Items");
            __mcTemp__1[1] = resources->GetString(S"comboBox1.Items1");
            __mcTemp__1[2] = resources->GetString(S"comboBox1.Items2");
            this->comboBox1->Items->AddRange(__mcTemp__1);
            this->comboBox1->Location = (*__try_cast<__box System::Drawing::Point *  >(resources->GetObject(S"comboBox1.Location")));
            this->comboBox1->MaxDropDownItems = (*__try_cast<__box System::Int32 *  >(resources->GetObject(S"comboBox1.MaxDropDownItems")));
            this->comboBox1->MaxLength = (*__try_cast<__box System::Int32 *  >(resources->GetObject(S"comboBox1.MaxLength")));
            this->comboBox1->Name = S"comboBox1";
            this->comboBox1->RightToLeft = (*__try_cast<__box System::Windows::Forms::RightToLeft *  >(resources->GetObject(S"comboBox1.RightToLeft")));
            this->comboBox1->Size = (*__try_cast<__box System::Drawing::Size *  >(resources->GetObject(S"comboBox1.Size")));
            this->comboBox1->TabIndex = (*__try_cast<__box System::Int32 *  >(resources->GetObject(S"comboBox1.TabIndex")));
            this->comboBox1->Text = resources->GetString(S"comboBox1.Text");
            this->comboBox1->Visible = (*__try_cast<__box System::Boolean *  >(resources->GetObject(S"comboBox1.Visible")));
            this->comboBox1->SelectedIndexChanged += new System::EventHandler(this, comboBox1_SelectedIndexChanged);
            // 
            // SelectLang
            // 
            this->AccessibleDescription = resources->GetString(S"$this.AccessibleDescription");
            this->AccessibleName = resources->GetString(S"$this.AccessibleName");
            this->AutoScaleBaseSize = (*__try_cast<__box System::Drawing::Size *  >(resources->GetObject(S"$this.AutoScaleBaseSize")));
            this->AutoScroll = (*__try_cast<__box System::Boolean *  >(resources->GetObject(S"$this.AutoScroll")));
            this->AutoScrollMargin = (*__try_cast<__box System::Drawing::Size *  >(resources->GetObject(S"$this.AutoScrollMargin")));
            this->AutoScrollMinSize = (*__try_cast<__box System::Drawing::Size *  >(resources->GetObject(S"$this.AutoScrollMinSize")));
            this->BackgroundImage = (__try_cast<System::Drawing::Image *  >(resources->GetObject(S"$this.BackgroundImage")));
            this->ClientSize = (*__try_cast<__box System::Drawing::Size *  >(resources->GetObject(S"$this.ClientSize")));
            this->Controls->Add(this->label1);
            this->Controls->Add(this->comboBox1);
            this->Enabled = (*__try_cast<__box System::Boolean *  >(resources->GetObject(S"$this.Enabled")));
            this->Font = (__try_cast<System::Drawing::Font *  >(resources->GetObject(S"$this.Font")));
            this->Icon = (__try_cast<System::Drawing::Icon *  >(resources->GetObject(S"$this.Icon")));
            this->ImeMode = (*__try_cast<__box System::Windows::Forms::ImeMode *  >(resources->GetObject(S"$this.ImeMode")));
            this->Location = (*__try_cast<__box System::Drawing::Point *  >(resources->GetObject(S"$this.Location")));
            this->MaximumSize = (*__try_cast<__box System::Drawing::Size *  >(resources->GetObject(S"$this.MaximumSize")));
            this->MinimumSize = (*__try_cast<__box System::Drawing::Size *  >(resources->GetObject(S"$this.MinimumSize")));
            this->Name = S"SelectLang";
            this->RightToLeft = (*__try_cast<__box System::Windows::Forms::RightToLeft *  >(resources->GetObject(S"$this.RightToLeft")));
            this->StartPosition = (*__try_cast<__box System::Windows::Forms::FormStartPosition *  >(resources->GetObject(S"$this.StartPosition")));
            this->Text = resources->GetString(S"$this.Text");
            this->ResumeLayout(false);

        }		
    private: 

        static String *culture[] = {S"en-us", S"fr-fr", S"de-de"};

        System::Void comboBox1_SelectedIndexChanged(System::Object *  sender, System::EventArgs *  e)
        {
            Thread::CurrentThread->CurrentCulture = new CultureInfo(culture[comboBox1->SelectedIndex]);
            Thread::CurrentThread->CurrentUICulture = Thread::CurrentThread->CurrentCulture;

            this->Close();
        }
    };
}