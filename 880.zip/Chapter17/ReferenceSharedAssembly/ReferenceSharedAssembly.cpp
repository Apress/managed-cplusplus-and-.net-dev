using namespace System;
using namespace SharedAssembly;

Int32 main()
{
    SharedClass *sa = new SharedClass();
    Console::WriteLine(sa->Version);
	return 0;
}