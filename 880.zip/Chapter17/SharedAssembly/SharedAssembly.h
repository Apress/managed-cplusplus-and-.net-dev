// SharedAssembly.h

#pragma once

using namespace System;
using namespace System::Reflection;

namespace SharedAssembly
{
    public __gc class SharedClass
    {
    public:
        __property Version *get_Version()
        {
            Assembly *assembly = Assembly::GetExecutingAssembly();
            return assembly->GetName()->Version;
        }
    };

    void DummyMethod()
    {
    }
}
