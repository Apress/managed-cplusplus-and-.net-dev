#pragma once


namespace Reflecting
{
    using namespace System;
    using namespace System::ComponentModel;
    using namespace System::Collections;
    using namespace System::Windows::Forms;
    using namespace System::Data;
    using namespace System::Drawing;
    using namespace System::IO;
    using namespace System::Reflection;

    public __gc class Form1 : public System::Windows::Forms::Form
    {   
    public:
        Form1(void)
        {
            InitializeComponent();
        }
  
    protected:
        void Dispose(Boolean disposing)
        {
            if (disposing && components)
            {
                components->Dispose();
            }
            __super::Dispose(disposing);
        }

    private: System::Windows::Forms::Label *  label1;
    private: System::Windows::Forms::ListBox *  lbMethods;
    private: System::Windows::Forms::ListBox *  lbProperties;
    private: System::Windows::Forms::ListBox *  lbVariables;
    private: System::Windows::Forms::Label *  label2;
    private: System::Windows::Forms::Label *  label3;
    private: System::Windows::Forms::Label *  label4;
    private: System::Windows::Forms::ComboBox *  cbDataTypes;
    private: System::Windows::Forms::Label *  label5;
    private: System::ComponentModel::Container * components;
    private: System::Windows::Forms::ComboBox *  cbAssemblies;
    private: System::Windows::Forms::GroupBox *  groupBox1;

    private: Type *types[];
    private: static String *assemblies[] = {
       S"System",
       S"System.Drawing",
       S"System.Xml",
       S"System.Windows.Forms",
       S"System.Data",
       S"mscorlib"
    };

        void InitializeComponent(void)
        {
            this->label1 = new System::Windows::Forms::Label();
            this->lbMethods = new System::Windows::Forms::ListBox();
            this->lbProperties = new System::Windows::Forms::ListBox();
            this->lbVariables = new System::Windows::Forms::ListBox();
            this->label2 = new System::Windows::Forms::Label();
            this->label3 = new System::Windows::Forms::Label();
            this->label4 = new System::Windows::Forms::Label();
            this->cbDataTypes = new System::Windows::Forms::ComboBox();
            this->label5 = new System::Windows::Forms::Label();
            this->cbAssemblies = new System::Windows::Forms::ComboBox();
            this->groupBox1 = new System::Windows::Forms::GroupBox();
            this->SuspendLayout();
            // 
            // label1
            // 
            this->label1->Location = System::Drawing::Point(40, 72);
            this->label1->Name = S"label1";
            this->label1->Size = System::Drawing::Size(104, 23);
            this->label1->TabIndex = 1;
            this->label1->Text = S"Select data type:";
            // 
            // lbMethods
            // 
            this->lbMethods->HorizontalScrollbar = true;
            this->lbMethods->ItemHeight = 16;
            this->lbMethods->Location = System::Drawing::Point(8, 144);
            this->lbMethods->Name = S"lbMethods";
            this->lbMethods->Size = System::Drawing::Size(392, 308);
            this->lbMethods->TabIndex = 2;
            // 
            // lbProperties
            // 
            this->lbProperties->HorizontalScrollbar = true;
            this->lbProperties->ItemHeight = 16;
            this->lbProperties->Location = System::Drawing::Point(408, 144);
            this->lbProperties->Name = S"lbProperties";
            this->lbProperties->Size = System::Drawing::Size(336, 308);
            this->lbProperties->TabIndex = 3;
            // 
            // lbVariables
            // 
            this->lbVariables->HorizontalScrollbar = true;
            this->lbVariables->ItemHeight = 16;
            this->lbVariables->Location = System::Drawing::Point(752, 144);
            this->lbVariables->Name = S"lbVariables";
            this->lbVariables->Size = System::Drawing::Size(192, 308);
            this->lbVariables->TabIndex = 4;
            // 
            // label2
            // 
            this->label2->Location = System::Drawing::Point(16, 120);
            this->label2->Name = S"label2";
            this->label2->Size = System::Drawing::Size(100, 16);
            this->label2->TabIndex = 6;
            this->label2->Text = S"Methods";
            // 
            // label3
            // 
            this->label3->Location = System::Drawing::Point(416, 120);
            this->label3->Name = S"label3";
            this->label3->Size = System::Drawing::Size(100, 16);
            this->label3->TabIndex = 7;
            this->label3->Text = S"Properties";
            // 
            // label4
            // 
            this->label4->Location = System::Drawing::Point(760, 120);
            this->label4->Name = S"label4";
            this->label4->Size = System::Drawing::Size(100, 16);
            this->label4->TabIndex = 8;
            this->label4->Text = S"Variables";
            // 
            // cbDataTypes
            // 
            this->cbDataTypes->Location = System::Drawing::Point(160, 72);
            this->cbDataTypes->Name = S"cbDataTypes";
            this->cbDataTypes->Size = System::Drawing::Size(456, 24);
            this->cbDataTypes->TabIndex = 9;
            this->cbDataTypes->SelectedIndexChanged += new System::EventHandler(this, cbDataTypes_SelectedIndexChanged);
            // 
            // label5
            // 
            this->label5->Location = System::Drawing::Point(40, 40);
            this->label5->Name = S"label5";
            this->label5->Size = System::Drawing::Size(112, 16);
            this->label5->TabIndex = 10;
            this->label5->Text = S"Select assembly:";
            // 
            // cbAssemblies
            // 
            this->cbAssemblies->Location = System::Drawing::Point(160, 40);
            this->cbAssemblies->Name = S"cbAssemblies";
            this->cbAssemblies->Size = System::Drawing::Size(456, 24);
            this->cbAssemblies->TabIndex = 11;
            this->cbAssemblies->SelectedIndexChanged += new System::EventHandler(this, cbAssemblies_SelectedIndexChanged);
            // 
            // groupBox1
            // 
            this->groupBox1->Location = System::Drawing::Point(24, 16);
            this->groupBox1->Name = S"groupBox1";
            this->groupBox1->Size = System::Drawing::Size(616, 96);
            this->groupBox1->TabIndex = 12;
            this->groupBox1->TabStop = false;
            // 
            // Form1
            // 
            this->AutoScaleBaseSize = System::Drawing::Size(6, 15);
            this->ClientSize = System::Drawing::Size(952, 461);
            this->Controls->Add(this->cbAssemblies);
            this->Controls->Add(this->label5);
            this->Controls->Add(this->cbDataTypes);
            this->Controls->Add(this->label4);
            this->Controls->Add(this->label3);
            this->Controls->Add(this->label2);
            this->Controls->Add(this->lbVariables);
            this->Controls->Add(this->lbProperties);
            this->Controls->Add(this->lbMethods);
            this->Controls->Add(this->label1);
            this->Controls->Add(this->groupBox1);
            this->Name = S"Form1";
            this->Text = S"Assembly Viewer";
            this->Load += new System::EventHandler(this, Form1_Load);
            this->ResumeLayout(false);

        }   

    private: 
        System::Void Form1_Load(System::Object *sender, System::EventArgs *e)
        {
            for (Int32 i = 0; i < assemblies->Length; i++)
            {
                cbAssemblies->Items->Add(assemblies[i]);   
            }
            cbAssemblies->SelectedIndex = 0;
        }

    private: 
        System::Void cbAssemblies_SelectedIndexChanged(System::Object *  sender, System::EventArgs *  e)
        {
            Assembly* assembly = Assembly::LoadWithPartialName(
                                 assemblies[cbAssemblies->SelectedIndex]);

            types = assembly->GetTypes();

            cbDataTypes->Items->Clear();
            for (Int32 i = 0; i < types->Length; i++)
            {
                cbDataTypes->Items->Add(types[i]->ToString());   
            }
            cbDataTypes->SelectedIndex = 0;
        }

    private: 
        System::Void cbDataTypes_SelectedIndexChanged(System::Object *  sender, System::EventArgs *  e)
        {

            Type *type = types[cbDataTypes->SelectedIndex];

            MemberInfo *methods[] = type->GetMethods();
            lbMethods->Items->Clear();
            for (Int32 i = 0; i < methods->Length; i++)
            {
                lbMethods->Items->Add(methods[i]->ToString());
            }

            PropertyInfo *properties[] = type->GetProperties();
            lbProperties->Items->Clear();
            for (Int32 i = 0; i < properties->Length; i++)
            {
                lbProperties->Items->Add(properties[i]->ToString());
            }

            MemberInfo *variables[] = type->GetFields();
            lbVariables->Items->Clear();
            for (Int32 i = 0; i < variables->Length; i++)
            {
                lbVariables->Items->Add(variables[i]->ToString());
            }
        }
    };
}


