#pragma once


namespace SplitCLB
{
    using namespace System;
    using namespace System::ComponentModel;
    using namespace System::Collections;
    using namespace System::Windows::Forms;
    using namespace System::Data;
    using namespace System::Drawing;

    public __gc class Form1 : public System::Windows::Forms::Form
    {   
    public:
        Form1(void)
        {
            InitializeComponent();

            Object *Items[] = { S"Appleman", S"Challa", S"Chand", S"Cornell",
                                S"Fraser", S"Gunnerson", S"Harris", S"Rammer", 
                                S"Symmonds", S"Thomsen", S"Troelsen", S"Vaughn" 
            };
            clBox->Items->AddRange(Items);
            lBox->Items->AddRange(Items);

            // Create a Check box for each entry in Items array.
            cBox = new CheckBox*[Items->Count]; 
            Int32 j = cBox->Count/2;
            for (Int32 i = 0; i < j; i++)
            {
                // Build Left Column
                cBox[i] = new CheckBox();
                cBox[i]->Location = Drawing::Point(50, 160+(30*i)); 
                cBox[i]->TabIndex = i+2; 
                cBox[i]->Text = Items[i]->ToString(); 
                cBox[i]->CheckStateChanged += 
                    new EventHandler(this, cBox_CheckStateChanged); 
                
                // Build Right Column
                cBox[i+j] = new CheckBox();
                cBox[i+j]->Location = Drawing::Point(180, 160+(30*i)); 
                cBox[i+j]->TabIndex = i+j+2; 
                cBox[i+j]->Text = Items[i+j]->ToString(); 
                cBox[i+j]->CheckStateChanged += 
                    new EventHandler(this, cBox_CheckStateChanged); 
            }
            // Add all CheckBoxes to Form
            Controls->AddRange(cBox);
        }
  
    protected:
        void Dispose(Boolean disposing)
        {
            if (disposing && components)
            {
                components->Dispose();
            }
            __super::Dispose(disposing);
        }
    private: System::Windows::Forms::CheckedListBox *  clBox;
    private: System::Windows::Forms::ListBox *  lBox;
    private: System::ComponentModel::Container * components;

    private: CheckBox *cBox[]; 

        void InitializeComponent(void)
        {
            this->clBox = new System::Windows::Forms::CheckedListBox();
            this->lBox = new System::Windows::Forms::ListBox();
            this->SuspendLayout();
            // 
            // clBox
            // 
            this->clBox->Location = System::Drawing::Point(16, 16);
            this->clBox->MultiColumn = true;
            this->clBox->Name = S"clBox";
            this->clBox->Size = System::Drawing::Size(304, 106);
            this->clBox->TabIndex = 0;
            this->clBox->ThreeDCheckBoxes = true;
            this->clBox->SelectedIndexChanged += new System::EventHandler(this, clBox_SelectedIndexChanged);
            this->clBox->ItemCheck += new System::Windows::Forms::ItemCheckEventHandler(this, clBox_ItemCheck);
            // 
            // lBox
            // 
            this->lBox->ItemHeight = 16;
            this->lBox->Location = System::Drawing::Point(360, 16);
            this->lBox->Name = S"lBox";
            this->lBox->Size = System::Drawing::Size(136, 196);
            this->lBox->TabIndex = 1;
            this->lBox->SelectedIndexChanged += new System::EventHandler(this, lBox_SelectedIndexChanged);
            // 
            // Form1
            // 
            this->AutoScaleBaseSize = System::Drawing::Size(6, 15);
            this->ClientSize = System::Drawing::Size(528, 357);
            this->Controls->Add(this->lBox);
            this->Controls->Add(this->clBox);
            this->Name = S"Form1";
            this->Text = S"Splitting The Check List Box";
            this->ResumeLayout(false);
        }   
    private: 
        System::Void clBox_ItemCheck(System::Object *  sender, System::Windows::Forms::ItemCheckEventArgs *  e)
        {
            // update state of CheckBox with same index as checked CheckedListBox
            cBox[e->Index]->CheckState = e->NewValue; 
        }
    private: 
        System::Void clBox_SelectedIndexChanged(System::Object *  sender, System::EventArgs *  e)
        {
            // update ListBox with same selected item in the CheckedListBox
            lBox->SelectedItem = clBox->SelectedItem->ToString(); 
        }
    private: 
        System::Void lBox_SelectedIndexChanged(System::Object *  sender, System::EventArgs *  e)
        {
            // update CheckedListBox with same selected item in the ListBox
            clBox->SelectedItem = lBox->SelectedItem; 
        }
    private: 
        void cBox_CheckStateChanged(Object *sender, EventArgs *e) 
        {
            // update state of CheckedListBox with same index as checked CheckBox
            CheckBox *cb = dynamic_cast<CheckBox*>(sender);
            clBox->SetItemCheckState(Array::IndexOf(cBox, cb), cb->CheckState);
        }
    };
}


