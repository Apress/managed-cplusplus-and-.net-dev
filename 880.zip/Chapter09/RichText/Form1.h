#pragma once


namespace RichText
{
    using namespace System;
    using namespace System::ComponentModel;
    using namespace System::Collections;
    using namespace System::Windows::Forms;
    using namespace System::Data;
    using namespace System::Drawing;

    public __gc class Form1 : public System::Windows::Forms::Form
    {   
    public:
        Form1(void)
        {
            InitializeComponent();
            BuildLabels();
        }
  
    protected:
        void Dispose(Boolean disposing)
        {
            if (disposing && components)
            {
                components->Dispose();
            }
            __super::Dispose(disposing);
        }
    private: System::Windows::Forms::RichTextBox *  rtBox;
    private: System::Windows::Forms::Label *labels[]; 

    private: System::ComponentModel::Container * components;

        void InitializeComponent(void)
        {
            this->rtBox = new System::Windows::Forms::RichTextBox();
            this->SuspendLayout();
            // 
            // rtBox
            // 
            this->rtBox->Anchor = (System::Windows::Forms::AnchorStyles)(((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Bottom) 
                | System::Windows::Forms::AnchorStyles::Left) 
                | System::Windows::Forms::AnchorStyles::Right);
            this->rtBox->Location = System::Drawing::Point(0, 32);
            this->rtBox->Name = S"rtBox";
            this->rtBox->RightMargin = 900;
            this->rtBox->ScrollBars = System::Windows::Forms::RichTextBoxScrollBars::ForcedVertical;
            this->rtBox->ShowSelectionMargin = true;
            this->rtBox->Size = System::Drawing::Size(950, 488);
            this->rtBox->TabIndex = 0;
            this->rtBox->Text = S"";
            this->rtBox->KeyDown += new System::Windows::Forms::KeyEventHandler(this, rtBox_KeyDown);
            // 
            // Form1
            // 
            this->AutoScaleBaseSize = System::Drawing::Size(6, 15);
            this->ClientSize = System::Drawing::Size(950, 520);
            this->Controls->Add(this->rtBox);
            this->Name = S"Form1";
            this->Text = S"(Very Simple Rich Text Editor)";
            this->ResumeLayout(false);

        }   

    private:
        void BuildLabels()
        {
            String *rtLabel[] = {S"F1-Bold", S"F2-Italics", S"F3-Underline", 
                                S"F4-Normal", S"F5-Red", S"F6-Blue", S"F7-Green", 
                                S"F8-Black", S"F9-Load", S"F10-Save"};
            labels = new Label*[10];

            // Build the labels
            for (Int32 i = 0; i < labels->Count; i++)
            {
                labels[i] = new Label();
                labels[i]->BackColor = SystemColors::ControlDark; 
                labels[i]->BorderStyle = BorderStyle::FixedSingle; 
                labels[i]->Location = Drawing::Point(5+(95*i), 8); 
                labels[i]->Size = Drawing::Size(85, 16); 
                labels[i]->Text = rtLabel[i]; 
                labels[i]->TextAlign = ContentAlignment::MiddleCenter; 
            }
            // Place labels on the Form
            Controls->AddRange(labels);
        }
    private: 
        System::Void rtBox_KeyDown(System::Object *  sender, System::Windows::Forms::KeyEventArgs *  e)
        {
            try
            {
                if (rtBox->SelectionLength > 0) 
                {
                    // Change selected text style
                    FontStyle fs;
                    switch (e->KeyCode) 
                    {
                        case Keys::F1: 
                            fs = FontStyle::Bold;                    
                            break; 
                        case Keys::F2: 
                            fs = FontStyle::Italic;                   
                            break; 
                        case Keys::F3: 
                            fs = FontStyle::Underline;
                            break; 
                        case Keys::F4: 
                            fs = FontStyle::Regular;
                            break; 
                    // Change selected text color
                        case Keys::F5: 
                            rtBox->SelectionColor = Color::Red; 
                            break; 
                        case Keys::F6: 
                            rtBox->SelectionColor = Color::Blue; 
                            break; 
                        case Keys::F7: 
                            rtBox->SelectionColor = Color::Green; 
                            break; 
                        case Keys::F8: 
                            rtBox->SelectionColor = Color::Black; 
                            break; 
                    }
                    // Do the actual change of the selected text style
                    if (e->KeyCode >= Keys::F1 && e->KeyCode <= Keys::F4)
                    {
                        rtBox->SelectionFont = new Drawing::Font( 
                            rtBox->SelectionFont->FontFamily, 
                            rtBox->SelectionFont->Size, 
                            fs 
                        );
                    }
                }
                // Load hard coded Chapter01.rtf file
                else if (e->KeyCode == Keys::F9)
                {
                    rtBox->LoadFile(S"Chapter01.rtf");
                }
                // Save hard coded Chapter01.rtf file
                else if (e->KeyCode == Keys::F10)
                {
                    rtBox->SaveFile(S"Chapter01.rtf", 
                                    RichTextBoxStreamType::RichText);
                }
            }
            // Capture any blowups
            catch (Exception *e)
            {
                MessageBox::Show(String::Format(S"Error: {0}", e->Message));
            }
        }
    };
}


