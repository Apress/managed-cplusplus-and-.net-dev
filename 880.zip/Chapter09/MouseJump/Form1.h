#pragma once


namespace MouseJump
{
    using namespace System;
    using namespace System::ComponentModel;
    using namespace System::Collections;
    using namespace System::Windows::Forms;
    using namespace System::Data;
    using namespace System::Drawing;

    /// <summary> 
    /// Summary for Form1
    ///
    /// WARNING: If you change the name of this class, you will need to change the 
    ///          'Resource File Name' property for the managed resource compiler tool 
    ///          associated with all .resx files this class depends on.  Otherwise,
    ///          the designers will not be able to interact properly with localized
    ///          resources associated with this form.
    /// </summary>
    public __gc class Form1 : public System::Windows::Forms::Form
    {   
    public:
        Form1(void)
        {
            InitializeComponent();
        }
  
    protected:
        void Dispose(Boolean disposing)
        {
            if (disposing && components)
            {
                components->Dispose();
            }
            __super::Dispose(disposing);
        }

    private:
        /// <summary>
        /// Required designer variable.
        /// </summary>
        System::ComponentModel::Container * components;

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        void InitializeComponent(void)
        {
            // 
            // Form1
            // 
            this->ClientSize = System::Drawing::Size(450, 300);
            this->Name = S"Form1";
            this->Text = S"Mouse Jump";
            this->MouseDown += new System::Windows::Forms::MouseEventHandler(this, Form1_MouseDown);

        }   
    private: 
        System::Void Form1_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
        {
            // Get mouse x and y coordinates
            Int32 x = e->X;
            Int32 y = e->Y;

            // Get Forms upper left location
            Point loc = DesktopLocation;

            // Handle left button mouse click
            if (e->Button == MouseButtons::Left)
            {
                Text = String::Format(S"Mouse Jump - Left Button at {0},{1}",
                    __box(x), __box(y));

                DesktopLocation = Drawing::Point(loc.X + x, loc.Y +y); 
            }
            // Handle right button mouse click
            else if (e->Button == MouseButtons::Right)
            {
                Text = String::Format(S"Mouse Jump - Right Button at {0},{1}",
                    __box(x), __box(y));

                DesktopLocation = Point((loc.X+1) - (ClientSize.Width - x), 
                                    (loc.Y+1) - (ClientSize.Height - y)); 
            }
            // Handle middle button mouse click
            else
            {
                Text = String::Format(S"Mouse Jump - Middle Button at {0},{1}",
                    __box(x), __box(y));
                DesktopLocation = Point((loc.X+1) - ((ClientSize.Width/2) - x), 
                                    (loc.Y+1) - ((ClientSize.Height/2) - y)); 
            }
        }
    };
}


