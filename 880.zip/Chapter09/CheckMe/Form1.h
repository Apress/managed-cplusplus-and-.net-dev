#pragma once


namespace CheckMe
{
    using namespace System;
    using namespace System::ComponentModel;
    using namespace System::Collections;
    using namespace System::Windows::Forms;
    using namespace System::Data;
    using namespace System::Drawing;

    public __gc class Form1 : public System::Windows::Forms::Form
    {   
    public:
        Form1(void)
        {
            InitializeComponent();
        }
  
    protected:
        void Dispose(Boolean disposing)
        {
            if (disposing && components)
            {
                components->Dispose();
            }
            __super::Dispose(disposing);
        }

 
    private: System::Windows::Forms::CheckBox *  TopCheck;
    private: System::Windows::Forms::CheckBox *  checkBox1;
    private: System::Windows::Forms::CheckBox *  checkBox2;
    private: System::Windows::Forms::CheckBox *  BottomCheck;

    private:
        System::ComponentModel::Container * components;

        void InitializeComponent(void)
        {
            this->TopCheck = new System::Windows::Forms::CheckBox();
            this->checkBox1 = new System::Windows::Forms::CheckBox();
            this->checkBox2 = new System::Windows::Forms::CheckBox();
            this->BottomCheck = new System::Windows::Forms::CheckBox();
            this->SuspendLayout();
            // 
            // TopCheck
            // 
            this->TopCheck->Location = System::Drawing::Point(50, 50);
            this->TopCheck->Name = S"TopCheck";
            this->TopCheck->Size = System::Drawing::Size(160, 25);
            this->TopCheck->TabIndex = 2;
            this->TopCheck->TabStop = false;
            this->TopCheck->Text = S"You Can\'t Check Me!";
            this->TopCheck->Enter += new System::EventHandler(this, TopCheck_Entered);
            this->TopCheck->MouseEnter += new System::EventHandler(this, TopCheck_Entered);
            // 
            // checkBox1
            // 
            this->checkBox1->Checked = true;
            this->checkBox1->CheckState = System::Windows::Forms::CheckState::Indeterminate;
            this->checkBox1->Location = System::Drawing::Point(50, 100);
            this->checkBox1->Name = S"checkBox1";
            this->checkBox1->Size = System::Drawing::Size(160, 25);
            this->checkBox1->TabIndex = 0;
            this->checkBox1->Text = S"Check Me! Check Me!";
            this->checkBox1->ThreeState = true;
            // 
            // checkBox2
            // 
            this->checkBox2->Location = System::Drawing::Point(50, 150);
            this->checkBox2->Name = S"checkBox2";
            this->checkBox2->Size = System::Drawing::Size(160, 25);
            this->checkBox2->TabIndex = 1;
            this->checkBox2->Text = S"Don\'t Forget ME!";
            // 
            // BottomCheck
            // 
            this->BottomCheck->Enabled = false;
            this->BottomCheck->Location = System::Drawing::Point(50, 200);
            this->BottomCheck->Name = S"BottomCheck";
            this->BottomCheck->Size = System::Drawing::Size(160, 25);
            this->BottomCheck->TabIndex = 0;
            this->BottomCheck->TabStop = false;
            this->BottomCheck->Text = S"You Can\'t Check Me!";
            this->BottomCheck->Visible = false;
            this->BottomCheck->Enter += new System::EventHandler(this, BottomCheck_Entered);
            this->BottomCheck->MouseEnter += new System::EventHandler(this, BottomCheck_Entered);
            // 
            // Form1
            // 
            this->AutoScaleBaseSize = System::Drawing::Size(6, 15);
            this->ClientSize = System::Drawing::Size(300, 300);
            this->Controls->Add(this->BottomCheck);
            this->Controls->Add(this->checkBox2);
            this->Controls->Add(this->checkBox1);
            this->Controls->Add(this->TopCheck);
            this->Name = S"Form1";
            this->Text = S"Can\'t Check Me";
            this->ResumeLayout(false);

        }   
    private: 
        System::Void TopCheck_Entered(System::Object *  sender, 
                                      System::EventArgs *  e)
        {
            // Hide Top checkbox and display bottom
            TopCheck->Enabled = false; 
            TopCheck->Visible = false; 
            BottomCheck->Enabled = true; 
            BottomCheck->Visible = true; 
        }

    private: 
        System::Void BottomCheck_Entered(System::Object *  sender, 
                                         System::EventArgs *  e)
        {
            // Hide Bottom checkbox and display top
            BottomCheck->Enabled = false; 
            BottomCheck->Visible = false; 
            TopCheck->Enabled = true; 
            TopCheck->Visible = true; 
        }

    };
}


