#pragma once


namespace SyncCombos
{
    using namespace System;
    using namespace System::ComponentModel;
    using namespace System::Collections;
    using namespace System::Windows::Forms;
    using namespace System::Data;
    using namespace System::Drawing;

    public __gc class Form1 : public System::Windows::Forms::Form
    {   
    public:
        Form1(void)
        {
            InitializeComponent();
            PopulateLists();
        }
  
    protected:
        void Dispose(Boolean disposing)
        {
            if (disposing && components)
            {
                components->Dispose();
            }
            __super::Dispose(disposing);
        }
    private: System::Windows::Forms::ComboBox *  ddown;
    private: System::Windows::Forms::ComboBox *  simple;
    private: System::Windows::Forms::ComboBox *  ddlist;
    private: System::ComponentModel::Container * components;

        void InitializeComponent(void)
        {
            this->ddown = new System::Windows::Forms::ComboBox();
            this->simple = new System::Windows::Forms::ComboBox();
            this->ddlist = new System::Windows::Forms::ComboBox();
            this->SuspendLayout();
            // 
            // ddown
            // 
            this->ddown->Location = System::Drawing::Point(16, 24);
            this->ddown->MaxDropDownItems = 3;
            this->ddown->MaxLength = 10;
            this->ddown->Name = S"ddown";
            this->ddown->Size = System::Drawing::Size(121, 24);
            this->ddown->TabIndex = 0;
            this->ddown->TextChanged += new System::EventHandler(this, ddown_Change);
            this->ddown->SelectedIndexChanged += new System::EventHandler(this, ddown_Change);
            // 
            // simple
            // 
            this->simple->DropDownStyle = System::Windows::Forms::ComboBoxStyle::Simple;
            this->simple->Location = System::Drawing::Point(184, 24);
            this->simple->Name = S"simple";
            this->simple->Size = System::Drawing::Size(121, 128);
            this->simple->Sorted = true;
            this->simple->TabIndex = 1;
            this->simple->TextChanged += new System::EventHandler(this, simple_Change);
            this->simple->SelectedIndexChanged += new System::EventHandler(this, simple_Change);
            // 
            // ddlist
            // 
            this->ddlist->DropDownStyle = System::Windows::Forms::ComboBoxStyle::DropDownList;
            this->ddlist->Location = System::Drawing::Point(352, 24);
            this->ddlist->Name = S"ddlist";
            this->ddlist->Size = System::Drawing::Size(121, 24);
            this->ddlist->TabIndex = 2;
            this->ddlist->SelectedIndexChanged += new System::EventHandler(this, ddlist_Change);
            // 
            // Form1
            // 
            this->AutoScaleBaseSize = System::Drawing::Size(6, 15);
            this->ClientSize = System::Drawing::Size(496, 167);
            this->Controls->Add(this->ddlist);
            this->Controls->Add(this->simple);
            this->Controls->Add(this->ddown);
            this->Name = S"Form1";
            this->Text = S"Synchronized Combo boxing";
            this->ResumeLayout(false);

        }   
    private:
        void PopulateLists()
        {
            // Item to be placed in all ComboBoxes
            Object *ddItems[] = { S"oranges", S"cherries", S"apples",
                                S"lemons",  S"bananas",  S"grapes" };
            ddown->Items->AddRange(ddItems);        
            simple->Items->AddRange(ddItems);        
            ddlist->Items->AddRange(ddItems);
        }
    private: 
        System::Void ddown_Change(System::Object *  sender, System::EventArgs *  e)
        {
            // Update simple and dropdownlist with dropdown text
            simple->Text = ddown->Text; 
            ddlist->SelectedItem = ddown->Text; 
        }
    private: 
        System::Void simple_Change(System::Object *  sender, System::EventArgs *  e)
        {
            // Update dropdown and dropdownlist with simple text
            ddown->Text = simple->Text; 
            ddlist->SelectedItem = simple->Text; 
        }
    private: 
        System::Void ddlist_Change(System::Object *  sender, System::EventArgs *  e)
        {
            // Update simple and dropdown with dropdownlist SelectedText
            ddown->SelectedItem = ddlist->SelectedItem; 
            simple->SelectedItem = ddlist->SelectedItem; 
        }
    };
}


