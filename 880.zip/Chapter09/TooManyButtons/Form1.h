#pragma once


namespace TooManyButtons
{
    using namespace System;
    using namespace System::ComponentModel;
    using namespace System::Collections;
    using namespace System::Windows::Forms;
    using namespace System::Data;
    using namespace System::Drawing;

    /// <summary> 
    /// Summary for Form1
    ///
    /// WARNING: If you change the name of this class, you will need to change the 
    ///          'Resource File Name' property for the managed resource compiler tool 
    ///          associated with all .resx files this class depends on.  Otherwise,
    ///          the designers will not be able to interact properly with localized
    ///          resources associated with this form.
    /// </summary>
    public __gc class Form1 : public System::Windows::Forms::Form
    {   
    public:
        Form1(void)
        {
            InitializeComponent();
        }
  
    protected:
        void Dispose(Boolean disposing)
        {
            if (disposing && components)
            {
                components->Dispose();
            }
            __super::Dispose(disposing);
        }
    private: System::Windows::Forms::Button *  TooMany;

    private:
        /// <summary>
        /// Required designer variable.
        /// </summary>
        System::ComponentModel::Container * components;

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        void InitializeComponent(void)
        {
            this->TooMany = new System::Windows::Forms::Button();
            this->SuspendLayout();
            // 
            // TooMany
            // 
            this->TooMany->Location = System::Drawing::Point(24, 16);
            this->TooMany->Name = S"TooMany";
            this->TooMany->TabIndex = 0;
            this->TooMany->Text = S"Click Me!";
            this->TooMany->Size = System::Drawing::Size(72, 24);
            this->TooMany->Click += new System::EventHandler(this, TooMany_Click);
            // 
            // Form1
            // 
            this->AutoScaleBaseSize = System::Drawing::Size(6, 15);
            this->ClientSize = System::Drawing::Size(292, 270);
            this->Controls->Add(this->TooMany);
            this->Name = S"Form1";
            this->Text = S"Too Many Buttons";
            this->ResumeLayout(false);

        }   
    private: 
        System::Void TooMany_Click(System::Object *  sender, System::EventArgs *  e)
        {
            // Grab the location of the button that was clicked
            Point p = dynamic_cast<Button*>(sender)->Location; 

            // Create a dynamic button
            Button *Many = new Button(); 
            Many->Location = Drawing::Point(p.X + 36, p.Y + 26); 
            Many->Size = Drawing::Size(72, 24); 
            Many->Text = S"Click Me!"; 
            Many->Click += new System::EventHandler(this, TooMany_Click); 

            // Add dynamic button to Form
            Controls->Add(Many); 
        }

    };
}


