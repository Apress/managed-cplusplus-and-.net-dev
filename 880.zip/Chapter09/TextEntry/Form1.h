#pragma once


namespace TextEntry
{
    using namespace System;
    using namespace System::ComponentModel;
    using namespace System::Collections;
    using namespace System::Windows::Forms;
    using namespace System::Data;
    using namespace System::Drawing;

    public __gc class Form1 : public System::Windows::Forms::Form
    {   
    public:
        Form1(void)
        {
            InitializeComponent();
        }
  
    protected:
        void Dispose(Boolean disposing)
        {
            if (disposing && components)
            {
                components->Dispose();
            }
            __super::Dispose(disposing);
        }
    private: System::Windows::Forms::TextBox *  Entry;
    private: System::Windows::Forms::TextBox *  Result;
    private: System::Windows::Forms::Button *  bnSubmit;
    private: System::Windows::Forms::TextBox *  Password;
    private: System::ComponentModel::Container * components;

        void InitializeComponent(void)
        {
            this->Entry = new System::Windows::Forms::TextBox();
            this->Result = new System::Windows::Forms::TextBox();
            this->Password = new System::Windows::Forms::TextBox();
            this->bnSubmit = new System::Windows::Forms::Button();
            this->SuspendLayout();
            // 
            // Entry
            // 
            this->Entry->Location = System::Drawing::Point(25, 25);
            this->Entry->Name = S"Entry";
            this->Entry->Size = System::Drawing::Size(260, 22);
            this->Entry->TabIndex = 0;
            // 
            // Result
            // 
            this->Result->AcceptsReturn = true;
            this->Result->AcceptsTab = true;
            this->Result->Location = System::Drawing::Point(25, 65);
            this->Result->Multiline = true;
            this->Result->Name = S"Result";
            this->Result->ReadOnly = true;
            this->Result->ScrollBars = System::Windows::Forms::ScrollBars::Vertical;
            this->Result->Size = System::Drawing::Size(330, 240);
            this->Result->TabIndex = 1;
            // 
            // Password
            // 
            this->Password->Location = System::Drawing::Point(25, 320);
            this->Password->Name = S"Password";
            this->Password->PasswordChar = '*';
            this->Password->Size = System::Drawing::Size(330, 22);
            this->Password->TabIndex = 2;
            this->Password->Text = S"You cannot cut or copy but you can paste text";
            this->Password->TextChanged += new System::EventHandler(this, Password_TextChanged);
            // 
            // bnSubmit
            // 
            this->bnSubmit->Location = System::Drawing::Point(290, 25);
            this->bnSubmit->Name = S"bnSubmit";
            this->bnSubmit->Size = System::Drawing::Size(60, 25);
            this->bnSubmit->TabIndex = 3;
            this->bnSubmit->Text = S"Submit";
            this->bnSubmit->Click += new System::EventHandler(this, bnSubmit_Click);
            // 
            // Form1
            // 
            this->AcceptButton = this->bnSubmit;
            this->AutoScaleBaseSize = System::Drawing::Size(6, 15);
            this->ClientSize = System::Drawing::Size(370, 360);
            this->Controls->Add(this->bnSubmit);
            this->Controls->Add(this->Password);
            this->Controls->Add(this->Result);
            this->Controls->Add(this->Entry);
            this->Name = S"Form1";
            this->Text = S"Simple Text Entry";
            this->ResumeLayout(false);

        }   
    private: 
        System::Void Password_TextChanged(System::Object *  sender, System::EventArgs *  e)
        {
            // if the Password TextBox Text equals "Editable" then make 
            // the multiline TextBox editable
            if (Password->Text->Equals(S"Editable")) 
                Result->ReadOnly = false; 
            else 
                Result->ReadOnly = true; 
        }
    private: 
        System::Void bnSubmit_Click(System::Object *  sender, System::EventArgs *  e)
        {
            // Grab a StringBuilder from the Text of the Multiline Textbox
            Result->Text = String::Concat(Entry->Text, S"\r\n", Result->Text);
            Entry->Clear(); 
        }
    };
}


