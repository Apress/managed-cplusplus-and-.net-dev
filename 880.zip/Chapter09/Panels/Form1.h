#pragma once


namespace Panels
{
    using namespace System;
    using namespace System::ComponentModel;
    using namespace System::Collections;
    using namespace System::Windows::Forms;
    using namespace System::Data;
    using namespace System::Drawing;

    public __gc class Form1 : public System::Windows::Forms::Form
    {   
    public:
        Form1(void)
        {
            InitializeComponent();
        }
  
    protected:
        void Dispose(Boolean disposing)
        {
            if (disposing && components)
            {
                components->Dispose();
            }
            __super::Dispose(disposing);
        }
    private: System::Windows::Forms::Panel *  Leftpanel;
    private: System::Windows::Forms::Panel *  Rightpanel;
    private: System::Windows::Forms::Button *  bnDisable;
    private: System::Windows::Forms::Button *  bnHide;
    private: System::Windows::Forms::Button *  button1;
    private: System::Windows::Forms::Button *  button2;
    private: System::ComponentModel::Container * components;

        void InitializeComponent(void)
        {
            this->Leftpanel = new System::Windows::Forms::Panel();
            this->Rightpanel = new System::Windows::Forms::Panel();
            this->bnDisable = new System::Windows::Forms::Button();
            this->bnHide = new System::Windows::Forms::Button();
            this->button1 = new System::Windows::Forms::Button();
            this->button2 = new System::Windows::Forms::Button();
            this->Leftpanel->SuspendLayout();
            this->Rightpanel->SuspendLayout();
            this->SuspendLayout();
            // 
            // Leftpanel
            // 
            this->Leftpanel->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
            this->Leftpanel->Controls->Add(this->bnHide);
            this->Leftpanel->Controls->Add(this->bnDisable);
            this->Leftpanel->Location = System::Drawing::Point(32, 24);
            this->Leftpanel->Name = S"Leftpanel";
            this->Leftpanel->Size = System::Drawing::Size(145, 110);
            this->Leftpanel->TabIndex = 0;
            // 
            // Rightpanel
            // 
            this->Rightpanel->AutoScroll = true;
            this->Rightpanel->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
            this->Rightpanel->Controls->Add(this->button2);
            this->Rightpanel->Controls->Add(this->button1);
            this->Rightpanel->Location = System::Drawing::Point(192, 24);
            this->Rightpanel->Name = S"Rightpanel";
            this->Rightpanel->Size = System::Drawing::Size(145, 70);
            this->Rightpanel->TabIndex = 1;
            // 
            // bnDisable
            // 
            this->bnDisable->Location = System::Drawing::Point(20, 8);
            this->bnDisable->Name = S"bnDisable";
            this->bnDisable->Size = System::Drawing::Size(100, 24);
            this->bnDisable->TabIndex = 0;
            this->bnDisable->Text = S"Disable Panel";
            this->bnDisable->Click += new System::EventHandler(this, bnDisable_Click);
            // 
            // bnHide
            // 
            this->bnHide->Location = System::Drawing::Point(20, 72);
            this->bnHide->Name = S"bnHide";
            this->bnHide->Size = System::Drawing::Size(100, 24);
            this->bnHide->TabIndex = 1;
            this->bnHide->Text = S"Hide Panel";
            this->bnHide->Click += new System::EventHandler(this, bnHide_Click);
            // 
            // button1
            // 
            this->button1->Location = System::Drawing::Point(24, 8);
            this->button1->Name = S"button1";
            this->button1->TabIndex = 0;
            this->button1->Text = S"button1";
            // 
            // button2
            // 
            this->button2->Location = System::Drawing::Point(24, 72);
            this->button2->Name = S"button2";
            this->button2->TabIndex = 1;
            this->button2->Text = S"button2";
            // 
            // Form1
            // 
            this->AutoScaleBaseSize = System::Drawing::Size(6, 15);
            this->ClientSize = System::Drawing::Size(370, 160);
            this->Controls->Add(this->Rightpanel);
            this->Controls->Add(this->Leftpanel);
            this->Name = S"Form1";
            this->Text = S"A hidden fourth button";
            this->Leftpanel->ResumeLayout(false);
            this->Rightpanel->ResumeLayout(false);
            this->ResumeLayout(false);
        }   
    private: 
        System::Void bnDisable_Click(System::Object *  sender, System::EventArgs *  e)
        {
            Rightpanel->Enabled = !Rightpanel->Enabled;
        }
    private: 
        System::Void bnHide_Click(System::Object *  sender, System::EventArgs *  e)
        {
            Rightpanel->Visible = !Rightpanel->Visible;
        }
    };
}


