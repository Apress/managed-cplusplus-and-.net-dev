#pragma once


namespace MinuteTimer
{
    using namespace System;
    using namespace System::ComponentModel;
    using namespace System::Collections;
    using namespace System::Windows::Forms;
    using namespace System::Data;
    using namespace System::Drawing;

    public __gc class Form1 : public System::Windows::Forms::Form
    {   
    public:
        Form1(void)
        {
            InitializeComponent();
            seconds = 0;
        }
  
    protected:
        void Dispose(Boolean disposing)
        {
            if (disposing && components)
            {
                components->Dispose();
            }
            __super::Dispose(disposing);
        }

    private: System::Windows::Forms::Timer *  timer;
    private: System::Windows::Forms::Label *  lbsecs;
    private: System::Windows::Forms::ProgressBar *  progressBar;
    private: System::ComponentModel::IContainer *  components;

    Int32 seconds;
    
        void InitializeComponent(void)
        {
            this->components = new System::ComponentModel::Container();
            this->lbsecs = new System::Windows::Forms::Label();
            this->progressBar = new System::Windows::Forms::ProgressBar();
            this->timer = new System::Windows::Forms::Timer(this->components);
            this->SuspendLayout();
            // 
            // lbsecs
            // 
            this->lbsecs->Location = System::Drawing::Point(25, 25);
            this->lbsecs->Name = S"lbsecs";
            this->lbsecs->Size = System::Drawing::Size(50, 25);
            this->lbsecs->TabIndex = 0;
            this->lbsecs->TextAlign = System::Drawing::ContentAlignment::MiddleRight;
            // 
            // progressBar
            // 
            this->progressBar->Location = System::Drawing::Point(80, 25);
            this->progressBar->Maximum = 60;
            this->progressBar->Name = S"progressBar";
            this->progressBar->Size = System::Drawing::Size(300, 25);
            this->progressBar->TabIndex = 1;
            // 
            // timer1
            // 
            this->timer->Enabled = true;
            this->timer->Tick += new System::EventHandler(this, timer_Tick);
            // 
            // Form1
            // 
            this->AutoScaleBaseSize = System::Drawing::Size(6, 15);
            this->ClientSize = System::Drawing::Size(450, 80);
            this->Controls->Add(this->progressBar);
            this->Controls->Add(this->lbsecs);
            this->Name = S"Form1";
            this->Text = S"The One Minute Timer";
            this->ResumeLayout(false);
        }   
    private: 
        System::Void timer_Tick(System::Object *  sender, System::EventArgs *  e)
        {
            // Write current tick count (int 10th of second) to label
            seconds++; 
            seconds %= 600; 
            lbsecs->Text = String::Format(S"{0}.{1}", (seconds/10).ToString(),
                                                      (seconds%10).ToString());
            // Update ProgressBar
            progressBar->Value = seconds/10; 
         }
   };
}


