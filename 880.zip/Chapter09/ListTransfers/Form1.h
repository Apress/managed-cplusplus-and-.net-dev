#pragma once


namespace ListTransfers
{
    using namespace System;
    using namespace System::ComponentModel;
    using namespace System::Collections;
    using namespace System::Windows::Forms;
    using namespace System::Data;
    using namespace System::Drawing;

    public __gc class Form1 : public System::Windows::Forms::Form
    {   
    public:
        Form1(void)
        {
            InitializeComponent();
        }
  
    protected:
        void Dispose(Boolean disposing)
        {
            if (disposing && components)
            {
                components->Dispose();
            }
            __super::Dispose(disposing);
        }
    private: System::Windows::Forms::Label *  lOrg;
    private: System::Windows::Forms::Label *  lDest;
    private: System::Windows::Forms::Button *  bnL2R;
    private: System::Windows::Forms::Button *  bnR2L;
    private: System::Windows::Forms::ListBox *  LBOrg;
    private: System::Windows::Forms::ListBox *  LBDest;
    private: System::ComponentModel::Container * components;

        void InitializeComponent(void)
        {
            this->lOrg = new System::Windows::Forms::Label();
            this->lDest = new System::Windows::Forms::Label();
            this->bnL2R = new System::Windows::Forms::Button();
            this->bnR2L = new System::Windows::Forms::Button();
            this->LBOrg = new System::Windows::Forms::ListBox();
            this->LBDest = new System::Windows::Forms::ListBox();
            this->SuspendLayout();
            // 
            // lOrg
            // 
            this->lOrg->Location = System::Drawing::Point(24, 16);
            this->lOrg->Name = S"lOrg";
            this->lOrg->Size = System::Drawing::Size(136, 23);
            this->lOrg->TabIndex = 0;
            this->lOrg->Text = S"Sorted Multiextended";
            // 
            // lDest
            // 
            this->lDest->Location = System::Drawing::Point(256, 16);
            this->lDest->Name = S"lDest";
            this->lDest->Size = System::Drawing::Size(136, 23);
            this->lDest->TabIndex = 1;
            this->lDest->Text = S"Unsorted Multisimple";
            // 
            // bnL2R
            // 
            this->bnL2R->Location = System::Drawing::Point(200, 88);
            this->bnL2R->Name = S"bnL2R";
            this->bnL2R->Size = System::Drawing::Size(40, 23);
            this->bnL2R->TabIndex = 2;
            this->bnL2R->Text = S"==>";
            this->bnL2R->Click += new System::EventHandler(this, bnL2R_Click);
            // 
            // bnR2L
            // 
            this->bnR2L->Location = System::Drawing::Point(200, 120);
            this->bnR2L->Name = S"bnR2L";
            this->bnR2L->Size = System::Drawing::Size(40, 23);
            this->bnR2L->TabIndex = 3;
            this->bnR2L->Text = S"<==";
            this->bnR2L->Click += new System::EventHandler(this, bnR2L_Click);
            // 
            // LBOrg
            // 
            this->LBOrg->ItemHeight = 16;
            System::Object* __mcTemp__1[] = new System::Object*[10];
            __mcTemp__1[0] = S"System";
            __mcTemp__1[1] = S"System::Collections";
            __mcTemp__1[2] = S"System::Data";
            __mcTemp__1[3] = S"System::Drawing";
            __mcTemp__1[4] = S"System::IO";
            __mcTemp__1[5] = S"System::Net";
            __mcTemp__1[6] = S"System::Threading";
            __mcTemp__1[7] = S"System::Web";
            __mcTemp__1[8] = S"System::Windows::Forms";
            __mcTemp__1[9] = S"System::Xml";
            this->LBOrg->Items->AddRange(__mcTemp__1);
            this->LBOrg->Location = System::Drawing::Point(24, 48);
            this->LBOrg->Name = S"LBOrg";
            this->LBOrg->SelectionMode = System::Windows::Forms::SelectionMode::MultiExtended;
            this->LBOrg->Size = System::Drawing::Size(160, 164);
            this->LBOrg->Sorted = true;
            this->LBOrg->TabIndex = 0;
            this->LBOrg->DoubleClick += new System::EventHandler(this, LBOrg_DoubleClick);
            // 
            // LBDest
            // 
            this->LBDest->ItemHeight = 16;
            this->LBDest->Location = System::Drawing::Point(256, 48);
            this->LBDest->Name = S"LBDest";
            this->LBDest->SelectionMode = System::Windows::Forms::SelectionMode::MultiSimple;
            this->LBDest->Size = System::Drawing::Size(160, 164);
            this->LBDest->TabIndex = 1;
            this->LBDest->DoubleClick += new System::EventHandler(this, LBDest_DoubleClick);
            // 
            // Form1
            // 
            this->AutoScaleBaseSize = System::Drawing::Size(6, 15);
            this->ClientSize = System::Drawing::Size(440, 231);
            this->Controls->Add(this->LBDest);
            this->Controls->Add(this->LBOrg);
            this->Controls->Add(this->bnR2L);
            this->Controls->Add(this->bnL2R);
            this->Controls->Add(this->lDest);
            this->Controls->Add(this->lOrg);
            this->Name = S"Form1";
            this->Text = S"List Box Transfers";
            this->ResumeLayout(false);
        }   
    private: 
        System::Void LBOrg_DoubleClick(System::Object *  sender, System::EventArgs *  e)
        {
            // Add Selected item to other ListBox 
            // Then remove item from original
            if (LBOrg->SelectedItem != 0)
            {
                LBDest->Items->Add(LBOrg->SelectedItem); 
                LBOrg->Items->Remove(LBOrg->SelectedItem); 
            }
        }

    private: 
        System::Void LBDest_DoubleClick(System::Object *  sender, System::EventArgs *  e)
        {
            // Add Selected item to other ListBox 
            // Then remove item from original
            if (LBDest->SelectedItem != 0)
            {
                LBOrg->Items->Add(LBDest->SelectedItem); 
                LBDest->Items->Remove(LBDest->SelectedItem); 
            }
        }

    private: 
        System::Void bnL2R_Click(System::Object *  sender, System::EventArgs *  e)
        {
            // Add all Selected items to other ListBox 
            // Then remove the all items from original
            Object *tmp[] = new Object*[LBOrg->SelectedItems->Count]; 
            LBOrg->SelectedItems->CopyTo(tmp, 0); 
            LBDest->Items->AddRange(tmp); 
            for (Int32 i = 0; i < tmp->Count; i++) 
                LBOrg->Items->Remove(tmp[i]); 
        }

    private: 
        System::Void bnR2L_Click(System::Object *  sender, System::EventArgs *  e)
        {
            // Add all Selected items to other ListBox 
            // Then remove all the items from original
            Object *tmp[] = new Object*[LBDest->SelectedItems->Count]; 
            LBDest->SelectedItems->CopyTo(tmp, 0); 
            LBOrg->Items->AddRange(tmp); 
            for (Int32 i = 0; i < tmp->Count; i++) 
                LBDest->Items->Remove(tmp[i]); 
        }
    };
}


