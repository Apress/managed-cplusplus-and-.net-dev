#pragma once


namespace GroupingRadios
{
    using namespace System;
    using namespace System::ComponentModel;
    using namespace System::Collections;
    using namespace System::Windows::Forms;
    using namespace System::Data;
    using namespace System::Drawing;

    public __gc class Form1 : public System::Windows::Forms::Form
    {   
    public:
        Form1(void)
        {
            InitializeComponent();
            BuildRadios();
        }
  
    protected:
        void Dispose(Boolean disposing)
        {
            if (disposing && components)
            {
                components->Dispose();
            }
            __super::Dispose(disposing);
        }
    private: 
        System::Windows::Forms::GroupBox * groupBox1;
        System::Windows::Forms::GroupBox * groupBox2;

        System::ComponentModel::Container * components;

        System::Windows::Forms::RadioButton * radio1[]; 
        System::Windows::Forms::RadioButton * radio2[]; 
        System::Windows::Forms::RadioButton * radio3[]; 

        void InitializeComponent(void)
        {
            this->groupBox1 = new System::Windows::Forms::GroupBox();
            this->groupBox2 = new System::Windows::Forms::GroupBox();
            this->SuspendLayout();
            // 
            // groupBox1
            // 
            this->groupBox1->Location = System::Drawing::Point(150, 15);
            this->groupBox1->Name = S"groupBox1";
            this->groupBox1->Size = System::Drawing::Size(150, 130);
            this->groupBox1->TabIndex = 0;
            this->groupBox1->TabStop = false;
            this->groupBox1->Text = S"You";
            // 
            // groupBox2
            // 
            this->groupBox2->Location = System::Drawing::Point(150, 160);
            this->groupBox2->Name = S"groupBox2";
            this->groupBox2->Size = System::Drawing::Size(150, 130);
            this->groupBox2->TabIndex = 1;
            this->groupBox2->TabStop = false;
            this->groupBox2->Text = S"Use";
            // 
            // Form1
            // 
            this->AutoScaleBaseSize = System::Drawing::Size(6, 15);
            this->ClientSize = System::Drawing::Size(352, 330);
            this->Controls->Add(this->groupBox2);
            this->Controls->Add(this->groupBox1);
            this->Name = S"Form1";
            this->Text = S"Using Group Boxes";
            this->ResumeLayout(false);
        }   
            
        void BuildRadios()
        {
            this->SuspendLayout();
            // Text for RadioButton places on Form directly
            String *rbText1[]= {S"Can", S"You", S"Click", S"More", S"Than", S"One"};
            // Build a RadioButton for each rbText1
            radio1 = new RadioButton*[6]; 
            for (Int32 i = 0; i < radio1->Count; i++)
            {
                radio1[i] = new RadioButton();
                radio1[i]->Location = Drawing::Point(20, 20+(40*i)); 
                radio1[i]->Text = rbText1[i]; 
            }
            // Add RadioButtons to Form
            Controls->AddRange(radio1);

            // Text for RadioButton places in first GroupBox
            String *rbText2[] = {S"Can", S"If", S"You"};
            // Build a RadioButton for each rbText2
            radio2 = new RadioButton*[3]; 
            for (Int32 i = 0; i < radio2->Count; i++)
            {
                radio2[i] = new RadioButton();
                radio2[i]->Location = Drawing::Point(40, 30+(35*i)); 
                radio2[i]->Text = rbText2[i]; 
            }
            // Add RadioButtons to GroupBox
            groupBox1->Controls->AddRange(radio2);
            
            // Text for RadioButton places in second GroupBox
            String *rbText3[] = {S"Different", S"Group", S"Boxes"};
            // Build a RadioButton for each rbText3
            radio3 = new RadioButton*[3]; 
            for (Int32 i = 0; i < radio3->Count; i++)
            {
                radio3[i] = new RadioButton();
                radio3[i]->Location = Drawing::Point(40, 30+(35*i)); 
                radio3[i]->Text = rbText3[i]; 
            }
            // Add RadioButtons to GroupBox2
            groupBox2->Controls->AddRange(radio3);

            this->ResumeLayout(false);
        }
    };
}


