#pragma once


namespace ArrayOfRadios
{
    using namespace System;
    using namespace System::Collections;
    using namespace System::Windows::Forms;
    using namespace System::Drawing;

    public __gc class Form1 : public System::Windows::Forms::Form
    {   
        RadioButton *radios[]; 
        Label       *label; 

    public:
        Form1(void)
        {
        String *rbText[] = {S"Can", S"You", S"Click", S"More", S"Than", S"One"};
        radios = new RadioButton*[6]; 
        label  = new Label(); 

        for (Int32 i = 0; i < radios->Count; i++)
        {
            Int32 j = 50*i;
            radios[i] = new RadioButton();
            radios[i]->BackColor = Color::FromArgb(255, j+5, j+5, j+5);
            radios[i]->ForeColor = Color::FromArgb(255, 250-j, 250-j, 250-j);
            radios[i]->Location = Drawing::Point(90, 5+(40*i)); 
            radios[i]->TabIndex = i; 
            radios[i]->TabStop = true; 
            radios[i]->Text = rbText[i]; 
            radios[i]->CheckedChanged += 
                new EventHandler(this,radioCheckedChanged);
        }
        Controls->AddRange(radios);

        label->Location = Drawing::Point(90, 5+(40*radios->Count)); 
        Controls->Add(label);

        Text = S"An Array Of Radios";
    }
  
    private:
        void radioCheckedChanged(Object *sender, EventArgs *e)
        {
            RadioButton *rb = dynamic_cast<RadioButton*>(sender);

            if (rb->Checked == true)
                label->Text = rb->Text; 
        }
    };
}


